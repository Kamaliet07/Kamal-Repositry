﻿CREATE TABLE [dbo].[Skills] (
    [SkillId]          INT            IDENTITY (1, 1) NOT NULL,
    [Skill]            NVARCHAR (150) NOT NULL,
    [SkillDescription] NVARCHAR (250) NULL,
    [Active]           BIT            NOT NULL,
    [CreatedDate]      DATETIME2 (7)  NULL,
    [UpdatedDate]      DATETIME2 (7)  NULL,
    CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED ([SkillId] ASC)
);

