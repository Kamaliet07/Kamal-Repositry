﻿CREATE TABLE [dbo].[TempCustomer] (
    [ID]      INT        NOT NULL,
    [FName]   CHAR (10)  NULL,
    [LName]   CHAR (10)  NULL,
    [Salary]  INT        NULL,
    [City]    CHAR (10)  NULL,
    [Country] NCHAR (10) NULL,
    [DeptID]  INT        NULL
);

