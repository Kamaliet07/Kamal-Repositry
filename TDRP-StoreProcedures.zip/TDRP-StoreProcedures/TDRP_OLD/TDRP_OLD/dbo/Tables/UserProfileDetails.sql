﻿CREATE TABLE [dbo].[UserProfileDetails] (
    [ProfileId]      INT             IDENTITY (1, 1) NOT NULL,
    [UserId]         NVARCHAR (450)  NULL,
    [FirstName]      NVARCHAR (20)   NULL,
    [LastName]       NVARCHAR (25)   NULL,
    [TeamId]         INT             NULL,
    [JobRoleId]      INT             NULL,
    [Active]         BIT             NOT NULL,
    [CreatedDate]    DATETIME2 (7)   NULL,
    [UpdatedDate]    DATETIME2 (7)   NULL,
    [EmployeeNumber] INT             NOT NULL,
    [FTE]            DECIMAL (18, 2) NULL,
    CONSTRAINT [PK_UserProfileDetails] PRIMARY KEY CLUSTERED ([ProfileId] ASC),
    CONSTRAINT [FK_UserProfileDetails_JobRoles_JobRoleId] FOREIGN KEY ([JobRoleId]) REFERENCES [dbo].[JobRoles] ([JobRoleId]),
    CONSTRAINT [FK_UserProfileDetails_Teams_TeamId] FOREIGN KEY ([TeamId]) REFERENCES [dbo].[Teams] ([TeamId]),
    CONSTRAINT [FK_UserProfileDetails_UserProfileDetails] FOREIGN KEY ([ProfileId]) REFERENCES [dbo].[UserProfileDetails] ([ProfileId])
);


GO
CREATE NONCLUSTERED INDEX [IX_UserProfileDetails_JobRoleId]
    ON [dbo].[UserProfileDetails]([JobRoleId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_UserProfileDetails_TeamId]
    ON [dbo].[UserProfileDetails]([TeamId] ASC);

