﻿CREATE TABLE [dbo].[Months] (
    [MonthId]     INT       IDENTITY (1, 1) NOT NULL,
    [MonthName]   CHAR (12) NOT NULL,
    [Active]      BIT       NOT NULL,
    [CreatedDate] DATETIME  NULL,
    [UpdatedDate] DATETIME  NULL,
    [TotalNoDays] INT       NULL,
    [Holidays]    INT       NULL,
    CONSTRAINT [PK_Months] PRIMARY KEY CLUSTERED ([MonthId] ASC)
);

