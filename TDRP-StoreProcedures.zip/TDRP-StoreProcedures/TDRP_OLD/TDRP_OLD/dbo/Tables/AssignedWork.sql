﻿CREATE TABLE [dbo].[AssignedWork] (
    [AssignedWorkId]  INT           IDENTITY (1, 1) NOT NULL,
    [ProjectId]       INT           NOT NULL,
    [EndDate]         DATETIME2 (7) NULL,
    [CreatedDate]     DATETIME2 (7) NULL,
    [CreateId]        INT           NOT NULL,
    [UpdatedDate]     DATETIME2 (7) NULL,
    [UpdateId]        INT           NULL,
    [EmployeeNumber]  INT           NULL,
    [TeamId]          INT           NULL,
    [UnnamedResource] BIT           NULL,
    CONSTRAINT [PK_AssignedWork] PRIMARY KEY CLUSTERED ([AssignedWorkId] ASC),
    CONSTRAINT [FK_AssignedWork_AssignedWork] FOREIGN KEY ([TeamId]) REFERENCES [dbo].[Teams] ([TeamId]),
    CONSTRAINT [FK_AssignedWork_Projects_ProjectId] FOREIGN KEY ([ProjectId]) REFERENCES [dbo].[Projects] ([ProjectId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_AssignedWork_ProjectId]
    ON [dbo].[AssignedWork]([ProjectId] ASC);

