﻿CREATE TABLE [dbo].[ProjectDetails] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [ProjectId]   INT             NOT NULL,
    [Notes]       NVARCHAR (1000) NULL,
    [CreatedDate] DATETIME2 (7)   NULL,
    [CreateId]    INT             NOT NULL,
    [UpdatedDate] DATETIME2 (7)   NULL,
    [UpdateId]    INT             NULL,
    CONSTRAINT [PK_ProjectDetails] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProjectDetails_Projects_ProjectId] FOREIGN KEY ([ProjectId]) REFERENCES [dbo].[Projects] ([ProjectId]) ON DELETE CASCADE
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_ProjectDetails_ProjectId]
    ON [dbo].[ProjectDetails]([ProjectId] ASC);

