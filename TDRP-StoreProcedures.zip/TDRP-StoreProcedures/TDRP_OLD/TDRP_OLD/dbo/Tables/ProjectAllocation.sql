﻿CREATE TABLE [dbo].[ProjectAllocation] (
    [ProjAllocationId] INT  IDENTITY (1, 1) NOT NULL,
    [EmployeeNumber]   INT  NOT NULL,
    [ProjectId]        INT  NOT NULL,
    [MonthId]          INT  NOT NULL,
    [AllocatedDays]    INT  NOT NULL,
    [UpdatedDate]      DATE NULL,
    [WorkingDays]      INT  NOT NULL,
    [TeamId]           INT  NULL,
    [Year]             INT  NOT NULL,
    CONSTRAINT [PK_ProjectAllocation_1] PRIMARY KEY CLUSTERED ([ProjAllocationId] ASC),
    CONSTRAINT [FK_ProjectAllocation_Months1] FOREIGN KEY ([MonthId]) REFERENCES [dbo].[Months] ([MonthId]),
    CONSTRAINT [FK_ProjectAllocation_Projects] FOREIGN KEY ([ProjectId]) REFERENCES [dbo].[Projects] ([ProjectId])
);

