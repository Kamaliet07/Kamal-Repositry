﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 05-SEP-2019
-- Description:	Used to add new employees to the system.
-- =============================================
CREATE PROCEDURE [dbo].[sp_AddNewEmployee] 
	-- Add the parameters for the stored procedure here
	-- Parameters to be used to insert into Employees table.
	@Staff_ID int,
	@Supervisor_ID int,
	@EmpType varchar(10),
	@Active bit,
	@FTE decimal(4,2),
	@Start_Date date,
	@Create_ID int,
	@Create_Date date
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO Employees (Staff_ID
						  ,Supervisor_ID
						  ,EmpType
						  ,Active
						  ,FTE
						  ,Start_Date
						  ,Created_ID
						  ,Created_Date)
				   VALUES (@Staff_ID
						  ,@Supervisor_ID
						  ,@EmpType
						  ,@Active
						  ,@FTE
						  ,@Start_Date
						  ,@Create_ID
						  ,@Create_Date)
END
