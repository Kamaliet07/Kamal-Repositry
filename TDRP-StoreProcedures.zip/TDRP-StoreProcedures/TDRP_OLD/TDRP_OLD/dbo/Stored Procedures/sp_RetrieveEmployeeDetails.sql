﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 05-SEP-2019
-- Description: Retrieves all employee details.
-- =============================================
CREATE PROCEDURE sp_RetrieveEmployeeDetails
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * FROM Employee_Details;
END
