﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 04-MARCH-2020
-- Description:	Retrieve the remaining days in month
--				
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetRemainingDaysInMonth] 
	-- Add the parameters for the stored procedure here	
	@EmployeeNo int,	
	@Month char(12),
	@Year int
AS
BEGIN	
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from	
	SET NOCOUNT ON;

	DECLARE 
	@CurrentDate Date,
	@HoursInMonth decimal,
	@WorkingDays int,
	@HoliDays int,
	@Allocateddays int,
	@FteDays int,
	@monthId int;

	WITH CteMonths(n, m) AS(
    SELECT 1, 'January' UNION ALL
    SELECT 2, 'February' UNION ALL
    SELECT 3, 'March' UNION ALL
    SELECT 4, 'April' UNION ALL
    SELECT 5, 'May' UNION ALL
    SELECT 6, 'June' UNION ALL
    SELECT 7, 'July' UNION ALL
    SELECT 8, 'August' UNION ALL
    SELECT 9, 'September' UNION ALL
    SELECT 10, 'October' UNION ALL
    SELECT 11, 'November' UNION ALL
    SELECT 12, 'December'
    )

    SELECT @CurrentDate  =  DATEADD(MONTH, n - 1, DATEADD(YEAR, @Year - 1, 0)) FROM CteMonths WHERE m = @Month;
	
	SELECT @HoliDays = mn.Holidays FROM dbo.Months mn WHERE mn.MonthName = @Month;

	-- Get the total working days in the month
	SELECT @WorkingDays = (SELECT DAY(EOMONTH(@CurrentDate))) - (SELECT dbo.GetWeekendDaysCount(@CurrentDate))

	-- Get the total available hours for the month.
	SELECT @HoursInMonth = @WorkingDays * 7;
		
	SELECT @Allocateddays = COALESCE(SUM(AllocatedDays),0) FROM [dbo].[ProjectAllocation] 
	                         WHERE MonthId = (SELECT mn.MonthId FROM dbo.Months as mn where mn.MonthName = @Month)
							 AND EmployeeNumber = @EmployeeNo
							 AND Year = @Year;

	-- Calculate the number of days the employee is available to work in the month based on their weekly FTE.
	SELECT @FteDays = CEILING((((SELECT e.FTE FROM Employees AS e WHERE e.EmployeeNumber = @EmployeeNo) / 35) * @HoursInMonth) / 7);

	-- Check If Record Already Exist
	SELECT (@FteDays - @Allocateddays - @HoliDays) AS RemainingDays;

	END TRY
	
	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	      
	        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
