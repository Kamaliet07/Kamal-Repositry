﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 27-FEB-2020
-- Description:	Retrieves Employee Details
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetEmployeeDetails]
	-- Add the parameters for the stored procedure here
	@EmployeeNo int,
	@ProjectId int

AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	
	SET NOCOUNT ON;

	     SELECT tm.TeamId, tm.TeamName, tm.SupervisorName, emp.FTE, emp.EmploymentType, emp.EmployeeNumber, emp.FirstName + ' ' + emp.LastName as EmployeeName, 
                         jr.JobRole
               FROM      dbo.Employees AS emp INNER JOIN
                         dbo.Teams AS tm ON emp.TeamId = tm.TeamId LEFT JOIN
                         dbo.JobRoles AS jr ON emp.JobRoleId = jr.JobRoleId
               WHERE     emp.EmployeeNumber = @EmployeeNo
			   AND       emp.EndDate IS NULL
			   

	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
			, @errorNumber      VARCHAR    (Max)
			, @errorSeverioty   VARCHAR    (1000)
			, @errorState       VARCHAR    (1000)
			, @errorLine        VARCHAR    (500)
			, @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
			,@errorSeverioty  = ERROR_SEVERITY()
			,@errorState      = ERROR_STATE()
			,@errorLine       = ERROR_LINE()
			,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
		(
		     @errorMessage
			,@errorSeverioty
			,@errorState
			,@errorLine
			,@errorProcedure
			,@errorNumber
		)
	END CATCH
END
