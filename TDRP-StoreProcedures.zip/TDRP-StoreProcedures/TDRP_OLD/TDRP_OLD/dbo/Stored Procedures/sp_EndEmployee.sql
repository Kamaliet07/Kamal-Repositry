﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 10-SEP-2019
-- Description:	Removes employee based on the employee Staff_ID
-- =============================================
CREATE PROCEDURE [dbo].[sp_EndEmployee] 

	-- Parameters for the Stored Procedure:
	@Staff_ID int,
	@Update_ID int
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Updates the Employees table with the Update ID of the 
	-- user and inserts the current timestamp in the End_Date field.
	UPDATE Employees
	   SET End_Date = CURRENT_TIMESTAMP,
	       Update_ID = @Update_ID,
		   Update_Date = CURRENT_TIMESTAMP
	 WHERE Staff_ID = @Staff_ID;
END
