﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 22-JAN-2020
-- Description:	Retrieve all employees into a list.
-- =============================================
CREATE PROCEDURE [dbo].[usp_ViewEmployeeList] 

AS
BEGIN

	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Main SQL Query
	SELECT   emp.EmpSysId
			,emp.EmployeeNumber
			,(emp.FirstName + ' ' + emp.LastName) AS EmployeeName
			,emp.FTE
			,t.SupervisorName
			,t.TeamName
			,j.JobRole
	FROM	Employees AS emp
	LEFT JOIN Teams AS t ON t.TeamId = emp.TeamId
	LEFT JOIN JobRoles AS j ON j.JobRoleId = emp.JobRoleId
	WHERE	emp.Active = 1
	AND		emp.EndDate IS NULL;

	END TRY
		
	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
	
	        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
