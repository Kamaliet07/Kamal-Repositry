﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 10-DEC-2019
-- Description: Retrieves all Projects for a view.
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAllProjects]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY

    -- Insert statements for procedure here
	SELECT *
	FROM   [dbo].[Projects] AS p
	
	END TRY
	
	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END