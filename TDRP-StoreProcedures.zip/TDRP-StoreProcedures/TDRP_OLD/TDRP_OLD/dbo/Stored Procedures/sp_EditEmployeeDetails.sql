﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 09-SEP-2019
-- Description:	Edit the record for the specified employee.
-- =============================================
CREATE PROCEDURE [dbo].[sp_EditEmployeeDetails] 
	-- Parameters to be used by the stored procedure.
	@EmpDetSYSID int,
	@Staff_ID int,
	@Title varchar(6),
	@First_Name varchar(50),
	@Middle_Name varchar(50),
	@Last_Name varchar(50),
	@Date_Of_Birth date,
	@Email_Address varchar(50),
	@Update_ID int,
	@Update_Date date
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Update the employee details using the specified Staff ID,
	UPDATE Employee_Details
	SET	   Title = @Title,
		   First_Name = @First_Name,
		   Middle_Name = @Middle_Name,
		   Last_Name = @Last_Name,
		   Date_Of_Birth = @Date_Of_Birth,
		   Email_Address = @Email_Address,
		   Update_ID = @Update_ID,
		   Update_Date = @Update_Date
	WHERE  EmpDetSYSID = @EmpDetSYSID
END
