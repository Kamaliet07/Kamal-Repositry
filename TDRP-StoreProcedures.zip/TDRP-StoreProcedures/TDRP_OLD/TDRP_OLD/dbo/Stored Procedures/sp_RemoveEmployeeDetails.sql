﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 09-SEP-2019
-- Description:	Permanently removes the record specified by the Staff_ID from the Employee_Details table.
-- =============================================
CREATE PROCEDURE sp_RemoveEmployeeDetails 
	-- Add the parameters for the stored procedure here
	@EmpDetSYSID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE FROM Employee_Details
	WHERE		EmpDetSYSID = @EmpDetSYSID;
END
