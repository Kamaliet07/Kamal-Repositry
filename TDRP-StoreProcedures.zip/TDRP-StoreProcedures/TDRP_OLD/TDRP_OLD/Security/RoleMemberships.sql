﻿ALTER ROLE [db_owner] ADD MEMBER [YBS\U29338];


GO
ALTER ROLE [db_owner] ADD MEMBER [YBS\U70254];


GO
ALTER ROLE [db_owner] ADD MEMBER [YBS\YBSXW505$];


GO
ALTER ROLE [db_datareader] ADD MEMBER [YBS\YBSLW492$];


GO
ALTER ROLE [db_datareader] ADD MEMBER [YBS\YBSXW505$];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [YBS\YBSLW492$];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [YBS\YBSXW505$];

