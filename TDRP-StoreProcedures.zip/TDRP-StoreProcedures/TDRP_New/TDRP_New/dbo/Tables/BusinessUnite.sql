﻿CREATE TABLE [dbo].[BusinessUnite] (
    [Id]                   INT            IDENTITY (1, 1) NOT NULL,
    [BusinessUniteName]    NVARCHAR (50)  NOT NULL,
    [BusinessUniteDetails] NVARCHAR (250) NULL,
    [OwnerId]              NVARCHAR (450) NOT NULL,
    [Active]               BIT            NOT NULL,
    [CreatedBy]            NVARCHAR (450) NOT NULL,
    [CreatedDate]          DATETIME2 (7)  NULL,
    [UpdateBy]             NVARCHAR (450) NULL,
    [UpdatedDate]          DATETIME2 (7)  NULL,
    CONSTRAINT [PK_BusinessUnite] PRIMARY KEY CLUSTERED ([Id] ASC)
);

