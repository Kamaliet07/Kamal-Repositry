﻿CREATE TABLE [dbo].[Teams] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [TeamName]        NVARCHAR (50)  NOT NULL,
    [TeamDetails]     NVARCHAR (250) NULL,
    [BusinessUniteId] INT            NOT NULL,
    [TeamLeadId]      NVARCHAR (450) NOT NULL,
    [Active]          BIT            NOT NULL,
    [CreatedBy]       NVARCHAR (MAX) NULL,
    [CreatedDate]     DATETIME2 (7)  NULL,
    [UpdateBy]        NVARCHAR (MAX) NULL,
    [UpdatedDate]     DATETIME2 (7)  NULL,
    CONSTRAINT [PK_Teams] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Teams_BusinessUnite_BusinessUniteId] FOREIGN KEY ([BusinessUniteId]) REFERENCES [dbo].[BusinessUnite] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_Teams_BusinessUniteId]
    ON [dbo].[Teams]([BusinessUniteId] ASC);

