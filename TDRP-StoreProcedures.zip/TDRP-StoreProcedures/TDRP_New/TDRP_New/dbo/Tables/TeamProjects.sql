﻿CREATE TABLE [dbo].[TeamProjects] (
    [Id]                 INT             IDENTITY (1, 1) NOT NULL,
    [ProjectName]        NVARCHAR (100)  NOT NULL,
    [ProjectDescription] NVARCHAR (2000) NULL,
    [TeamId]             INT             NOT NULL,
    [EstimatedBudget]    DECIMAL (18, 2) NULL,
    [TotalExpenditure]   DECIMAL (18, 2) NULL,
    [CategoryId]         INT             NOT NULL,
    [Active]             BIT             NOT NULL,
    [StartDate]          DATETIME2 (7)   NULL,
    [EndDate]            DATETIME2 (7)   NULL,
    [CreatedBy]          NVARCHAR (MAX)  NULL,
    [CreateDate]         DATETIME2 (7)   NOT NULL,
    [UpdateBy]           NVARCHAR (MAX)  NULL,
    [UpdateDate]         DATETIME2 (7)   NULL,
    CONSTRAINT [PK_TeamProjects] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_TeamProjects_ProjectCategory_CategoryId] FOREIGN KEY ([CategoryId]) REFERENCES [dbo].[ProjectCategory] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_TeamProjects_Teams_TeamId] FOREIGN KEY ([TeamId]) REFERENCES [dbo].[Teams] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_TeamProjects_CategoryId]
    ON [dbo].[TeamProjects]([CategoryId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_TeamProjects_TeamId]
    ON [dbo].[TeamProjects]([TeamId] ASC);

