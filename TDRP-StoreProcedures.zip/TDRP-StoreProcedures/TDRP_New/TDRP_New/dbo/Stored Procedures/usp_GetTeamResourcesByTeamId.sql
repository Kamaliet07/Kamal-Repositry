﻿-- =============================================
-- Author:		Kamal Batham
-- Create date: 08-DEC-2021
-- Description:	Retrives List of All Register Users
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetTeamResourcesByTeamId]
-- Add the parameters for the stored procedure here
	@TeamId INT

AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
	SELECT TR.Id, 
       Emp.EmployeeName, 
	   TM.TeamName, 
	   BU.BusinessUniteName, 
	   TR.CreateDate
    FROM  dbo.Employees AS Emp INNER JOIN
         dbo.TeamResources as TR ON Emp.Id = TR.EmployeeId INNER JOIN
         dbo.Teams as TM ON TR.TeamId = TM.Id INNER JOIN
		 dbo.BusinessUnite AS BU ON BU.Id = TM.BusinessUniteId
		 WHERE TR.TeamId = @TeamId
	
	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END

