﻿CREATE PROCEDURE [dbo].[usp_GetTeams]

 @MgrId nvarchar(450)

AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE 
	@loopCounter int = 0

	DECLARE @MyBusinessUnite TABLE (
    Id INT NOT NULL    
    );

	IF (@MgrId IS NOT NULL)
	 BEGIN

	 SELECT a.Id, 
       a.TeamName, 
	   a.TeamDetails, 
	   b.BusinessUniteName, 
	   c.Name as TeamLead, 
	   a.CreatedDate
    FROM dbo.Teams a, dbo.BusinessUnite as b, dbo.AspNetUsers as c 
    WHERE a.BusinessUniteId = b.Id AND a.TeamLeadId = c.Id
	AND b.OwnerId = @MgrId

	 END	
	
	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
