﻿-- =============================================
-- Author:		Kamal Batham
-- Create date: 08-DEC-2021
-- Description:	Remove Project Allocation
-- =============================================
CREATE PROCEDURE [dbo].[usp_RemoveProjectAllocation]
-- Add the parameters for the stored procedure here
	@teamId INT,
	@empId INT

AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
	DECLARE @RowsToProcess  int
    DECLARE @CurrentRow     int
    DECLARE @ProjId     int

    DECLARE @tblProjects TABLE (RowID int not null primary key identity(1,1), ProjectId int )  
    INSERT into @tblProjects (ProjectId) SELECT Id FROM dbo.TeamProjects
    SET @RowsToProcess=@@ROWCOUNT

	SET @CurrentRow=0
	WHILE @CurrentRow<@RowsToProcess
	BEGIN
		SET @CurrentRow=@CurrentRow+1
		SELECT @ProjId= ProjectId FROM @tblProjects WHERE RowID=@CurrentRow
		DELETE FROM dbo.ProjectAllocation WHERE ProjectId = @ProjId AND EmployeeId = @empId
    --do your thing here--

    END
	
	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
