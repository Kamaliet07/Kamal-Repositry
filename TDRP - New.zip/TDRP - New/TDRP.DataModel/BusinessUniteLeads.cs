﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    [Table("BusinessUniteLeads")]
    public class BusinessUniteLeads
    {
        [Key]
        public int Id { get; set; }

        [Required]        
        public int BusinessUniteId { get; set; }
        [ForeignKey("BusinessUniteId")]
        public BusinessUnite BusinessUnite { get; set; }

        [Required]
        [Display(Name = "Business Unite Owner")]
        [StringLength(450)]
        public string LeadsId { get; set; }        

        [Required]
        [Display(Name = "Created By")]
        [StringLength(450)]
        public string CreatedBy { get; set; }

        [Display(Name = "Creation Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }        
    }
}
