﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    [Table("BusinessUnite")]
    public class BusinessUnite
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Business Unit Name")]
        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string BusinessUniteName { get; set; }

        [Display(Name = "Business Unit Description")]
        [StringLength(250, ErrorMessage = "Character length cannot exceed 250.")]
        public string BusinessUniteDetails { get; set; }

        [Required]
        [Display(Name = "Business Unit Owner")]
        [StringLength(450)]
        public string OwnerId { get; set; }

        [Required]
        public bool Active { get; set; }

        [Required]
        [Display(Name = "Created By")]
        [StringLength(450)]
        public string CreatedBy { get; set; }

        [Display(Name = "Creation Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Update By")]
        [StringLength(450)]
        public string UpdateBy { get; set; }

        [Display(Name = "Update Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }   
}
