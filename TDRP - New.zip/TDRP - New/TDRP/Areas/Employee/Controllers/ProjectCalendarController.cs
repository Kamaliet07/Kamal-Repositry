﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.Utility;
using System.Security.Claims;
using TDRP.Areas.Employee.Models;

namespace TDRP.Areas.Employee.Controllers
{
    [Authorize]
    [Area(AppConstant.Employee)]
    public class ProjectCalendarController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<ProjectCalendarController> _logger;

        public ProjectCalendarController(IUnitOfWork unitOfWork, ILogger<ProjectCalendarController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                List<TeamModel> teamResources = null;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                if (User.IsInRole(AppConstant.Manager))
                {                   
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@Id", loginuserId, DbType.String, ParameterDirection.Input);
                    teamResources = _unitOfWork.spCall.ReturnList<TeamModel>(AppConstant.usp_GetBusinessUniteTeams, param).Result.ToList();

                }
                else if (User.IsInRole(AppConstant.Lead))
                {
                    var teams = _unitOfWork.teamRepository.GetAll().Where(x => x.TeamLeadId == loginuserId).ToList();
                    teamResources = new List<TeamModel>();
                    TeamModel objmodel = null;  
                    if(teams.Count > 0)
                    {
                        foreach(var item in teams)
                        {
                            objmodel = new TeamModel()
                            {
                                Id = item.Id,
                                TeamName = item.TeamName
                            };

                            teamResources.Add(objmodel);
                        }
                    }                    
                }
                
                return View(teamResources);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public JsonResult GetTeamsProjectCalendar(int teamId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@TeamId", teamId, DbType.Int16, ParameterDirection.Input);
                List<TeamProjectCalendar> projectResource = _unitOfWork.spCall.ReturnList<TeamProjectCalendar>(AppConstant.usp_GetTeamsProjectCalendar, param).Result.ToList();

                return Json(new { success = true, data = projectResource });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }
    }
}
