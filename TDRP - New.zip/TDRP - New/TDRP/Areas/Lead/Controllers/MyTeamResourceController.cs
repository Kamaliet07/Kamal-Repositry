﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.Areas.Lead.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Lead.Controllers
{
    [Authorize]
    [Area("Lead")]
    public class MyTeamResourceController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<MyTeamResourceController> _logger;

        public MyTeamResourceController(IUnitOfWork unitOfWork, ILogger<MyTeamResourceController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetMyTeamResource()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                DynamicParameters param = new DynamicParameters();
                param.Add("@Id", loginuserId, DbType.String, ParameterDirection.Input);
                List<MyTeamResourceModel> teamResources = _unitOfWork.spCall.ReturnList<MyTeamResourceModel>(AppConstant.usp_GetMyTeamResources, param).Result.ToList();

                return Json(new { success = true, data = teamResources });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetResourceProjectAllocation(int empId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@EmpId", empId, DbType.Int16, ParameterDirection.Input);
                List<ResourceCalendar> projectResource = _unitOfWork.spCall.ReturnList<ResourceCalendar>(AppConstant.usp_GetResourceProjectCalendar, param).Result.ToList();

                return Json(new { success = true, data = projectResource });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetResourceCapicityUsed(int empId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@EmpId", empId, DbType.Int16, ParameterDirection.Input);
                List<ProjectResourceFTE> resourceSearch = _unitOfWork.spCall.ReturnList<ProjectResourceFTE>(AppConstant.usp_GetResourceFteAvailability, param).Result.ToList();
                //return Json(resourceSearch);
                return Json(new { success = true, data = resourceSearch });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpDelete]
        public IActionResult DeleteResourceFromTeam(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.teamResourcesRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }

                // First remove project allocation in this team
                RemoveProjectAllocation(objFromDb.TeamId, objFromDb.EmployeeId);

                // Remove resource from team
                _unitOfWork.teamResourcesRepository.Remove(objFromDb);
                _unitOfWork.Save();

                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        private void RemoveProjectAllocation(int teamId, int empId)
        {
            DynamicParameters param = new DynamicParameters();
            param.Add("@teamId", teamId, DbType.Int32, ParameterDirection.Input);
            param.Add("@empId", empId, DbType.Int32, ParameterDirection.Input);
            _unitOfWork.spCall.ExecuteWithoutReturn(AppConstant.usp_RemoveProjectAllocation, param);
        }
    }
}
