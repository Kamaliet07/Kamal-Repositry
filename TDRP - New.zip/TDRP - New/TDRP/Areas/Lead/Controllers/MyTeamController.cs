﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.Areas.Lead.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Lead.Controllers
{
    [Authorize]
    [Area("Lead")]
    public class MyTeamController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<MyTeamController> _logger;

        public MyTeamController(IUnitOfWork unitOfWork, ILogger<MyTeamController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetMyTeam()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                DynamicParameters param = new DynamicParameters();
                param.Add("@UserId", loginuserId, DbType.String, ParameterDirection.Input);
                List<MyTeamViewModel> teamViewModel = _unitOfWork.spCall.ReturnList<MyTeamViewModel>(AppConstant.usp_GetMyTeamDetails, param).Result.ToList();                
                return Json(new { data = teamViewModel });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        public IActionResult Upsert(int id)
        {
            try
            {
                Teams teams = null;
                if (id == 0)
                {
                    teams = new Teams();
                }
                else
                {
                    teams = _unitOfWork.teamRepository.GetById(id);
                }
                return View(teams);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="teams"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Upsert(Teams teams)
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                

                if (ModelState.IsValid)
                {
                    teams.UpdateBy = loginuser;
                    teams.UpdatedDate = DateTime.Now;
                    _unitOfWork.teamRepository.Update(teams);

                    _unitOfWork.Save();

                    return RedirectToAction(nameof(Index));
                }

                return View(teams);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public IActionResult AddTeamResource(int id)
        {            
            Teams teams = null;
            if (id == 0)
            {
                teams = new Teams();                
            }
            else
            {
                teams = _unitOfWork.teamRepository.GetById(id);                
            }

            DynamicParameters param = new DynamicParameters();
            param.Add("@TeamId", id, DbType.Int32, ParameterDirection.Input);
            List<TeamResourceModel> teamResources = _unitOfWork.spCall.ReturnList<TeamResourceModel>(AppConstant.usp_GetTeamResources, param).Result.ToList();

            TeamResourcesModel teamResourcesModel = new TeamResourcesModel()
            {
                Teams = teams,
                TeamResourceModel = teamResources,
            };

            return View(teamResourcesModel);
        }

        [HttpGet]
        public JsonResult SearchResource(string search)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@namestr", search, DbType.String, ParameterDirection.Input);
                List<EmployeesModel> resources = _unitOfWork.spCall.ReturnList<EmployeesModel>(AppConstant.usp_SearchTeamResources, param).Result.ToList();
                return Json(resources);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }            
        }


        [HttpPost]
        public IActionResult AddResourceInTeam(int Id, int empId)
        {
            try
            {
                bool status = false;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                
                if (empId != 0)
                {
                    if (!ResourceAlreadyExist(empId))
                    {
                        TeamResources teamResources = new TeamResources()
                        {
                            EmployeeId = empId,
                            TeamId = Id,
                            CreatedBy = loginuserId,
                            CreateDate = DateTime.Now
                        };

                        _unitOfWork.teamResourcesRepository.Add(teamResources);
                        _unitOfWork.Save();
                        status = true;
                    }                    
                }

                //return RedirectToAction(nameof(Index));
                return Json(new { success = status, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while Adding." });
            }
        }

        private bool ResourceAlreadyExist(int empId)
        {
            bool exist = false;
            List<TeamResources> buteamLeads = _unitOfWork.teamResourcesRepository.GetAll().Where(x => x.EmployeeId == empId).ToList();
            if (buteamLeads.Count > 0)
            {
                exist = true;
            }
            return exist;
        }

        [HttpDelete]
        public IActionResult DeleteResourceFromTeam(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.teamResourcesRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.teamResourcesRepository.Remove(objFromDb);
                _unitOfWork.Save();

                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
