﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TDRP.Areas.Lead.Models
{
    public class MyTeamViewModel
    {
        public string Id { get; set; }
        public string TeamName { get; set; }
        public string TeamDetails { get; set; }
        public string BusinessUniteName { get; set; }        
        public string CreatedBy { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreatedDate { get; set; }
    }
}
