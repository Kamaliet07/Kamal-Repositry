﻿using System;
using System.Collections.Generic;

namespace TDRP.Areas.Lead.Models
{
    public class ProjectResource
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public decimal FTE { get; set; }
        public decimal FTEAssigned { get; set; }
        public bool Active { get; set; }
    }

    public class ProjectResourceFTE
    {        
        public string EmployeeName { get; set; }
        public decimal FTE { get; set; }
        public decimal FTEConsumed { get; set; }
        public decimal FTEAvailable { get; set; }        
    }

    public class ProjectAndResourceModel
    {
        public List<ProjectResource> listResource { get; set; }
        public TeamProjectsModel teamProjectsModel { get; set; }
    }

    public class ResourceCalendar
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }
        public decimal FTEAssigned { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
