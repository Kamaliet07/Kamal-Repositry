﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TDRP.Areas.Lead.Models
{
    public class MyTeamProjectModel
    {
        public string Id { get; set; }
        public string ProjectName { get; set; }        
        public string TeamName { get; set; }
        public string ProjectCategory { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime StartDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime EndDate { get; set; }

        public bool Active { get; set; }
    }

    public class TeamProjectsModel
    {        
        public int Id { get; set; }

        [Required]
        [Display(Name = "Project Name")]
        [StringLength(100, ErrorMessage = "Name length cannot exceed 100 characters.")]
        public string ProjectName { get; set; }

        [Required]
        [Display(Name = "Project Description")]
        [StringLength(2000, ErrorMessage = "Project Description cannot exceed 2000 characters.")]
        public string ProjectDescription { get; set; }
       
        [Display(Name = "Team Id")]
        public int TeamId { get; set; }

        [Required]
        public string TeamName { get; set; }
        public decimal? EstimatedBudget { get; set; }
        
        public decimal? TotalExpenditure { get; set; }
        
        [Display(Name = "Project Category Id")]
        public int CategoryId { get; set; }

        [Required]
        public string ProjectCategory { get; set; }
        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }

        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Update By")]
        public string UpdateBy { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdateDate { get; set; }
    }
}
