﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using TDRP.DataModel;

namespace TDRP.Areas.Lead.Models
{

    public class EmployeesModel
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
    } 
    public class TeamResourceModel
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public decimal FTE { get; set; }
    }

    public class TeamResourcesModel
    {
        public Teams Teams { get; set; }
        public List<TeamResourceModel> TeamResourceModel { get; set; }
    }

    public class MyTeamResourceModel
    {
        public int Id { get; set; }
        public int ProjectAllocationId { get; set; }
        public string EmployeeName { get; set; }
        public string TeamName { get; set; }
        public string BusinessUniteName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreateDate { get; set; }
    }

}
