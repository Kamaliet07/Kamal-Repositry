﻿using AutoMapper;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using TDRP.Areas.Admin.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class EmployeeController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<EmployeeController> _logger;
        private readonly IMapper _mapper;

        public EmployeeController(IUnitOfWork unitOfWork, ILogger<EmployeeController> logger, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
        }

        public IActionResult Index()
        {
            try
            {
                var objEmpList = _unitOfWork.employeeRepository.GetAll().ToList();
                var objDto = new List<EmployeeModel>();
                foreach (var obj in objEmpList)
                {
                    objDto.Add(_mapper.Map<EmployeeModel>(obj));
                }
                return View(objDto);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public IActionResult Upsert(int id)
        {
            try
            {
                EmployeeModel employeeViewModel = null;
                if (id == 0)
                {
                    employeeViewModel = new EmployeeModel();
                }
                else
                {
                    var objEmp = _unitOfWork.employeeRepository.GetById(id);
                    employeeViewModel = new EmployeeModel();
                    employeeViewModel = _mapper.Map<EmployeeModel>(objEmp);
                }

                return View(employeeViewModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpPost]
        public IActionResult Upsert(EmployeeModel employeeViewModel)
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                Employees employees = null;

                if (ModelState.IsValid)
                {

                    if (employeeViewModel.Id == 0)
                    {
                        employees = new Employees()
                        {
                            EmployeeName = employeeViewModel.EmployeeName,
                            EmployeeNumber = employeeViewModel.EmployeeNumber,
                            Email = employeeViewModel.Email,
                            PhoneNumber = employeeViewModel.PhoneNumber,
                            Active = employeeViewModel.Active,
                            StartDate = employeeViewModel.StartDate,
                            EndDate = employeeViewModel.EndDate,
                            CreatedBy = loginuserId,
                            CreateDate = DateTime.Now
                        };

                        var obj = _unitOfWork.employeeRepository.GetFirstOrDefault(x => x.Email.ToUpper() == employees.Email.ToUpper());
                        if (obj == null)
                        {
                            _unitOfWork.employeeRepository.Add(employees);
                        }
                    }
                    else
                    {
                        employees = new Employees()
                        {
                            Id = employeeViewModel.Id,
                            EmployeeName = employeeViewModel.EmployeeName,
                            EmployeeNumber = employeeViewModel.EmployeeNumber,
                            Email = employeeViewModel.Email,
                            PhoneNumber = employeeViewModel.PhoneNumber,
                            Active = employeeViewModel.Active,
                            StartDate = employeeViewModel.StartDate,
                            EndDate = employeeViewModel.EndDate,
                            UpdateBy = loginuserId,
                            UpdateDate = DateTime.Now
                        };

                        _unitOfWork.employeeRepository.Update(employees);
                    }
                    _unitOfWork.Save();
                }

                return RedirectToAction(nameof(Index));

            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.employeeRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.employeeRepository.Remove(objFromDb);
                _unitOfWork.Save();
                //return RedirectToAction(nameof(Index));
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        [HttpGet]
        public IActionResult EmployeeJobRole(int id)
        {
            try
            {
                JobRoleModel jobRoleModel = null;
                EmployeeModel employeeViewModel = null;
                if (id != 0)
                {
                    // Get the Selected Employee Details
                    var objEmp = _unitOfWork.employeeRepository.GetById(id);
                    employeeViewModel = _mapper.Map<EmployeeModel>(objEmp);

                    // Get the Job Role Details of Selected Employee
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@EmpId", employeeViewModel.Id, DbType.Int32, ParameterDirection.Input);
                    List<JobRoleModel> model = _unitOfWork.spCall.ReturnList<JobRoleModel>(AppConstant.usp_GetEmployeeJobRole, param).Result.ToList();

                    // If Job Role details found in database for this employee
                    if (model.Count > 0)
                    {
                        jobRoleModel = model[0];
                    }
                    else
                    {
                        jobRoleModel = new JobRoleModel();
                    }
                }
                else
                {
                    jobRoleModel = new JobRoleModel();
                    employeeViewModel = new EmployeeModel();
                }


                EmployeeJobRoleModel employeeJobRoleModel = new EmployeeJobRoleModel()
                {
                    EmployeeViewModel = employeeViewModel,
                    JobRoleModel = jobRoleModel,
                };
                return View(employeeJobRoleModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public JsonResult GetContractTypes()
        {
            try
            {
                // Get the Selected Employee Details
                var objcontracts = _unitOfWork.contractTypeRepository.GetAll().Where(x => x.Active == true).ToList();

                return Json(new { success = true, data = objcontracts });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        [HttpGet]
        public JsonResult GetJobRoles()
        {
            try
            {
                // Get the Selected Employee Details
                var objJobRoles = _unitOfWork.jobRolesRepository.GetAll().Where(x => x.Active == true).ToList();

                return Json(new { success = true, data = objJobRoles });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="empId"></param>
        /// <param name="fte"></param>
        /// <param name="active"></param>
        /// <param name="preRroleId"></param>
        /// <param name="newRoleId"></param>
        /// <param name="preCtrId"></param>
        /// <param name="newContractId"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult SaveEmployeeJobRoles(int Id, int empId, decimal fte, bool active, int newRoleId, int newContractId, DateTime startdate, DateTime enddate)
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                if (Id == 0)
                {
                    EmployeeJobRole employeeJobRole = new EmployeeJobRole()
                    {
                        Id = Id,
                        EmployeeId = empId,
                        JobRoleId = newRoleId,
                        ContractTypeId = newContractId,
                        FTE = fte,
                        Active = active,
                        CreatedBy = loginuserId,
                        CreateDate = DateTime.Now,
                        StartDate = startdate,
                        EndDate = enddate,

                    };
                    _unitOfWork.employeeJobRoleRepository.Add(employeeJobRole);
                }
                else
                {
                    EmployeeJobRole employeeJobRole = new EmployeeJobRole()
                    {
                        Id = Id,
                        EmployeeId = empId,
                        JobRoleId = newRoleId,
                        ContractTypeId = newContractId,
                        FTE = fte,
                        Active = active,
                        StartDate = startdate,
                        EndDate = enddate,
                        Updateby = loginuserId,
                        UpdateDate = DateTime.Now,
                    };

                    _unitOfWork.employeeJobRoleRepository.Update(employeeJobRole);
                }
                _unitOfWork.Save();

                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        [HttpGet]
        public IActionResult EmployeeSkills(int id)
        {
            try
            {                
                return View();
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }
    }
}
