﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class JobRolesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<AccessControlController> _logger;

        public JobRolesController(IUnitOfWork unitOfWork,
            ILogger<AccessControlController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                List<JobRoles> objjobRoles = _unitOfWork.jobRolesRepository.GetAll().ToList();
                return View(objjobRoles);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        public IActionResult Upsert(int id)
        {
            try
            {
                JobRoles jobRoles = null;
                if (id == 0)
                {
                    jobRoles = new JobRoles();
                }
                else
                {
                    jobRoles = _unitOfWork.jobRolesRepository.GetById(id);
                }

                return View(jobRoles);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(JobRoles jobRoles)
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                jobRoles.CreatedBy = loginuser;
                jobRoles.CreatedDate = DateTime.Now;

                if (ModelState.IsValid)
                { 
                    if (jobRoles.Id == 0)
                    {
                        _unitOfWork.jobRolesRepository.Add(jobRoles);
                    }
                    else
                    {
                        _unitOfWork.jobRolesRepository.Update(jobRoles);
                    }
                    _unitOfWork.Save();

                    return RedirectToAction(nameof(Index));
                }

                return View(jobRoles);

            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.jobRolesRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.jobRolesRepository.Remove(objFromDb);
                _unitOfWork.Save();
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
