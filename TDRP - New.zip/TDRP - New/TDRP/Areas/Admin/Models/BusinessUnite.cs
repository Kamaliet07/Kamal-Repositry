﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using TDRP.DataModel;

namespace TDRP.Areas.Admin.Models
{
    public class BusinessOwner
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class BUTeamLead
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class BusinessUniteTable
    {
        public string Id { get; set; }
        public string BusinessUniteName { get; set; }
        public string BusinessUniteDetails { get; set; }
        public string OwnerID { get; set; }
        public string OwnerName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreatedDate { get; set; }
    }

    public class BusinessUniteModel
    {
        public BusinessUnite BusinessUnite { get; set; }
        public List<BusinessOwner> BusinessOwner { get; set; }        
    }

    public class BULeads
    {
        public BusinessUnite BusinessUnite { get; set; }
        public List<BUTeamLead> BUTeamLead { get; set; }
    }
}
