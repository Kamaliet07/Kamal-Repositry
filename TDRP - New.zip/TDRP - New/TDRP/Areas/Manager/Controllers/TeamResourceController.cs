﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using TDRP.Areas.Manager.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Manager.Controllers
{
    [Authorize]
    [Area("Manager")]
    public class TeamResourceController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<TeamResourceController> _logger;

        public TeamResourceController(IUnitOfWork unitOfWork, ILogger<TeamResourceController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                return View();
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public JsonResult GetMyBUTeamResource()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                DynamicParameters param = new DynamicParameters();
                param.Add("@Id", loginuserId, DbType.String, ParameterDirection.Input);
                List<MyBUResourceModel> teamResources = _unitOfWork.spCall.ReturnList<MyBUResourceModel>(AppConstant.usp_GetMyBUResources, param).Result.ToList();

                return Json(new { success = true, data = teamResources });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetResourceProjectAllocation(int empId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@EmpId", empId, DbType.Int16, ParameterDirection.Input);
                List<ResourceCalendar> projectResource = _unitOfWork.spCall.ReturnList<ResourceCalendar>(AppConstant.usp_GetResourceProjectCalendar, param).Result.ToList();

                return Json(new { success = true, data = projectResource });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetResourceCapicityUsed(int empId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@EmpId", empId, DbType.Int16, ParameterDirection.Input);
                List<ProjectResourceFTE> resourceSearch = _unitOfWork.spCall.ReturnList<ProjectResourceFTE>(AppConstant.usp_GetResourceFteAvailability, param).Result.ToList();
                //return Json(resourceSearch);
                return Json(new { success = true, data = resourceSearch });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        public IActionResult Upsert(int id)
        {
            try
            {
                List<BusinessUnite> businessUnite = null;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                businessUnite = _unitOfWork.businessUniteRepository.GetAll().Where(x => x.OwnerId == loginuserId).ToList();

                return View(businessUnite);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }            
        }

        [HttpGet]
        public JsonResult GetBusinessUnitTeams(int buId)
        {
            try
            {                
                List<Teams> team = _unitOfWork.teamRepository.GetAll().Where(x => x.BusinessUniteId == buId).ToList();

                return Json(new { success = true, data = team });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetTeamResourcesByTeamId(int teamId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@TeamId", teamId, DbType.Int32, ParameterDirection.Input);
                List<TeamResourceModel> teamResources = _unitOfWork.spCall.ReturnList<TeamResourceModel>(AppConstant.usp_GetTeamResourcesByTeamId, param).Result.ToList();
                return Json(new { success = true, data = teamResources });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult SearchResource(string search)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@namestr", search, DbType.String, ParameterDirection.Input);
                List<EmployeesSearchModel> resources = _unitOfWork.spCall.ReturnList<EmployeesSearchModel>(AppConstant.usp_SearchTeamResources, param).Result.ToList();
                return Json(resources);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpPost]
        public IActionResult AddResourceInTeam(int Id, int empId)
        {
            try
            {
                bool status = false;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;               

                if (empId != 0)
                {
                    if(!ResourceAlreadyExist(empId))
                    {
                        TeamResources teamResources = new TeamResources()
                        {
                            EmployeeId = empId,
                            TeamId = Id,
                            CreatedBy = loginuserId,
                            CreateDate = DateTime.Now
                        };

                        _unitOfWork.teamResourcesRepository.Add(teamResources);
                        _unitOfWork.Save();
                        status = true;
                    }                   
                }

                //return RedirectToAction(nameof(Index));
                return Json(new { success = status, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while Adding." });
            }
        }

        private bool ResourceAlreadyExist(int empId)
        {
            bool exist = false;
            List<TeamResources> buteamLeads = _unitOfWork.teamResourcesRepository.GetAll().Where(x => x.EmployeeId == empId).ToList();
            if (buteamLeads.Count > 0)
            {
                exist = true;
            }
            return exist;
        }

        [HttpDelete]
        public IActionResult DeleteResourceFromTeam(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.teamResourcesRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                
                // First remove project allocation in this team
                RemoveProjectAllocation(objFromDb.TeamId, objFromDb.EmployeeId);

                // Remove resource from team
                _unitOfWork.teamResourcesRepository.Remove(objFromDb);
                _unitOfWork.Save();

                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        private void RemoveProjectAllocation(int teamId, int empId)
        {
            DynamicParameters param = new DynamicParameters();
            param.Add("@teamId", teamId, DbType.Int32, ParameterDirection.Input);
            param.Add("@empId", empId, DbType.Int32, ParameterDirection.Input);
            _unitOfWork.spCall.ExecuteWithoutReturn(AppConstant.usp_RemoveProjectAllocation, param);
        }

        [HttpGet]
        public IActionResult CheckIfTeamActive(int teamId)
        {
            try
            {
                bool status = false;
                var objFromDb = _unitOfWork.teamRepository.GetById(teamId);
                if (objFromDb != null)
                {
                    status = objFromDb.Active;                                      
                } 

                return Json(new { success = status, message = "Team is not active." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Team is not active." });
            }
        }
    }
}
