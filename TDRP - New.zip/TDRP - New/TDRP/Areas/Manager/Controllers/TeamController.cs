﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.Areas.Manager.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Manager.Controllers
{
    [Authorize]
    [Area("Manager")]
    public class TeamController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<TeamController> _logger;

        [BindProperty]
        public TeamUpsertModel teamupsertModel { get; set; }

        public TeamController(IUnitOfWork unitOfWork, ILogger<TeamController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Get the list of teams Under the Manager
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetManagerTeam()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                DynamicParameters param = new DynamicParameters();
                param.Add("@MgrId", loginuserId, DbType.String, ParameterDirection.Input);
                List<TeamDetailModel> teamDetails = _unitOfWork.spCall.ReturnList<TeamDetailModel>(AppConstant.usp_GetTeams, param).Result.ToList();
               
                return Json(new { data = teamDetails });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        /// <summary>
        /// Add or fetch Team
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IActionResult Upsert(int id)
        {
            try
            {
                Teams teams = null;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                if (id == 0)
                {
                    teams = new Teams();
                }
                else
                {
                    teams = _unitOfWork.teamRepository.GetById(id);
                }

                teamupsertModel = new TeamUpsertModel()
                {
                    Teams = teams,
                    BusinessUnite = _unitOfWork.businessUniteRepository.GetAll().Where(x => x.OwnerId == loginuserId).ToList(),
                };

                return View(teamupsertModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        /// <summary>
        /// Update Teams Details
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="teamName"></param>
        /// <param name="teamDesc"></param>
        /// <param name="active"></param>
        /// <param name="buId"></param>
        /// <param name="teamleadid"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Upsert(int Id, string teamName, string teamDesc, bool active, int buid, string leadid)
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                Teams teams = null;

                if (ModelState.IsValid)
                {
                    teams = new Teams()
                    {
                        Id = Id,
                        TeamName = teamName,
                        TeamDetails = teamDesc,
                        Active = active,
                        BusinessUniteId = buid,
                        TeamLeadId = leadid,
                        CreatedBy = loginuserId,
                        CreatedDate = DateTime.Now
                    };

                    if (Id == 0)
                    {
                        _unitOfWork.teamRepository.Add(teams);
                    }
                    else
                    {
                        _unitOfWork.teamRepository.Update(teams);
                    }
                    _unitOfWork.Save();
                }

                //return RedirectToAction(nameof(Index));
                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        /// <summary>
        /// Delete Team
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.teamRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.teamRepository.Remove(objFromDb);
                _unitOfWork.Save();
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        [HttpGet]
        public JsonResult GetBusinessUniteLeads(int buId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@buId", buId, DbType.Int32, ParameterDirection.Input);
                param.Add("@role", AppConstant.Lead, DbType.String, ParameterDirection.Input);
                List<TeamLead> teamLead = _unitOfWork.spCall.ReturnList<TeamLead>(AppConstant.usp_GetUsersWithSpecificRole, param).Result.ToList();

                return Json(new { success = true, data = teamLead });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }
    }
}
