﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using TDRP.Areas.Manager.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Manager.Controllers
{
    [Authorize]
    [Area("Manager")]
    public class ProjectControlController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<ProjectControlController> _logger;

        [BindProperty]
        public TeamProjectAddModel TeamProjectAddModel { get; set; }
        public TeamProjectUpdateModel TeamProjectUpdateModel { get; set; }

        public ProjectControlController(IUnitOfWork unitOfWork, ILogger<ProjectControlController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                DynamicParameters param = new DynamicParameters();
                param.Add("@Id", loginuserId, DbType.String, ParameterDirection.Input);
                List<ProjectControlModel> projectModel = _unitOfWork.spCall.ReturnList<ProjectControlModel>(AppConstant.usp_GetAllManagerTeamProjects, param).Result.ToList();

                return View(projectModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        } 

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                if (DeleteResourceAllocation(id))
                {
                    var objFromDb = _unitOfWork.teamProjectsRepository.GetById(id);
                    if (objFromDb == null)
                    {
                        return Json(new { success = false, message = "Error while deleting." });
                    }
                    _unitOfWork.teamProjectsRepository.Remove(objFromDb);
                    _unitOfWork.Save();
                    return Json(new { success = true, message = "Delete success." });
                }
                return Json(new { success = false, message = "Error while deleting." });               
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        private bool DeleteResourceAllocation(int projectid)
        {
            bool value = false;
            DynamicParameters param = new DynamicParameters();
            param.Add("@ProjId", projectid, DbType.Int32, ParameterDirection.Input);
            param.Add("@Count", projectid, DbType.Int32, ParameterDirection.Output);
            int count = _unitOfWork.spCall.ExecuteWithReturnAsync(AppConstant.usp_DeleteResourceAllocation, param).Result;
            if (count > 0)
            {
                value = true;
            }

            return value;
        }

        public IActionResult AddProject()
        {
            try
            {                
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                TeamProjectAddModel = new TeamProjectAddModel()
                {
                    TeamProjectsModel = new TeamProjectsModel(),
                    BusinessUnite = _unitOfWork.businessUniteRepository.GetAll().Where(x => x.OwnerId == loginuserId).ToList(),
                    ProjectCategory = _unitOfWork.projectCategoryRepository.GetAll().Where(x => x.Active == true).ToList(),
                };

                return View(TeamProjectAddModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddProject(TeamProjectsModel teamProjectsmodel)
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                TeamProjects teamProjects = null;

                if (ModelState.IsValid)
                {
                    if (teamProjectsmodel.Id == 0)
                    {
                        teamProjects = new TeamProjects()
                        {
                            ProjectName = teamProjectsmodel.ProjectName,
                            ProjectDescription = teamProjectsmodel.ProjectDescription,
                            TeamId = teamProjectsmodel.TeamId,
                            EstimatedBudget = teamProjectsmodel.EstimatedBudget,
                            TotalExpenditure = teamProjectsmodel.TotalExpenditure,
                            CategoryId = teamProjectsmodel.CategoryId,
                            Active = teamProjectsmodel.Active,
                            StartDate = teamProjectsmodel.StartDate,
                            EndDate = teamProjectsmodel.EndDate,
                            CreatedBy = loginuser,
                            CreateDate = DateTime.Now
                        };

                        _unitOfWork.teamProjectsRepository.Add(teamProjects);
                        _unitOfWork.Save();
                    } 
                }

                return RedirectToAction(nameof(Index));

            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }



        [HttpGet]
        public JsonResult GetBusinessUnitTeams(int buId)
        {
            try
            {
                List<Teams> team = _unitOfWork.teamRepository.GetAll().Where(x => x.BusinessUniteId == buId).ToList();

                return Json(new { success = true, data = team });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        public IActionResult UpdateProject(int id)
        {
            try
            {
                TeamProjectsModel teamProjects = null;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                if (id == 0)
                {
                    teamProjects = new TeamProjectsModel();
                }
                else
                {
                    var objTeamProj = _unitOfWork.teamProjectsRepository.GetById(id);
                    teamProjects = new TeamProjectsModel()
                    {
                        Id = objTeamProj.Id,
                        ProjectName = objTeamProj.ProjectName,
                        ProjectDescription = objTeamProj.ProjectDescription,
                        TeamId = objTeamProj.TeamId,
                        EstimatedBudget = objTeamProj.EstimatedBudget,
                        TotalExpenditure = objTeamProj.TotalExpenditure,
                        CategoryId = objTeamProj.CategoryId,
                        Active = objTeamProj.Active,
                        StartDate = objTeamProj.StartDate,
                        EndDate = objTeamProj.EndDate
                    };
                    teamProjects.ProjectCategory = _unitOfWork.projectCategoryRepository.GetById(objTeamProj.CategoryId).Name;
                    teamProjects.TeamName = _unitOfWork.teamRepository.GetById(objTeamProj.TeamId).TeamName;
                }

                int buId = _unitOfWork.teamRepository.GetById(teamProjects.TeamId).BusinessUniteId;

                TeamProjectUpdateModel = new TeamProjectUpdateModel()
                {
                    TeamProjectsModel = teamProjects,
                    BusinessUnite = _unitOfWork.businessUniteRepository.GetById(buId),
                    ProjectCategory = _unitOfWork.projectCategoryRepository.GetAll().Where(x => x.Active == true).ToList(),                    
                };

                return View(TeamProjectUpdateModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateProject(TeamProjectsModel teamProjectsmodel)
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                TeamProjects teamProjects = null;

                if (ModelState.IsValid)
                {
                    // Update the allocation status of this project to resource.
                    UpdateStatusOfResourceAllocatedInProject(teamProjectsmodel.Id, teamProjectsmodel.Active, teamProjectsmodel.StartDate, teamProjectsmodel.EndDate);

                    teamProjects = new TeamProjects()
                    {
                        Id = teamProjectsmodel.Id,
                        ProjectName = teamProjectsmodel.ProjectName,
                        ProjectDescription = teamProjectsmodel.ProjectDescription,
                        TeamId = teamProjectsmodel.TeamId,
                        EstimatedBudget = teamProjectsmodel.EstimatedBudget,
                        TotalExpenditure = teamProjectsmodel.TotalExpenditure,
                        CategoryId = teamProjectsmodel.CategoryId,
                        Active = teamProjectsmodel.Active,
                        StartDate = teamProjectsmodel.StartDate,
                        EndDate = teamProjectsmodel.EndDate,
                        UpdateBy = loginuser,
                        UpdateDate = DateTime.Now
                    };
                    _unitOfWork.teamProjectsRepository.Update(teamProjects);

                    _unitOfWork.Save();                    
                }

                return RedirectToAction(nameof(Index));

            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        private bool UpdateStatusOfResourceAllocatedInProject(int id, bool active, DateTime? startDate, DateTime? endDate)
        {
            DynamicParameters param = new DynamicParameters();
            param.Add("@ProjId", id, DbType.Int32, ParameterDirection.Input);
            param.Add("@Active", active, DbType.Boolean, ParameterDirection.Input);
            param.Add("@StartDate", startDate, DbType.Date, ParameterDirection.Input);
            param.Add("@EndDate", endDate, DbType.Date, ParameterDirection.Input);
            _unitOfWork.spCall.ExecuteWithoutReturn(AppConstant.usp_UpdateProjectAllocationActiveStatus, param);
            return true;
        }
    }
}
