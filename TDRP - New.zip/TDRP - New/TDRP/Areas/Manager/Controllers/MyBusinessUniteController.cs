﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using TDRP.Areas.Manager.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Manager.Controllers
{
    [Authorize]
    [Area("Manager")]
    public class MyBusinessUniteController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<MyBusinessUniteController> _logger;

        public MyBusinessUniteController(IUnitOfWork unitOfWork, ILogger<MyBusinessUniteController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetBusinessUnites()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                List<BusinessUniteViewModel> objbusinessUnite = _unitOfWork.spCall.ReturnList<BusinessUniteViewModel>(AppConstant.usp_GetBusinessUniteDetails).Result.Where(x => x.OwnerID == loginuserId).ToList();
                return Json(new { data = objbusinessUnite });               
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }            
        }

        public IActionResult Upsert(int id)
        {
            BusinessUnite businessUnite = null;
            if (id == 0)
            {
                businessUnite = new BusinessUnite();
            }
            else
            {
                businessUnite = _unitOfWork.businessUniteRepository.GetById(id);
            }            

            return View(businessUnite);
        }

        [HttpPost]
        public IActionResult Upsert(int Id, string uniteName, string uniteDesc, bool active)
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                BusinessUnite businessUnite = null;

                if (ModelState.IsValid)
                {
                    businessUnite = new BusinessUnite()
                    {
                        Id = Id,
                        BusinessUniteName = uniteName,
                        BusinessUniteDetails = uniteDesc,
                        Active = active,
                        OwnerId = loginuserId,
                        UpdateBy = loginuserId,
                        UpdatedDate = DateTime.Now
                    };

                    _unitOfWork.businessUniteRepository.Update(businessUnite);
                    _unitOfWork.Save();
                }
                
                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        /// <summary>
        /// Method to fetch the Model of BUManagers to bind BUManagers.chtml controls 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public IActionResult AddLeads(int id)
        {
            BusinessUnite businessUnite = null;
            if (id == 0)
            {
                businessUnite = new BusinessUnite();
            }
            else
            {
                businessUnite = _unitOfWork.businessUniteRepository.GetById(id);
            }

            DynamicParameters param = new DynamicParameters();
            param.Add("@Id", id, DbType.String, ParameterDirection.Input);
            List<BUTeamLeadModel> teamLeads = _unitOfWork.spCall.ReturnList<BUTeamLeadModel>(AppConstant.usp_GetBusinessUniteLeads, param).Result.ToList();

            BULeadsModel buManagers = new BULeadsModel()
            {
                BusinessUnite = businessUnite,
                BUTeamLead = teamLeads,
            };

            return View(buManagers);
        }

        /// <summary>
        /// Method for Autocomplete functionality
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetBuLead(string search)
        {
            DynamicParameters param = new DynamicParameters();
            param.Add("@namestr", search, DbType.String, ParameterDirection.Input);
            List<BUTeamLeadModel> buteamLeads = _unitOfWork.spCall.ReturnList<BUTeamLeadModel>(AppConstant.usp_SearchBusinessUniteLeads, param).Result.ToList();
            return Json(buteamLeads);
        }

        [HttpPost]
        public IActionResult AddBULeads(int Id, string leadsId)
        {
            try
            {
                bool status = false;
                string msg = string.Empty;
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                BusinessUniteLeads businessUnite = new BusinessUniteLeads()
                {
                    BusinessUniteId = Id,
                    LeadsId = leadsId,
                    CreatedBy = loginuserId,
                    CreatedDate = DateTime.Now
                };

                if (!string.IsNullOrEmpty(leadsId))
                {
                    if(!CheckIfLeadAlreadyAdded(Id, leadsId))
                    {
                        _unitOfWork.buLeadsRepository.Add(businessUnite);
                        _unitOfWork.Save();
                        status = true;                        
                    }
                    else
                    {
                        status = false;                        
                    }
                }

                //return RedirectToAction(nameof(Index));
                return Json(new { success = status, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while Adding." });
            }
        }

        private bool CheckIfLeadAlreadyAdded(int id, string leadsId)
        {
            bool exist = false;
            List<BusinessUniteLeads> buteamLeads = _unitOfWork.buLeadsRepository.GetAll().Where(x => x.BusinessUniteId == id &&  x.LeadsId == leadsId).ToList();            
            if(buteamLeads.Count > 0)
            {
                exist = true;
            }
            return exist;
        }

        [HttpDelete]
        public IActionResult DeleteBULead(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.buLeadsRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.buLeadsRepository.Remove(objFromDb);
                _unitOfWork.Save();

                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
