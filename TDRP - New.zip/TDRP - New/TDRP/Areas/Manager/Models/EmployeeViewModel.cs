﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TDRP.Areas.Manager.Models
{
    public class MyBUResourceModel
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
        public string TeamName { get; set; }
        public string BusinessUniteName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreateDate { get; set; }
    }

    public class ProjectResourceFTE
    {
        public string EmployeeName { get; set; }
        public decimal FTE { get; set; }
        public decimal FTEConsumed { get; set; }
        public decimal FTEAvailable { get; set; }
    }

    public class ResourceCalendar
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }
        public decimal FTEAssigned { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
