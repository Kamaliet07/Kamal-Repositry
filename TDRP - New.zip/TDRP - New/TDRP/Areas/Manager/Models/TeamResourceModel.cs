﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TDRP.Areas.Manager.Models
{
    public class TeamResourceModel
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
        public string TeamName { get; set; }
        public string BusinessUniteName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreateDate { get; set; }
    }

    public class EmployeesSearchModel
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
    }
}
