﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using TDRP.DataModel;

namespace TDRP.Areas.Manager.Models
{
    public class TeamLead
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class TeamDetailModel
    {
        public int Id { get; set; }
        public string TeamName { get; set; }
        public string TeamDetails { get; set; }
        public string BusinessUniteName { get; set; }
        public string TeamLead { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreatedDate { get; set; }

    }

    public class TeamUpsertModel
    {
        public Teams Teams { get; set; }
        public List<BusinessUnite> BusinessUnite { get; set; }
    }
}
