﻿using AutoMapper;
using TDRP.Areas.Admin.Models;
using TDRP.DataModel;

namespace TDRP.Models
{
    public class ModelMappings : Profile
    {
        public ModelMappings()
        {            
            CreateMap<Employees, EmployeeModel>().ReverseMap();
        }
    }
}
