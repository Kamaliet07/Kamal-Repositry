﻿var dataTable;

$(document).ready(function () {
    $("#tblresourceproj").hide();
    loadEmptyCalender();
});

$("#tblview").click(function () {
    $("#clndresourceproj").hide();
    $("#tblresourceproj").show();
    var resourceId = $('#hdnResourceId').val();
    if (resourceId > 0) {
        loadTeamsProjectsTable(resourceId);
    }
});

$("#clndrview").click(function () {
    $("#tblresourceproj").hide();
    $("#clndresourceproj").show();
});

$(function () {
    $('#tblmyResource').DataTable({
        'paging': true,
        'pageLength': 10,
        'lengthChange': false,
        'searching': false,
        'ordering': true,
        'info': false,
        'autoWidth': false
    });
});

$('#tblmyResource').on('click', 'tbody tr', function (event) {
    $(this).addClass('highlight').siblings().removeClass('highlight');
});

function loadEmptyCalender() {
    var Calendar = FullCalendar.Calendar;
    var calendarEl = document.getElementById('calendar');
    var calendar = new Calendar(calendarEl, {
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        themeSystem: 'bootstrap',
        //Random default events
        events: [
                        
        ],
        editable: false,     
    });

    calendar.render();
}

function loadResourceCalendar(empId) {
    $("#tblresourceproj").hide();
    $("#clndresourceproj").show();
    $('#hdnResourceId').val(empId);
    var eventsarray = [];
    $.ajax({
        url: '/Lead/ResourceCalendar/GetResourceProjectCalendar',
        type: "GET",
        dataType: "JSON",
        data: { empId: empId },
        success: function (result) {
            if (result.data.length > 0) {
                var colorArray = ['#f39c12', "#669933", "#03d3fc", "#3399FF", "#a103fc", "#fc03c2", '#f56954'];
                for (var i = 0; i < result.data.length; i++) {
                    eventsarray.push(
                        {
                            title: result.data[i].projectName + ': ' + result.data[i].fteAssigned + ' Hours per week',
                            start: moment(result.data[i].startDate).format("yyyy-MM-DD"),
                            end: moment(result.data[i].endDate).format("yyyy-MM-DD"),
                            backgroundColor: colorArray[i]
                        });
                };
            }           

            if (calendar) calendar.destroy();
            var Calendar = FullCalendar.Calendar;
            var calendarEl = document.getElementById('calendar');
            var calendar = new Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                themeSystem: 'bootstrap',

                events: eventsarray,

                editable: false
            });

            calendar.render();
        }
    });    
}

function loadTeamsProjectsTable(resourceId) {
    dataTable = $("#tblResourceProject").DataTable({
        destroy: true,
        "ajax": {
            "url": "/Lead/ResourceCalendar/GetResourceProjectCalendar",
            "dataType": "json",
            "type": "GET",
            "data": { "empId": resourceId }
        },
        "columns": [
            { "data": "projectName", "title": "Project Name", "width": "30%" },            
            { "data": "fteAssigned", "title": "FTE", "width": "10%" },
            {
                "data": "startDate", "title": "Start Date", "width": "20%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Start date not found.</p>";
                    }
                }
            },
            {
                "data": "endDate", "title": "End Date", "width": "20%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Start date not found.</p>";
                    }
                }
            },
        ],

        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}