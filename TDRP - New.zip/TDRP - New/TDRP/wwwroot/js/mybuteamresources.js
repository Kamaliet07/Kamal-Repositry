﻿var dataTableAssignedProjects;
var dataTableProjects;

function projectallocation(d) {
    return '<div class="row"><div class="col-md-8"><table id="childtb_' + d.id + '" class="table table-bordered table-striped"></table></div><div class="col-md-4"><canvas id="donutChart_' + d.id + '" height="202px"></canvas ></div></div>';
}

$(document).ready(function () {

    var table = $("#tblmybuteamResource").DataTable({
        'paging': true,
        'pageLength': 10,
        'lengthChange': false,
        'searching': false,
        'ordering': true,
        'info': false,
        'autoWidth': false,
        "ajax": {
            "url": "/Manager/TeamResource/GetMyBUTeamResource",
            "type": "GET",
            "dataType": "json"
        },
        "columns": [
            {
                "className": "details-control",
                "orderable": false,
                "data": null,
                "defaultContent": " ",
                "width": "5%"
            },
            { "data": "employeeName", "title": "Employee Name", "width": "25%" },
            { "data": "teamName", "title": "Team Name", "width": "20%" },
            { "data": "businessUniteName", "title": "Business Unit", "width": "25%" },
            {
                "data": "createDate", "title": "Added On", "width": "20%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Create date not found.</p>";
                    }
                }
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
    // Add event listener for opening and closing details
    $('#tblmybuteamResource tbody').on('click', 'td.details-control', function () {
        var tr = $(this).closest('tr');
        var row = table.row(tr);

        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }
        else {
            // Open this row (the format() function would return the data to be shown)
            if (row.child() && row.child().length) {
                row.child.show();
            }
            else {
                var empid = row.data().id;
                row.child(projectallocation(row.data())).show();
                // Load Details of project Assigned
                GetProjectsAllocation(empid);
            }
            tr.addClass('shown');
        }
    });

    // 
    $("select#EmploymentType").change(function () {
        newEmployeeType = $(this).children("option:selected").val();
    });
});

function GetProjectsAllocation(empNo) {
    LoadProjectAllocationTable(empNo);
    LoadCapacityUserChart(empNo);
}

function LoadProjectAllocationTable(empNo) {
    dataTableAssignedProjects = $('#childtb_' + empNo).DataTable({
        'paging': true,
        'pageLength': 5,
        'lengthChange': false,
        'searching': false,
        'ordering': true,
        'info': false,
        'autoWidth': false,
        "ajax": {
            "url": "/Manager/TeamResource/GetResourceProjectAllocation",
            "dataType": "json",
            "type": "GET",
            "data": { "empId": empNo }
        },
        "columns": [
            { "data": "projectName", "title": "Project Name", "width": "30%" },
            { "data": "fteAssigned", "title": "Hrs/Week", "width": "20%" },
            {
                "data": "startDate", "title": "Start Date", "width": "25%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Start date not found.</p>";
                    }
                }
            },
            {
                "data": "endDate", "title": "End Date", "width": "25%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>End date not found.</p>";
                    }
                }
            }
        ],

        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function LoadCapacityUserChart(empNo) {
    // Get the selected month allocation
    var total = null;
    total = GetCapacityUsed(empNo);
    donutChartCanvas = $('#donutChart_' + empNo).get(0).getContext('2d');
    var donutData = {
        labels: [
            'Capacity Used',
            'Capacity Spare'
        ],
        datasets: [
            {
                data: [total[0].fteConsumed, total[0].fteAvailable],
                backgroundColor: ['#39CCCC', '#d2d6de']
            }
        ]
    }
    var donutOptions = {
        maintainAspectRatio: false,
        responsive: true
    }
    donutChart = new Chart(donutChartCanvas,
        {
            type: 'doughnut',
            data: donutData,
            options: donutOptions
        });
}

function GetCapacityUsed(empNo) {
    var totalFTE = 0;
    $.ajax({
        async: false,
        url: '/Manager/TeamResource/GetResourceCapicityUsed',
        data: { empId: empNo },
        type: "GET",
        success: function (result) {
            totalFTE = result.data;
        }
    });
    return totalFTE;
}