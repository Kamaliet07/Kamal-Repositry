﻿$(document).ready(function () {
    $("#projCatDiv").hide();   
    loadProjectCategory();
});

$(function () {
    $("#tblteamProjects").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblteamProjects_wrapper .col-md-6:eq(0)');
});

function ActiveProject(Id) {
    var text = null;
    var active = document.getElementById("chk_"+Id).checked;
    if (active) {
        text = "Are you sure to activate this project?";
    }
    else {
        text = "Are you sure to deactivate this project?";
    }
    swal({
        title: "Project Activation?",
        text: text,
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                async: false,
                url: '/Manager/ProjectControl/ActivateProject',
                data: { Id: Id, active: active },
                type: "POST",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);                        
                    }
                    else {
                        swal({
                            title: "Error Occurred! Try again.",
                            type: "warning"
                        });
                    }
                }
            });
        }
        else {
            document.getElementById("chk_" + Id).checked = !active;
        };
    });
}

function deleteProject(Id) {
    swal({
        title: "Delete Skill?",
        text: "This action cannot be reverted, are you sure you want to remove this Project Parmanently?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Manager/ProjectControl/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Project not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Unite not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function changeddlBU(obj) {

    var ddlbuTeam = $("#ddlBuTeam");
    ddlbuTeam.empty().append('<option selected="selected" value="0" disabled = "disabled">Loading.....</option>');
    var buId = obj.options[obj.selectedIndex].value;
    $("#hdnbuId").val(buId);
    if (buId != 0) {
        $.ajax({
            url: '/Manager/ProjectControl/GetBusinessUnitTeams',
            dataType: "json",
            data: { "buId": buId },
            type: "GET",
            success: function (data) {
                var dataOptions = "";
                dataOptions += '<option selected="selected" value="0">--Please Select Team--</option>';
                for (var i = 0; i < data.data.length; i++) {
                    dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].teamName + '</option>';
                }
                ddlbuTeam.html(dataOptions);
            },
            failure: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            },
            error: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        });
    }
}

function changeddlTeams(obj) {

    var teamId = obj.options[obj.selectedIndex].value;
    var text = obj.options[obj.selectedIndex].text;
    $("#hdnteamId").val(teamId);
    $("#hdnTeamName").val(text);
}

$("#enbCat").click(function () {
    $("#projCatDiv").show();    
});

$("#hideCat").click(function () {
    $("#projCatDiv").hide();
});


$("#sltProjCategory").change(function () {
    var catId = $("#sltProjCategory").val();
    var cattext = $("#sltProjCategory").children("option:selected").text();
    $("#hdnCategoryId").val(catId);
    $("#lblCatname").val(cattext);
});