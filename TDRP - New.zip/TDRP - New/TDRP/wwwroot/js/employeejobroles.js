﻿$(document).ready(function () {
    $("#contractDiv").hide();
    $("#roleDiv").hide();
    var assbuId = $("#hdnJREmpID").val();    
    if (assbuId != 0) {
        loadJobRoles();
        loadContractType();        
    }
});

$("#enbRole").click(function () {
    $("#roleDiv").show();
});

$("#enbContract").click(function () {
    $("#contractDiv").show();
});

$("#hideRole").click(function () {
    $("#roleDiv").hide();
});

$("#hideContract").click(function () {
    $("#contractDiv").hide();
});


function loadContractType() {
    var ddlContractType = $("#sltContractType");
    $.ajax({
        url: '/Admin/Employee/GetContractTypes',
        dataType: "json",
        type: "GET",
        success: function (data) {
            if (data.success == true) {
                var dataOptions = "";
                dataOptions += '<option selected="selected" value="0">--Please Select Contract Type--</option>';
                for (var i = 0; i < data.data.length; i++) {
                    dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].contractType + '</option>';
                }
                ddlContractType.html(dataOptions);
            }           
        },
        failure: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        },
        error: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        }
    });
}

function loadJobRoles() {
    var ddlJobRoles = $("#sltJobRoles");
    $.ajax({
        url: '/Admin/Employee/GetJobRoles',
        dataType: "json",
        type: "GET",
        success: function (data) {
            if (data.success == true) {
                var dataOptions = "";
                dataOptions += '<option selected="selected" value="0">--Please Select Role--</option>';
                for (var i = 0; i < data.data.length; i++) {
                    dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].jobRole + '</option>';
                }
                ddlJobRoles.html(dataOptions);
            }
        },
        failure: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        },
        error: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        }
    });
}

function submitJobRoles() {    
    var Id = $("#hdnID").val();
    var empId = $("#hdnJREmpID").val();
    var txtfte = $("#txtFTE").val();
    var startdt = $("#txtStartdate").val();
    var enddt = $("#txtEnddate").val();
    var jobroleId = $("#hdnJRId").val();
    var ContrId = $("#hdnContrId").val();
    var active = document.getElementById("chkActive").checked;    
    var e = document.getElementById("sltJobRoles");
    var roleid = e.value;    
    var ctr = document.getElementById("sltContractType");
    var contractid = ctr.value;
    if (roleid == 0) {
        if (jobroleId == 0) {
            swal({
                title: "Job Roles",
                text: "Please Select the New Job Role?",
                type: "warning"
            });
            return false;
        }
        else {
            roleid = jobroleId;
        }
    }
    if (contractid == 0) {
        if (ContrId == 0) {
            swal({
                title: "Contract Type",
                text: "Please Select the Contract Type",
                type: "warning"
            });
            return false;
        }
        else {
            contractid = ContrId;
        }
    }   
    
    $.ajax({
        async: false,
        url: '/Admin/Employee/SaveEmployeeJobRoles',
        data: { Id: Id, empId: empId, fte: txtfte, active: active, newRoleId: roleid, newContractId: contractid, startdate: startdt, enddate: enddt },
        type: "POST",
        success: function (data) {
            if (data.success) {
                window.location.reload(true);
            }
            else {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        }
    });
}
