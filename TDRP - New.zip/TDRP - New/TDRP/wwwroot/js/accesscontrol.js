﻿$(document).ready(function () {
    $("#empNumbDiv").hide();    
});

$("#editempnumb").click(function () {
    $("#empNumbDiv").show();
});

$("#hideEmpNum").click(function () {
    $("#empNumbDiv").hide();
});

function upsertAccess() {
    var roletext = "";
    var userId = $("#hdnId").val();
    var unumber = $("#lblEmpNumber").val();
    var prevRole = $("#prevRole").val();
    var active = document.getElementById("chkActive").checked;
    var e = document.getElementById("ddlroles");
    var roleid = e.value;
    if (roleid == 0) {
        roletext = prevRole;
    }
    else {
        roletext = e.options[e.selectedIndex].text;
    }      
    $.ajax({
        async: false,
        url: '/Admin/AccessControl/UpdateUserPermission',
        data: { Id: userId, active: active, role: roletext, prevRole: prevRole, empNumber: unumber },
        type: "POST",
        success: function (data) {
            if (data.success) {
                window.location.href = '/Admin/AccessControl';
            }
            else {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        }
    });
}

function deleteRegisterUser(Id) {    
    swal({
        title: "Delete User?",
        text: "This action cannot be reverted, are you sure you want to remove this User?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/AccessControl/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "User not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "User not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function addPermission() {
    var addPerm = $("#txtPermission").val();
    var chkAgree = document.getElementById("chkAgreePer").checked;
    if (chkAgree == false) {
        swal({
            title: "Aggrement",
            text: "Please agree on term and condition?",
            type: "warning"
        });
        return false;
    }
    else if (addPerm == null) {
        swal({
            title: "Permission",
            text: "Please add New Permission",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Admin/AccessControl/AddNewPermission',
            data: { permission: addPerm },
            type: "POST",
            success: function (data) {
                if (data.success) {
                    window.location.href = '/Admin/AccessControl';
                }
                else {
                    swal({
                        title: "Error",
                        text: data.message,
                        type: "warning"
                    });
                    return false;                    
                }
            }
        });
    }
}

$(function () {
    $("#tblAccess").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblAccess_wrapper .col-md-6:eq(0)');
});
