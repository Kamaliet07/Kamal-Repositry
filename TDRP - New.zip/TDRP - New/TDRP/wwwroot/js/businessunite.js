﻿$(document).ready(function () {
    loadBusinessUnites();    
});

function loadBusinessUnites() {
    $('#tblBusinessUnite').DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"],
        "ajax": {
            "url": "/Admin/BusinessUnite/GetBusinessUnites",
            "type": "GET",
            "dataType": "json"
        },
        "columnDefs": [
            { "className": "dt-center", "targets": "_all" }
        ],
        "columns": [ 
            { "data": "businessUniteName", "title": "Business Unite", "width": "25%" },
            { "data": "businessUniteDetails", "title": "Unite Details", "width": "40%" },
            { "data": "ownerName", "title": "Unite Owner", "width": "20%"},
            {
                "data": "id",
                "title": "Action",
                "render": function (data) {
                    return `<div>
                                <a href="/Admin/BusinessUnite/Upsert/${data}" class="btn btn-box-tool" style='cursor:pointer;'>
                                    <i class="fas fa-edit"></i></a>
                                &nbsp;
                                <a onclick= DeleteUnite(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class="fas fa-trash-alt"></i> </a>
                            </div>
                            `;
                }, "width": "15%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    })
};


function upsertBusinessUnite() {
    var uniteId = $("#hdnId").val();
    var uniteName = $("#txtuniteName").val();
    var uniteDesc = $("#txtdesc").val();
    var active = document.getElementById("chkActive").checked;
    var e = document.getElementById("ddlowner");
    var ownerid = e.value;    
    if (ownerid == 0 || uniteName == null || uniteDesc == null || active == false) {
        swal({
            title: "Active Status",
            text: "All fields are mandatory!",
            type: "warning"
        });
        return false;
    }    
    else {
        $.ajax({
            async: false,
            url: '/Admin/BusinessUnite/UpsertBusinessUnite',
            data: { Id: uniteId, uniteName: uniteName, uniteDesc: uniteDesc, active: active, ownerid: ownerid},
            type: "POST",
            success: function (data) {
                if (data.success) {                    
                    window.location.href = '/Admin/BusinessUnite';
                }
                else {
                    toastr.error(data.message);
                }
            }
        });
    }
}

function DeleteUnite(Id) {
    swal({
        title: "Delete Business Unite?",
        text: "This action cannot be reverted, are you sure you want to remove this unite?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/BusinessUnite/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Unite not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Unite not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}







