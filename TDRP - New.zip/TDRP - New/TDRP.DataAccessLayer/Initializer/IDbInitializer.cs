﻿namespace TDRP.DataAccessLayer.Initializer
{
    /// <summary>
    /// DB Initializer to Initialise the Database initial roles and Admin User
    /// </summary>
    public interface IDbInitializer
    {
        void Initialize();
    }
}
