﻿using System;
using TDRP.BusinessLayer.Repository.IRepository;

namespace TDRP.BusinessLayer.RepositoryUnit
{
    public interface IUnitOfWork : IDisposable
    {
        IBusinessUniteRepository businessUniteRepository { get; }

        IJobRolesRepository jobRolesRepository { get; }

        IProjectCategoryRepository projectCategoryRepository { get; }

        ISkillRepository skillRepository { get; }

        IStoreProcedureCall spCall { get; }

        ITeamRepository teamRepository { get; }

        IBULeadsRepository buLeadsRepository { get; }

        IEmployeesRepository employeeRepository { get; }

        IEmployeeJobRoleRepository employeeJobRoleRepository { get; }

        IEmployeeSkillsRepository employeeSkillsRepository { get; }

        ITeamResourcesRepository teamResourcesRepository { get; }

        IContractTypeRepository contractTypeRepository { get; }

        ITeamProjectsRepository teamProjectsRepository { get; }

        IProjectAllocationRepository projectAllocationRepository { get; }

        void Save();
    }
}
