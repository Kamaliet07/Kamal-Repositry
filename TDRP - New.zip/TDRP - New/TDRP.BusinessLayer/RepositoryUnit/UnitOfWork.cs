﻿using TDRP.BusinessLayer.Repository;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;

namespace TDRP.BusinessLayer.RepositoryUnit
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _dbcontext;

        public IBusinessUniteRepository businessUniteRepository { get; private set; }
        public IJobRolesRepository jobRolesRepository { get; private set; }

        public IProjectCategoryRepository projectCategoryRepository { get; private set; }

        public ISkillRepository skillRepository { get; private set; }

        public IStoreProcedureCall spCall { get; private set; }

        public ITeamRepository teamRepository { get; private set; }

        public IBULeadsRepository buLeadsRepository { get; private set; }

        public IEmployeesRepository employeeRepository { get; private set; }

        public IEmployeeJobRoleRepository employeeJobRoleRepository { get; private set; }

        public IEmployeeSkillsRepository employeeSkillsRepository { get; private set; }

        public ITeamResourcesRepository teamResourcesRepository { get; private set; }

        public IContractTypeRepository contractTypeRepository { get; private set; }

        public ITeamProjectsRepository teamProjectsRepository { get; private set; }

        public IProjectAllocationRepository projectAllocationRepository { get; private set; }

        public UnitOfWork(ApplicationDbContext dbcontext)
        {
            _dbcontext = dbcontext;
            businessUniteRepository = new BusinessUniteRepository(_dbcontext);
            jobRolesRepository = new JobRolesRepository(_dbcontext);
            projectCategoryRepository = new ProjectCategoryRepository(_dbcontext);
            skillRepository = new SkillRepository(_dbcontext);            
            spCall = new StoreProcedureCall(_dbcontext);
            teamRepository = new TeamRepository(_dbcontext);
            buLeadsRepository = new BULeadsRepository(_dbcontext);
            employeeRepository = new EmployeesRepository(_dbcontext);
            employeeJobRoleRepository = new EmployeeJobRoleRepository(_dbcontext);
            employeeSkillsRepository = new EmployeeSkillsRepository(_dbcontext);
            teamResourcesRepository = new TeamResourcesRepository(_dbcontext);
            contractTypeRepository = new ContractTypeRepository(_dbcontext);
            teamProjectsRepository = new TeamProjectsRepository(_dbcontext);
            projectAllocationRepository = new ProjectAllocationRepository(_dbcontext);
        }
        
        public void Save()
        {
            _dbcontext.SaveChanges();
        }

        public void Dispose()
        {
            _dbcontext.Dispose();
        }
    }
}
