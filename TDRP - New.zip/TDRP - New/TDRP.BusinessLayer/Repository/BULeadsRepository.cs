﻿using Dapper;
using System.Collections.Generic;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class BULeadsRepository : Repository<BusinessUniteLeads>, IBULeadsRepository
    {
        private readonly ApplicationDbContext _db;

        public BULeadsRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }        

        public List<BusinessUniteLeads> GetAllBusinessUnitesLeads()
        {
            List<BusinessUniteLeads> uniteDetails = new List<BusinessUniteLeads>();
            uniteDetails = _db.BusinessUniteLeads.AsList();
            return uniteDetails;
        }        
    }
}
