﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ProjectAllocationRepository : Repository<ProjectAllocation>, IProjectAllocationRepository
    {
        private readonly ApplicationDbContext _db;

        public ProjectAllocationRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetBusinessUnitesForDropDown()
        {
            throw new NotImplementedException();
        }

        public List<ProjectAllocation> GetProjectAllocation()
        {
            List<ProjectAllocation> projectAllocation = new List<ProjectAllocation>();
            projectAllocation = _db.ProjectAllocation.AsList();
            return projectAllocation;
        }

        public void Update(ProjectAllocation projectAllocation)
        {
            var objFromDb = _db.ProjectAllocation.FirstOrDefault(s => s.Id == projectAllocation.Id);
            objFromDb.ProjectId = projectAllocation.ProjectId;
            objFromDb.EmployeeId = projectAllocation.EmployeeId;
            objFromDb.FTEAssigned = projectAllocation.FTEAssigned;
            objFromDb.Active = projectAllocation.Active;
            objFromDb.StartDate = projectAllocation.StartDate;
            objFromDb.EndDate = projectAllocation.EndDate;
            objFromDb.UpdateBy = projectAllocation.UpdateBy;
            objFromDb.UpdatedDate = DateTime.Now;           

            _db.SaveChanges();
        }
    }
}
