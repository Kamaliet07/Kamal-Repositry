﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class EmployeeJobRoleRepository : Repository<EmployeeJobRole>, IEmployeeJobRoleRepository
    {
        private readonly ApplicationDbContext _db;

        public EmployeeJobRoleRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public List<EmployeeJobRole> GetEmployeesJobRole()
        {
            List<EmployeeJobRole> employeeJobRole = new List<EmployeeJobRole>();
            employeeJobRole = _db.EmployeeJobRole.AsList();
            return employeeJobRole;
        }

        public IEnumerable<SelectListItem> GetJobRolesForDropDown()
        {
            return _db.EmployeeJobRole.Select(i => new SelectListItem()
            {
                Text = i.JobRoles.JobRole,
                Value = i.Id.ToString(),
            });
        }

        public void Update(EmployeeJobRole employeeJobRole)
        {
            var objFromDb = _db.EmployeeJobRole.FirstOrDefault(s => s.Id == employeeJobRole.Id);
            objFromDb.JobRoleId = employeeJobRole.JobRoleId;
            objFromDb.ContractTypeId = employeeJobRole.ContractTypeId;
            objFromDb.FTE = employeeJobRole.FTE;
            objFromDb.Active = employeeJobRole.Active;            
            objFromDb.StartDate = employeeJobRole.StartDate;
            objFromDb.EndDate = employeeJobRole.EndDate;            
            objFromDb.Updateby = employeeJobRole.Updateby;
            objFromDb.UpdateDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
