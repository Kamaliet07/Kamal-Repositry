﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IProjectCategoryRepository : IRepository<ProjectCategory>
    {
        IEnumerable<SelectListItem> GetCategoriesDropDown();

        void Update(ProjectCategory projectCategory);
    }
}
