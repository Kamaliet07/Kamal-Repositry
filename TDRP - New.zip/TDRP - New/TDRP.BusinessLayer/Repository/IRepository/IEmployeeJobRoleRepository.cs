﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IEmployeeJobRoleRepository : IRepository<EmployeeJobRole>
    {
        IEnumerable<SelectListItem> GetJobRolesForDropDown();
        List<EmployeeJobRole> GetEmployeesJobRole();
        void Update(EmployeeJobRole employeeJobRole);
    }
}
