﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IContractTypeRepository : IRepository<ContractTypes>
    {
        IEnumerable<SelectListItem> GetContractTypeForDropDown();
        List<ContractTypes> GetContractTypes();

        void Update(ContractTypes contractTypes);
    }
}
