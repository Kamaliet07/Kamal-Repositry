﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface ITeamResourcesRepository : IRepository<TeamResources>
    {       

        IEnumerable<TeamResources> GetAllResources();

        void Update(TeamResources teamResources);

    }
}
