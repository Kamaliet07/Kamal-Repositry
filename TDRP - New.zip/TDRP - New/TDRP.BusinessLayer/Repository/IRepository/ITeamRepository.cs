﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface ITeamRepository : IRepository<Teams>
    {
        IEnumerable<SelectListItem> GetTeamListForDropDown();

        IEnumerable<Teams> GetAllTeamDetails();

        void Update(Teams teams);
    }
}
