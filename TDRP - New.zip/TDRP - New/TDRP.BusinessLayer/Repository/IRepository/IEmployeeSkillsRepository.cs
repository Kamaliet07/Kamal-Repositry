﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IEmployeeSkillsRepository : IRepository<EmployeeSkills>
    {
        IEnumerable<SelectListItem> GetEmployeeSkillsForDropDown();
        List<EmployeeSkills> GetEmployeeSkills();
        void Update(EmployeeSkills employeeSkills);
    }
}
