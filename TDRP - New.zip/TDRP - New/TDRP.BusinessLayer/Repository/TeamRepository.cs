﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class TeamRepository : Repository<Teams>, ITeamRepository
    {
        private readonly ApplicationDbContext _db;

        public TeamRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetTeamListForDropDown()
        {
            return _db.Teams.Select(i => new SelectListItem()
            {
                Text = i.TeamName,
                Value = i.Id.ToString(),
            });
        }

        public IEnumerable<Teams> GetAllTeamDetails()
        {
            List<Teams> teamDetails = new List<Teams>();
            teamDetails = _db.Teams.AsList();
            return teamDetails;
        }

        public void Update(Teams teams)
        {
            var objFromDb = _db.Teams.FirstOrDefault(s => s.Id == teams.Id);

            objFromDb.TeamName = teams.TeamName;            
            objFromDb.TeamDetails = teams.TeamDetails;
            objFromDb.TeamLeadId = teams.TeamLeadId;
            objFromDb.Active = teams.Active;
            objFromDb.UpdateBy = teams.UpdateBy;
            objFromDb.UpdatedDate = DateTime.Now;

            _db.SaveChanges();
        }
    }
}
