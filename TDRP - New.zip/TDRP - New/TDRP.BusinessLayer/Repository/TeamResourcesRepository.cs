﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class TeamResourcesRepository : Repository<TeamResources>, ITeamResourcesRepository
    {
        private readonly ApplicationDbContext _db;

        public TeamResourcesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<TeamResources> GetAllResources()
        {
            List<TeamResources> teamResources = new List<TeamResources>();
            teamResources = _db.TeamResources.AsList();
            return teamResources;
        }        

        public void Update(TeamResources teamResources)
        {
            var objFromDb = _db.TeamResources.FirstOrDefault(s => s.Id == teamResources.Id);
            objFromDb.EmployeeId = teamResources.EmployeeId;
            objFromDb.TeamId = teamResources.TeamId;            
            objFromDb.UpdateBy = teamResources.UpdateBy;
            objFromDb.UpdateDate = DateTime.Now;

            _db.SaveChanges();
        }
    }
}
