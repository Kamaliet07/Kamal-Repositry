﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class EmployeesRepository : Repository<Employees>, IEmployeesRepository
    {
        private readonly ApplicationDbContext _db;
        public EmployeesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public List<Employees> GetAllEmployees()
        {
            List<Employees> employees = new List<Employees>();
            employees = _db.Employees.AsList();
            return employees;
        }

        public IEnumerable<SelectListItem> GetEmployeesForDropDown()
        {
            return _db.Employees.Select(i => new SelectListItem()
            {
                Text = i.EmployeeName,
                Value = i.Id.ToString(),
            });
        }

        public void Update(Employees employees)
        {
            var objFromDb = _db.Employees.FirstOrDefault(s => s.Id == employees.Id);
            objFromDb.EmployeeName = employees.EmployeeName;
            objFromDb.EmployeeNumber = employees.EmployeeNumber;
            objFromDb.Email = employees.Email;
            objFromDb.Active = employees.Active;
            objFromDb.PhoneNumber = employees.PhoneNumber;
            objFromDb.StartDate = employees.StartDate;
            objFromDb.EndDate = employees.EndDate;
            objFromDb.UpdateBy = employees.UpdateBy;
            objFromDb.UpdateDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
