﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class SkillRepository : Repository<Skills>, ISkillRepository
    {
        private readonly ApplicationDbContext _db;

        public SkillRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetSkillsListItems()
        {
            return _db.Skills.Select(i => new SelectListItem()
            {
                Text = i.Skill,
                Value = i.Id.ToString()
            });
        }

        public void Update(Skills skills)
        {
            var objFromDb = _db.Skills.FirstOrDefault(s => s.Id == skills.Id);
            objFromDb.Skill = skills.Skill;
            objFromDb.SkillDescription = skills.SkillDescription;
            objFromDb.Active = skills.Active;
            objFromDb.CreatedBy = skills.CreatedBy;            
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
