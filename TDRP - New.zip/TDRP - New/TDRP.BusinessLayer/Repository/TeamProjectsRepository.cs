﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class TeamProjectsRepository : Repository<TeamProjects>, ITeamProjectsRepository
    {
        private readonly ApplicationDbContext _db;

        public TeamProjectsRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<TeamProjects> GetTeamProjects()
        {
            List<TeamProjects> teamResources = new List<TeamProjects>();
            teamResources = _db.TeamProjects.AsList();
            return teamResources;
        }

        public IEnumerable<SelectListItem> GetTeamProjectsForDropDown()
        {
            throw new NotImplementedException();
        }

        public void Update(TeamProjects teamProjects)
        {
            var objFromDb = _db.TeamProjects.FirstOrDefault(s => s.Id == teamProjects.Id);
            objFromDb.ProjectName = teamProjects.ProjectName;
            objFromDb.ProjectDescription = teamProjects.ProjectDescription;
            objFromDb.TeamId = teamProjects.TeamId;
            objFromDb.EstimatedBudget = teamProjects.EstimatedBudget;
            objFromDb.TotalExpenditure = teamProjects.TotalExpenditure;
            objFromDb.CategoryId = teamProjects.CategoryId;
            objFromDb.Active = teamProjects.Active;
            objFromDb.StartDate = teamProjects.StartDate;
            objFromDb.EndDate = teamProjects.EndDate;
            objFromDb.UpdateBy = teamProjects.UpdateBy;
            objFromDb.UpdateDate = DateTime.Now;

            _db.SaveChanges();
        }
    }
}
