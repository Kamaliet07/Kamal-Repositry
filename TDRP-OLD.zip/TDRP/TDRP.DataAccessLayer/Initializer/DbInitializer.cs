﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TDRP.DataAccessLayer.Data;
using TDRP.Utility;

namespace TDRP.DataAccessLayer.Initializer
{
    public class DbInitializer : IDbInitializer
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public DbInitializer(ApplicationDbContext db, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _db = db;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        /// <summary>
        /// Method To Initialize the Database with Pre-requisit data required to Access on first instance.
        /// </summary>
        public void Initialize()
        {
            try
            {
                if (_db.Database.GetPendingMigrations().Count() > 0)
                {
                    _db.Database.Migrate();
                }
            }
            catch (Exception ex)
            {
                
            }

            if (_db.Roles.Any(r => r.Name == AppConstant.Admin)) return;

            // Create Role into AspNetRole Table
            _roleManager.CreateAsync(new IdentityRole(AppConstant.Admin)).GetAwaiter().GetResult();
            _roleManager.CreateAsync(new IdentityRole(AppConstant.Manager)).GetAwaiter().GetResult();
            _roleManager.CreateAsync(new IdentityRole(AppConstant.Employee)).GetAwaiter().GetResult();

            // Create First User (Admin) login to start the application at first instance
            _userManager.CreateAsync(new ApplicationUser
            {
                UserName = "admin@ybs.co.uk",
                Email = "admin@ybs.co.uk",
                EmailConfirmed = true,
                Name = "YBS Admin"

            }, "Admin@123").GetAwaiter().GetResult();

            ApplicationUser user = _db.ApplicationUser.Where(u => u.Email == "admin@ybs.co.uk").FirstOrDefault();
            
            // Assign user role as Admin
            _userManager.AddToRoleAsync(user, AppConstant.Admin).GetAwaiter().GetResult();
        }
    }
}
