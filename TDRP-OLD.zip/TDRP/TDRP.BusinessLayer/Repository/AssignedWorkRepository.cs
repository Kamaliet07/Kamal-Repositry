﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class AssignedWorkRepository : Repository<AssignedWork>, IAssignedWorkRepository
    {
        private readonly ApplicationDbContext _db;

        public AssignedWorkRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetProjectsForDropDown()
        {
            return _db.AssignedWork.Select(i => new SelectListItem()
            {
                Text = i.Projects.ProjectName,
                Value = i.ProjectId.ToString()
            });
        }

        public void Update(AssignedWork assignedWork)
        {
            var objFromDb = _db.AssignedWork.FirstOrDefault(s => s.AssignedWorkId == assignedWork.AssignedWorkId);
        }
    }
}
