﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class JobRolesRepository : Repository<JobRoles>, IJobRolesRepository
    {
        private readonly ApplicationDbContext _db;

        public JobRolesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetJobRoles()
        {
            return _db.JobRoles.Select(i => new SelectListItem()
            {
                Text = i.JobRole,
                Value = i.JobRoleId.ToString(),
            });
        }

        public void Update(JobRoles jobRoles)
        {
            var objFromDb = _db.JobRoles.FirstOrDefault(s => s.JobRoleId == jobRoles.JobRoleId);
            objFromDb.JobRole = jobRoles.JobRole;
            objFromDb.JobRoleDescription = jobRoles.JobRoleDescription;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
