﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ProjectCategoriesRepository : Repository<ProjectCategories>, IProjectCategoriesRepository
    {
        private readonly ApplicationDbContext _db;

        public ProjectCategoriesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetCategoriesDropDown()
        {
            return _db.ProjectCategories.Select(i => new SelectListItem()
            {
                Text = i.Name,
                Value = i.Name.ToString()
            });
        }

        public void Update(ProjectCategories projectCategories)
        {
            var objFromDb = _db.ProjectCategories.FirstOrDefault(s => s.CategoryId == projectCategories.CategoryId);
        }
    }
}
