﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ProjectDetailsRepository : Repository<ProjectDetails>, IProjectDetailsRepository
    {
        private readonly ApplicationDbContext _db;

        public ProjectDetailsRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetProjectDetailsForDropDown()
        {
            return _db.ProjectDetails.Select(i => new SelectListItem()
            {
                Text = i.Projects.ProjectName,
                Value = i.ProjectId.ToString(),
            });
        }

        public IEnumerable<ProjectDetails> GetProjectDetails()
        {
            List<ProjectDetails> projectDetails = new List<ProjectDetails>();
            projectDetails = _db.ProjectDetails.AsList();
            return projectDetails;
        }

        public void Update(ProjectDetails ProjectDetails)
        {
            var objFromDb = _db.ProjectDetails.FirstOrDefault(s => s.ProjectId == ProjectDetails.ProjectId);
            objFromDb.Projects.ProjectName = ProjectDetails.Projects.ProjectName;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}