﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.EntityFrameworkCore;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class EmployeesRepository : Repository<Employees>, IEmployeesRepository
    {
        // Create a private connection to the Database that can only be accessed by this repository.
        private readonly ApplicationDbContext _db;

        public EmployeesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<Employees> GetAllEmployees()
        {
            List<Employees> employees = _db.Employees.AsList();

            return employees;
        }

        /// <summary>
        ///     Retrieve list of employees associated with the given Team ID.
        /// </summary>
        /// <param name="employees"></param>
        /// <returns></returns>
        public void Update(Employees employees)
        {
            var objFromDb = _db.Employees.FirstOrDefault(s => s.EmpSysId == employees.EmpSysId);

            objFromDb.EmployeeNumber = employees.EmployeeNumber;
            objFromDb.StartDate = employees.StartDate;
            objFromDb.SupervisorNumber = employees.SupervisorNumber;
            objFromDb.FTE = employees.FTE;
            objFromDb.FirstName = employees.FirstName;
            objFromDb.LastName = employees.LastName;
            objFromDb.EndDate = employees.EndDate;
            objFromDb.TeamId = employees.TeamId;
            objFromDb.IsSupervisor = employees.IsSupervisor;
            objFromDb.Active = employees.Active;
            objFromDb.UpdateId = employees.UpdateId;
            objFromDb.UpdateDate = DateTime.Now;

            _db.SaveChanges();
        }
    }
}
