﻿using System;
using System.Linq.Expressions;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using System.Collections.Generic;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity.UI.Services;
using System.Security.Claims;
using TDRP.BusinessLayer.RepositoryUnit;

namespace TDRP.BusinessLayer.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly IEmailSender _emailSender;

        public IdentityOptions Options { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public UserRepository(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IEmailSender emailSender)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this._emailSender = emailSender;
        }
        
        public async Task<bool> GetByFilter(string email)
        {
            var isUniqueEmail = (await userManager.FindByEmailAsync(email) == null);
            return isUniqueEmail;
        }

        public async Task SignOutAsync()
        {
            await signInManager.SignOutAsync();
        }

        public async Task<ApplicationUser> FindByEmailAsync(string email)
        {
            return await userManager.FindByEmailAsync(email);
        }

        public async Task<IdentityResult> ResetPasswordAsync(ApplicationUser user, string code, string password)
        {
            return await userManager.ResetPasswordAsync(user, code, password);
        }

        public async Task<bool> IsEmailConfirmedAsync(ApplicationUser user)
        {
            return await userManager.IsEmailConfirmedAsync(user);
        }

        public async Task<string> GeneratePasswordResetToken(ApplicationUser user)
        {
            return await userManager.GeneratePasswordResetTokenAsync(user);
        }

        public async Task<string> GeneratePasswordResetTokenAsync(ApplicationUser user)
        {
            return await userManager.GeneratePasswordResetTokenAsync(user);
        }

        public async Task<ApplicationUser> FindByIdAsync(string userId)
        {
            return await userManager.FindByIdAsync(userId);
        }

        public async Task<IdentityResult> ConfirmEmailAsync(ApplicationUser user, string code)
        {
            return await userManager.ConfirmEmailAsync(user, code);
        }

        public async Task<IEnumerable<AuthenticationScheme>> GetExternalAuthenticationSchemesAsync()
        {
            return await signInManager.GetExternalAuthenticationSchemesAsync();
        }

        public async Task<IdentityResult> CreateAsync(ApplicationUser user, string password)
        {
            return await userManager.CreateAsync(user, password);
        }

        public async Task<IdentityResult> AddToRoleAsync(ApplicationUser user, string empType)
        {
            return await userManager.AddToRoleAsync(user, empType);
        }

        public async Task<SignInResult> PasswordSignInAsync(string email, string password, bool rememberMe, bool lockoutOnFailure)
        {
            return await signInManager.PasswordSignInAsync(email, password, rememberMe, lockoutOnFailure: true);
        }

        public async Task<string> GetUserIdAsync(ApplicationUser user)
        {
            return await userManager.GetUserIdAsync(user);
        }

        public async Task<string> GenerateEmailConfirmationTokenAsync(ApplicationUser user)
        {
            return await userManager.GenerateEmailConfirmationTokenAsync(user);
        }

        public async Task<IdentityResult> ChangeEmailAsync(ApplicationUser user, string email, string code)
        {
            return await userManager.ChangeEmailAsync(user, email, code);
        }

        public async Task<IdentityResult> SetUserNameAsync(ApplicationUser user, string email)
        {
            return await userManager.SetUserNameAsync(user, email);
        }

        public async Task RefreshSignInAsync(ApplicationUser user)
        {
            await signInManager.RefreshSignInAsync(user);
        }

        public AuthenticationProperties ConfigureExternalAuthenticationProperties(string provider, string redirectUrl)
        {
            return signInManager.ConfigureExternalAuthenticationProperties(provider, redirectUrl);
        }

        public async Task<ExternalLoginInfo> GetExternalLoginInfoAsync()
        {
            return await signInManager.GetExternalLoginInfoAsync();
        }

        public async Task<SignInResult> ExternalLoginSignInAsync(string loginProvider, string providerKey, bool isPersistent, bool bypassTwoFactor)
        {
            return await signInManager.ExternalLoginSignInAsync(loginProvider, providerKey, isPersistent, bypassTwoFactor);
        }

        public async Task<IdentityResult> CreateAsync(ApplicationUser user)
        {
            return await userManager.CreateAsync(user);
        }

        public async Task<IdentityResult> AddLoginAsync(ApplicationUser user, UserLoginInfo info)
        {
            return await userManager.AddLoginAsync(user, info);
        }

        public async Task SignInAsync(ApplicationUser user, bool isPersistent, string authenticationMethod = null)
        {
            await signInManager.SignInAsync(user, isPersistent, authenticationMethod);
        }

        public async Task SendEmailAsync(string email, string conf, string link)
        {
            await _emailSender.SendEmailAsync(email, conf, link);
        }

        public async Task<ApplicationUser> GetTwoFactorAuthenticationUserAsync()
        {
            return await signInManager.GetTwoFactorAuthenticationUserAsync();
        }

        public async Task<SignInResult> TwoFactorAuthenticatorSignInAsync(string authenticatorCode, bool rememberMe, bool rememberMachine)
        {
            return await signInManager.TwoFactorAuthenticatorSignInAsync(authenticatorCode, rememberMe, rememberMachine);
        }

        public async Task<SignInResult> TwoFactorRecoveryCodeSignInAsync(string recoveryCode)
        {
            return await signInManager.TwoFactorRecoveryCodeSignInAsync(recoveryCode);
        }

        public async Task<ApplicationUser> GetUserAsync(ClaimsPrincipal user)
        {
            return await userManager.GetUserAsync(user);
        }

        public string GetUserId(ClaimsPrincipal user)
        {
            return userManager.GetUserId(user);
        }

        public async Task<bool> HasPasswordAsync(ApplicationUser user)
        {
            return await userManager.HasPasswordAsync(user);
        }

        public async Task<IdentityResult> ChangePasswordAsync(ApplicationUser user, string oldPassword, string newPassword)
        {
            return await userManager.ChangePasswordAsync(user, oldPassword, newPassword);
        }

        public async Task<bool> CheckPasswordAsync(ApplicationUser user, string password)
        {
            return await userManager.CheckPasswordAsync(user, password);
        }

        public async Task<IdentityResult> DeleteAsync(ApplicationUser user)
        {
            return await userManager.DeleteAsync(user);
        }

        public async Task<bool> GetTwoFactorEnabledAsync(ApplicationUser user)
        {
            return await userManager.GetTwoFactorEnabledAsync(user);
        }

        public async Task<IdentityResult> SetTwoFactorEnabledAsync(ApplicationUser user, bool enabled)
        {
            return await userManager.SetTwoFactorEnabledAsync(user, enabled);
        }

        public async Task<string> GetEmailAsync(ApplicationUser user)
        {
            return await userManager.GetEmailAsync(user);
        }

        public async Task<string> GenerateChangeEmailTokenAsync(ApplicationUser user, string newEmail)
        {
            return await userManager.GenerateChangeEmailTokenAsync(user, newEmail);
        }

        public async Task<bool> VerifyTwoFactorTokenAsync(ApplicationUser user, string authenticatorTokenProvider, string verificationCode)
        {
            return await userManager.VerifyTwoFactorTokenAsync(user, authenticatorTokenProvider, verificationCode);
        }

        public async Task<int> CountRecoveryCodesAsync(ApplicationUser user)
        {
            return await userManager.CountRecoveryCodesAsync(user);
        }

        public async Task<IEnumerable<string>> GenerateNewTwoFactorRecoveryCodesAsync(ApplicationUser user, int number)
        {
           return await userManager.GenerateNewTwoFactorRecoveryCodesAsync(user, number);
        }

        public async Task<string> GetAuthenticatorKeyAsync(ApplicationUser user)
        {
           return await userManager.GetAuthenticatorKeyAsync(user);
        }

        public async Task<IdentityResult> ResetAuthenticatorKeyAsync(ApplicationUser user)
        {
            return await userManager.ResetAuthenticatorKeyAsync(user);
        }

        public async Task<IList<UserLoginInfo>> GetLoginsAsync(ApplicationUser user)
        {
            return await userManager.GetLoginsAsync(user);
        }

        public async Task<IdentityResult> RemoveLoginAsync(ApplicationUser user, string loginProvider, string providerKey)
        {
            return await userManager.RemoveLoginAsync(user, loginProvider, providerKey);
        }

        public AuthenticationProperties ConfigureExternalAuthenticationProperties(string provider, string redirectUrl, string userId)
        {
           return signInManager.ConfigureExternalAuthenticationProperties(provider, redirectUrl, userId);
        }

        public async Task<ExternalLoginInfo> GetExternalLoginInfoAsync(string expectedXsrf)
        {
            return await signInManager.GetExternalLoginInfoAsync(expectedXsrf);
        }

        public async Task<string> GetUserNameAsync(ApplicationUser user)
        {
            return await userManager.GetUserNameAsync(user);
        }

        public async Task<string> GetPhoneNumberAsync(ApplicationUser user)
        {
            return await userManager.GetPhoneNumberAsync(user);
           
        }

        public async Task<IdentityResult> SetPhoneNumberAsync(ApplicationUser user, string phoneNumber)
        {
            return await userManager.SetPhoneNumberAsync(user, phoneNumber);
        }

        public async Task<IdentityResult> AddPasswordAsync(ApplicationUser user, string newPassword)
        {
           return await userManager.AddPasswordAsync(user, newPassword);
        }

        public async Task<bool> IsTwoFactorClientRememberedAsync(ApplicationUser user)
        {
            return await signInManager.IsTwoFactorClientRememberedAsync(user);
        }

        public async Task ForgetTwoFactorClientAsync()
        {
            await signInManager.ForgetTwoFactorClientAsync();
        }
    }
}
