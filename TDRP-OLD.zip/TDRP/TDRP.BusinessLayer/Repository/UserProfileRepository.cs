﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class UserProfileRepository : Repository<UserProfileDetails>, IUserProfileRepository
    {
        public ApplicationDbContext _db { get; }

        public UserProfileRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public int Update(UserProfileDetails userProfile)
        {
            var objFromDb = _db.UserProfileDetails.FirstOrDefault(s => s.ProfileId == userProfile.ProfileId);

            objFromDb.FirstName = userProfile.FirstName;
            objFromDb.LastName = userProfile.LastName;
            objFromDb.TeamId = userProfile.TeamId;
            objFromDb.JobRoleId = userProfile.JobRoleId;
            objFromDb.Active = true;
            objFromDb.UpdatedDate = DateTime.Now;
            return _db.SaveChanges();
        }
    }
}
