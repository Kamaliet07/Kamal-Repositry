﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class SkillRepository : Repository<Skills>, ISkillRepository
    {
        private readonly ApplicationDbContext _db;

        public SkillRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetSkillsListItems()
        {
            return _db.Skills.Select(i => new SelectListItem()
            {
                Text = i.Skill,
                Value = i.SkillId.ToString()
            });
        }

        public void Update(Skills skills)
        {
            var objFromDb = _db.Skills.FirstOrDefault(s => s.SkillId == skills.SkillId);
            objFromDb.Skill = skills.Skill;
            objFromDb.SkillDescription = skills.SkillDescription;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
