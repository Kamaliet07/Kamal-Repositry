﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.EntityFrameworkCore;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.DataAccessLayer.ParentRepository;

namespace TDRP.BusinessLayer.Repository
{
    public class ProjectAllocationRepository : Repository<ProjectAllocation>, IProjectAllocationRepository
    {
        private readonly ApplicationDbContext _db;

        public ProjectAllocationRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<ProjectAllocation> GetAllAllocations()
        {
            List<ProjectAllocation> projectAllocations = new List<ProjectAllocation>();
            projectAllocations = _db.ProjectAllocation.AsList();

            return projectAllocations;
        }

        public void Update(ProjectAllocation projectAllocation)
        {
            var objFromDb = _db.ProjectAllocation.FirstOrDefault(x => x.ProjAllocationId.Equals(projectAllocation.ProjAllocationId));
            objFromDb.AllocatedDays = projectAllocation.AllocatedDays;
            objFromDb.UpdatedDate = DateTime.Now;
            objFromDb.WorkingDays = projectAllocation.WorkingDays;
            objFromDb.Year = projectAllocation.Year;

            _db.SaveChanges();
        }
    }
}
