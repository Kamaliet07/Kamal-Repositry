﻿using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.Repository;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;

namespace TDRP.BusinessLayer.RepositoryUnit
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _dbcontext;

        public IUserProfileRepository userprofile { get; private set; }

        public ITeamRepository teamRepository { get; private set; }

        public IJobRolesRepository jobRolesRepository { get; private set; }

        public ISkillRepository skillRepository { get; private set; }

        public IUserSkillsRepository userSkillsRepository { get; private set; }

        public IUserRepository userRepository { get; private set; }

        public IProjectRepository projectRepository { get; private set; }

        public IProjectAllocationRepository ProjectAllocationRepository { get; private set; }

        public IProjectCategoriesRepository projectCategoriesRepository { get; private set; }

        public IProjectDetailsRepository ProjectDetailsRepository { get; private set; }

        public IStoreProcedureCall SpCall { get; private set; }

        public IAssignedWorkRepository AssignedWorkRepository { get; private set; }

        public IEmployeesRepository EmployeesRepository { get; private set; }

        public UnitOfWork(ApplicationDbContext dbcontext)
        {
            _dbcontext = dbcontext;

            SpCall = new StoreProcedureCall(_dbcontext);
            userprofile = new UserProfileRepository(_dbcontext);
            teamRepository = new TeamRepository(_dbcontext);
            jobRolesRepository = new JobRolesRepository(_dbcontext);
            skillRepository = new SkillRepository(_dbcontext);
            userSkillsRepository = new UserSkillsRepository(_dbcontext);
            projectRepository = new ProjectRepository(_dbcontext);
            ProjectAllocationRepository = new ProjectAllocationRepository(_dbcontext);
            projectCategoriesRepository = new ProjectCategoriesRepository(_dbcontext);
            ProjectDetailsRepository = new ProjectDetailsRepository(_dbcontext);
            AssignedWorkRepository = new AssignedWorkRepository(_dbcontext);
            EmployeesRepository = new EmployeesRepository(_dbcontext);
        }

        public void Save()
        {
            _dbcontext.SaveChanges();
        }

        public void Dispose()
        {
            _dbcontext.Dispose();
        }
    }
}
