﻿using System;
using System.Collections.Generic;
using System.Text;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.ParentRepository;

namespace TDRP.BusinessLayer.RepositoryUnit
{
    public interface IUnitOfWork : IDisposable
    {

        IUserProfileRepository userprofile { get; }

        ITeamRepository teamRepository { get; }

        IJobRolesRepository jobRolesRepository { get; }

        ISkillRepository skillRepository { get; }

        IUserSkillsRepository userSkillsRepository { get; }

        IProjectRepository projectRepository { get; }

        IProjectAllocationRepository ProjectAllocationRepository { get; }

        IProjectCategoriesRepository projectCategoriesRepository { get; }

        IProjectDetailsRepository ProjectDetailsRepository { get; }

        IStoreProcedureCall SpCall { get; }

        IAssignedWorkRepository AssignedWorkRepository { get; }

        IEmployeesRepository EmployeesRepository { get; }

        void Save();
    }
}
