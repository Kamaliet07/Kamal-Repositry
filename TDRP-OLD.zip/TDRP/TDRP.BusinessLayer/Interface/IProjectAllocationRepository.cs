﻿using System;
using System.Collections.Generic;
using System.Text;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IProjectAllocationRepository : IRepository<ProjectAllocation>
    {
        IEnumerable<ProjectAllocation> GetAllAllocations();

        void Update(ProjectAllocation projectAllocation);
    }
}
