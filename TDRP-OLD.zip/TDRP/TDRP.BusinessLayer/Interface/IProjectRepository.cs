﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IProjectRepository : IRepository<Projects>
    {
        IEnumerable<SelectListItem> GetProjectListForDropDown();

        IEnumerable<Projects> GetAllProjectDetails();

        void Update(Projects projects);
    }
}
