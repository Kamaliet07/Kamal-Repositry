﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IProjectCategoriesRepository : IRepository<ProjectCategories>
    {
        IEnumerable<SelectListItem> GetCategoriesDropDown();

        void Update(ProjectCategories projectCategories);
    }
}
