﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using Microsoft.AspNetCore.Identity.UI.Services;
using System.Security.Claims;

namespace TDRP.BusinessLayer.Interface
{
    public interface IUserRepository
    {
        IdentityOptions Options { get; set; }
        Task<bool> GetByFilter(string email);
        Task SignOutAsync();
        Task<ApplicationUser> FindByEmailAsync(string email);
        Task<IdentityResult> ResetPasswordAsync(ApplicationUser user, string code, string password);
        Task<bool> IsEmailConfirmedAsync(ApplicationUser user);
        Task<string> GeneratePasswordResetToken(ApplicationUser user);
        Task<ApplicationUser> FindByIdAsync(string userId);
        Task<IdentityResult> ConfirmEmailAsync(ApplicationUser user, string code);
        Task<bool> GetTwoFactorEnabledAsync(ApplicationUser user);
        Task<IEnumerable<AuthenticationScheme>> GetExternalAuthenticationSchemesAsync();
        Task<string> GetUserNameAsync(ApplicationUser user);
        Task<IList<UserLoginInfo>> GetLoginsAsync(ApplicationUser user);
        Task<string> GetPhoneNumberAsync(ApplicationUser user);
        Task<IdentityResult> CreateAsync(ApplicationUser user, string password);
        Task<IdentityResult> ChangeEmailAsync(ApplicationUser user, string email, string code);
        Task<IdentityResult> AddToRoleAsync(ApplicationUser user, string empType);
        Task<bool> IsTwoFactorClientRememberedAsync(ApplicationUser user);
        Task<SignInResult> PasswordSignInAsync(string email, string password, bool rememberMe, bool lockoutOnFailure);
        Task<string> GetEmailAsync(ApplicationUser user);
        Task<string> GeneratePasswordResetTokenAsync(ApplicationUser user);
        Task<IdentityResult> SetTwoFactorEnabledAsync(ApplicationUser user, bool enable);
        Task ForgetTwoFactorClientAsync();
        Task<IdentityResult> RemoveLoginAsync(ApplicationUser user, string loginProvider, string providerKey);
        Task<IdentityResult> SetPhoneNumberAsync(ApplicationUser user, string phoneNumber);
        Task<IdentityResult> AddPasswordAsync(ApplicationUser user, string newPassword);
        Task<string> GetUserIdAsync(ApplicationUser user);
        Task<ApplicationUser> GetTwoFactorAuthenticationUserAsync();
        Task<IdentityResult> SetUserNameAsync(ApplicationUser user, string email);
        Task<bool> CheckPasswordAsync(ApplicationUser user, string password);
        Task<ApplicationUser> GetUserAsync(ClaimsPrincipal user);
        Task<string> GenerateEmailConfirmationTokenAsync(ApplicationUser user);
        Task<IdentityResult> DeleteAsync(ApplicationUser user);
        string GetUserId(ClaimsPrincipal user);
        Task<bool> HasPasswordAsync(ApplicationUser user);
        AuthenticationProperties ConfigureExternalAuthenticationProperties(string provider, string redirectUrl, string userId = null);
        Task<string> GenerateChangeEmailTokenAsync(ApplicationUser user, string newEmail);
        Task RefreshSignInAsync(ApplicationUser user);
        Task<ExternalLoginInfo> GetExternalLoginInfoAsync(string expectedXsrf = null);
        Task<bool> VerifyTwoFactorTokenAsync(ApplicationUser user, string authenticatorTokenProvider, string verificationCode);
        Task<SignInResult> ExternalLoginSignInAsync(string loginProvider, string providerKey, bool isPersistent, bool bypassTwoFactor);
        Task<SignInResult> TwoFactorRecoveryCodeSignInAsync(string recoveryCode);
        Task<IdentityResult> CreateAsync(ApplicationUser user);
        Task<IdentityResult> AddLoginAsync(ApplicationUser user, UserLoginInfo info);
        Task<IdentityResult> ChangePasswordAsync(ApplicationUser user, string oldPassword, string newPassword);
        Task SignInAsync(ApplicationUser user, bool isPersistent, string authenticationMethod = null);
        Task<int> CountRecoveryCodesAsync(ApplicationUser user);
        Task SendEmailAsync(string email, string conf, string link);
        Task<IEnumerable<string>> GenerateNewTwoFactorRecoveryCodesAsync(ApplicationUser user, int number);
        Task<SignInResult> TwoFactorAuthenticatorSignInAsync(string authenticatorCode, bool rememberMe, bool rememberMachine);
        Task<string> GetAuthenticatorKeyAsync(ApplicationUser user);
        Task<IdentityResult> ResetAuthenticatorKeyAsync(ApplicationUser user);
    }
}
