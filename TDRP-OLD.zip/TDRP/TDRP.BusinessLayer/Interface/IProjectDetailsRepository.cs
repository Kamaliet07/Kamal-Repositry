﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IProjectDetailsRepository : IRepository<ProjectDetails>
    {
        IEnumerable<SelectListItem> GetProjectDetailsForDropDown();

        IEnumerable<ProjectDetails> GetProjectDetails();

        void Update(ProjectDetails projectDetails);
    }
}