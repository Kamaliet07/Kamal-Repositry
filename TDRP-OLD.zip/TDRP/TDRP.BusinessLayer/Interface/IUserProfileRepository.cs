﻿using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IUserProfileRepository : IRepository<UserProfileDetails>
    {
        int Update(UserProfileDetails userProfile);
    }
}
