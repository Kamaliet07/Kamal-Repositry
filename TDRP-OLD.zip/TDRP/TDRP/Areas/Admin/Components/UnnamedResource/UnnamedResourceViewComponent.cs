﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Query.ExpressionVisitors.Internal;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Areas.Admin.Components.UnnamedResource
{
    [ViewComponent(Name = "UnnamedResource")]
    public class UnnamedResourceViewComponent : ViewComponent
    {
        private readonly IUnitOfWork _unitOfWork;

        public UnnamedResourceViewComponent(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        ///     Returns a render of a form the user can use to allocate an unnamed resource to the project.
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public async Task<IViewComponentResult> InvokeAsync(int projectId)
        {
            ViewData["ProjectId"] = projectId;

            // Initialise the new object before passing it to the view.
            UnnamedResources unnamedResource = new UnnamedResources
            {
                ProjectId = projectId,
                TeamName = _unitOfWork.teamRepository.GetTeamListForDropDown()
            };

            return await Task.FromResult((IViewComponentResult)View("UnnamedResource", unnamedResource));
        }
    }
}
