﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class EmployeesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        ///     Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="userService"></param>
        public EmployeesController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        /// <summary>
        ///     Action Method To Load Employee List View
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Manager, Admin")]
        public IActionResult UsersList()
        {
            List<EmployeesList> objFromDb = _unitOfWork.SpCall.ReturnList<EmployeesList>(AppConstant.usp_GetEmployees)
                .Result.ToList();

            return View(objFromDb);
        }

        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            return Json(new { data = _unitOfWork.SpCall.ReturnList<EmployeesList>(AppConstant.usp_GetEmployees, null).Result });
        }

        /// <summary>
        ///     Takes the User's ID and deactivates their account by setting email confirmed to false in AspNetUsers
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<JsonResult> DeactivateUser(string userId)
        {
            var user = await _userService.FindByIdAsync(userId);
            var userDetails = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));
            // Check to see if the User is inactive already or if the userId is null.  Return error if true.
            if (user.EmailConfirmed == false || userId == null)
            {
                return Json(new { failure = true });
            }
            if (userDetails != null)
            {
                userDetails.Active = false;
            }
            user.EmailConfirmed = false;
            _unitOfWork.Save();

            // Return success when the user have been deactivated.
            return Json(new { success = true });
        }

        /// <summary>
        ///     Takes the User's ID and activates their account by setting email confirmed to true in AspNetUsers
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<JsonResult> ActivateUser(string userId)
        {
            var user = await _userService.FindByIdAsync(userId);
            // Check to see if the User is active already or if the userId is null.  Return error if true.
            if (user.EmailConfirmed || userId == null)
            {
                return Json(new { failure = true });
            }
            user.EmailConfirmed = true;
            _unitOfWork.Save();

            // Return success when the user have been activated.
            return Json(new { success = true });
        }
    }
}