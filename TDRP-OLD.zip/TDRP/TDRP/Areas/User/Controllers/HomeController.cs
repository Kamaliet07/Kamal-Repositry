﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Controllers
{
    [Authorize]
    [Area("User")]
    public class HomeController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        /// Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="userService"></param>
        public HomeController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        /// <summary>
        ///     Returns the main dashboard view.
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            var userDetails = _userService.GetUserAsync(User).Result;
            ViewBag.TeamId = userDetails.TeamId;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult InProgress()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /// <summary>
        ///     This GET method will call a stored procedure the retrieve the total allocated days for
        ///     each project in the current month.  It takes the user's Team ID and the current month ID.
        /// </summary>
        /// <param name="teamId"></param>
        /// <param name="monthId"></param>
        /// <param name="year"></param>
        /// <returns>
        ///     A list of results containing the following:
        ///     int?   TeamId
        ///     int    AllocatedDays
        ///     int    MonthId
        ///     string ProjectName
        /// </returns>
        [HttpGet]
        public JsonResult GetAllocationData(int teamId, int? monthId, int year)
        {
            if (monthId.HasValue.Equals(false))
            {
                monthId = DateTime.Now.Month + 1;
            }
            else
            {
                monthId += 2;
            }

            DynamicParameters chartParameters = new DynamicParameters();
            chartParameters.Add("@TeamId", teamId, DbType.Int32, ParameterDirection.Input);
            chartParameters.Add("@MonthId", monthId, DbType.Int32, ParameterDirection.Input);

            List<AreaAllocationChart> areaAllocationChart = _unitOfWork.SpCall.ReturnList<AreaAllocationChart>(
                AppConstant.usp_AreaChartDataAllocation,
                chartParameters).Result.ToList();

            chartParameters.Add("@Year", year, DbType.Int32, ParameterDirection.Input);

            List<ProjectAllocationChart> chartData = _unitOfWork.SpCall
                .ReturnList<ProjectAllocationChart>(AppConstant.usp_PieChartProjectAllocationDays, chartParameters)
                .Result.ToList();

            List<ProjectAllocationChart> categoryData = _unitOfWork.SpCall
                .ReturnList<ProjectAllocationChart>(AppConstant.usp_PieChartCategoryAllocationDays, chartParameters)
                .Result.ToList();

            return Json(new { data = chartData, data2 = categoryData, data3 = areaAllocationChart });
        }

        /// <summary>
        ///     Redirect the user to a view that shows everyone who is assigned to a project in the month they selected.
        /// </summary>
        /// <param name="projectName"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public IActionResult ViewMonthAssignment(string projectName, string month, int year)
        {
            int projId = _unitOfWork.projectRepository.GetFirstOrDefault(x => x.ProjectName.Equals(projectName)).ProjectId;

            DynamicParameters procData = new DynamicParameters();
            procData.Add("@ProjectId", projId, DbType.Int32, ParameterDirection.Input);
            procData.Add("@Month", month, DbType.String, ParameterDirection.Input);
            procData.Add("@Year", year, DbType.Int32, ParameterDirection.Input);

            List<MonthAssignedEmployees> assignedEmployees = _unitOfWork.SpCall.ReturnList<MonthAssignedEmployees>(AppConstant.usp_GetAllocatedEmployeesMonth, procData)
                .Result.ToList();

            return View(assignedEmployees);
        }

        /// <summary>
        ///     Return list of employees assigned to a project for the selected month.
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public JsonResult FindAssignedEmployees(int projectId, string month, int year)
        {
            DynamicParameters procData = new DynamicParameters();
            procData.Add("@ProjectId", projectId, DbType.Int32, ParameterDirection.Input);
            procData.Add("@Month", month, DbType.String, ParameterDirection.Input);
            procData.Add("@Year", year, DbType.Int32, ParameterDirection.Input);

            List<MonthAssignedEmployees> assignedEmployees = _unitOfWork.SpCall.ReturnList<MonthAssignedEmployees>(AppConstant.usp_GetAllocatedEmployeesMonth, procData)
                .Result.ToList();

            return Json(new { data = assignedEmployees });
        }

        ///// <summary>
        /////     This GET method will return a list of months with total hours available and allocated hours
        /////     for a specific team.
        ///// </summary>
        ///// <param name="teamId"></param>
        ///// <returns>
        /////     
        ///// </returns>
        //[HttpGet]
        //public JsonResult GetAreaChartAllocationData(int teamId)
        //{
        //    List<AreaAllocationChart> areaAllocationChart = new List<AreaAllocationChart>();
        //    DynamicParameters chartParameters = new DynamicParameters();
        //    chartParameters.Add("@TeamId", teamId, DbType.Int32, ParameterDirection.Input);

        //    areaAllocationChart = _unitOfWork.SpCall.ReturnList<AreaAllocationChart>(
        //            AppConstant.usp_AreaChartDataAllocation,
        //            chartParameters).Result.ToList();

        //    return Json(new { data = areaAllocationChart });
        //}

        #region Test Views

        public IActionResult NewPieChartView()
        {
            return View();
        }

        #endregion
    }
}
