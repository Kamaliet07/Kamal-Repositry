﻿using System;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Areas.User.Controllers
{
    [Authorize]
    [Area("User")]
    public class ProjectAllocationController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        [BindProperty]
        public ProjectsAllocation ProjAllocation { get; set; }

        public ProjectAllocationController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Index method to load user and assigned projects detail
        /// </summary>
        /// <param name="empid"></param>
        /// <param name="projectid"></param>
        /// <returns></returns>
        public IActionResult ProjectAllocation(int empid, int projectid)
        {
            DynamicParameters empdetailsParam = new DynamicParameters();
            empdetailsParam.Add("@EmployeeNo", empid, DbType.Int32, ParameterDirection.Input);
            empdetailsParam.Add("@ProjectId", projectid, DbType.Int32, ParameterDirection.Input);

            List<EmployeeDetails> employeeDetails = _unitOfWork.SpCall.ReturnList<EmployeeDetails>(AppConstant.usp_GetEmployeeDetails, empdetailsParam).Result.ToList();

            ProjAllocation = new ProjectsAllocation()
            {
                EmployeeDetails = employeeDetails[0],
                Project = _unitOfWork.projectRepository.GetById(projectid),
            };

            return View(ProjAllocation);
        }

        /// <summary>
        ///     Method to get total days allocated to the employee in a month.
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="currentMonth"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetMonthlyAllocation(int empId, string currentMonth, int year)
        {
            DynamicParameters fteall = new DynamicParameters();
            fteall.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            fteall.Add("@Month", currentMonth, DbType.String, ParameterDirection.Input);
            fteall.Add("@Year", year, DbType.Int32, ParameterDirection.Input);

            List<DaysAllocated> total = _unitOfWork.SpCall.ReturnList<DaysAllocated>(AppConstant.usp_GetMonthlyAllocation, fteall).Result.ToList();

            return Json(new { data = total[0] });
        }

        /// <summary>
        ///     Method to get the remaining days in a month.
        /// </summary>
        /// <param name="empId">employee number</param>
        /// <param name="currentMonth">Month Selected</param>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetRemainingDaysInMonth(int empId, string currentMonth, int year)
        {
            DynamicParameters rdays = new DynamicParameters();
            rdays.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            rdays.Add("@Month", currentMonth, DbType.String, ParameterDirection.Input);
            rdays.Add("@Year", year, DbType.Int32, ParameterDirection.Input);

            List<int> total = _unitOfWork.SpCall.ReturnList<int>(AppConstant.usp_GetRemainingDaysInMonth, rdays).Result.ToList();

            return Json(new { data = total[0] });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetSixMonthsAllocation(int empId)
        {
            DynamicParameters dallo = new DynamicParameters();
            dallo.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            List<MonthsAllocated> monthAlloca = _unitOfWork.SpCall.ReturnList<MonthsAllocated>(AppConstant.usp_GetProjectsAllocationSixMonth, dallo).Result.ToList();

            return Json(new { data = monthAlloca });
        }

        /// <summary>
        ///     Get the Allocation Details for Selected Month
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="currmonth"></param>
        /// <param name="projectid"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetAllocationDetails(int empId, string currmonth, int projectid, int year)
        {
            DynamicParameters allodetails = new DynamicParameters();
            allodetails.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            allodetails.Add("@ProjectId", projectid, DbType.Int32, ParameterDirection.Input);
            allodetails.Add("@Month", currmonth, DbType.String, ParameterDirection.Input);
            allodetails.Add("@Year", year, DbType.Int32, ParameterDirection.Input);
            List<AllocationDetails> lstAlloca = _unitOfWork.SpCall.ReturnList<AllocationDetails>(AppConstant.usp_GetAllocationDetails, allodetails).Result.ToList();

            return Json(new { data = lstAlloca });
        }

        /// <summary>
        ///     Method to Load The Allocation Run Time When Tab Selected
        /// </summary>
        /// <param name="empNo"></param>
        /// <param name="selectedmonth"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult LoadProjectAllocationPartial(int empNo, string selectedmonth, int year)
        {
            DynamicParameters allocat = new DynamicParameters();
            allocat.Add("@EmployeeNo", empNo, DbType.Int32, ParameterDirection.Input);
            allocat.Add("@Month", selectedmonth, DbType.String, ParameterDirection.Input);
            allocat.Add("@Year", year, DbType.Int32, ParameterDirection.Input);
            List<ProjectsAssigned> lstAllocapartial = _unitOfWork.SpCall.ReturnList<ProjectsAssigned>(AppConstant.usp_GetAssignedProjects, allocat).Result.ToList();
            return Json(new { data = lstAllocapartial });
        }

        /// <summary>
        ///     Json result will check if the employee has enough days before posting a record to the database with the allocated time
        ///     on the selected project for the selected month.
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="projId"></param>
        /// <param name="allocatedDay"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <param name="workingDays"></param>
        /// <param name="teamId"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveProjectAllocation(int empId, int projId, int allocatedDay, string month, int year, int workingDays, int teamId)
        {
            // Retrieve the project details so we can use the end date to check if the user is being allocated
            // time past the end of the project.
            Projects project = _unitOfWork.projectRepository.GetById(projId);

            // Get the month number and create a new date to check the project end date is not greater than the month and year specified.
            int monthNumber = Convert.ToDateTime("01-" + month + year).Month;
            DateTime dateCheck = new DateTime(year, monthNumber, 1);

            try
            {
                if (project.EndDate > dateCheck)
                {
                    DynamicParameters fteAll = new DynamicParameters();
                    fteAll.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
                    fteAll.Add("@ProjectId", projId, DbType.Int32, ParameterDirection.Input);
                    fteAll.Add("@TeamId", teamId, DbType.Int32, ParameterDirection.Input);
                    fteAll.Add("@AllocatedDay", allocatedDay, DbType.Int32, ParameterDirection.Input);
                    fteAll.Add("@Month", month, DbType.String, ParameterDirection.Input);
                    fteAll.Add("@Year", year, DbType.Int32, ParameterDirection.Input);
                    fteAll.Add("@Workingdays", workingDays, DbType.Int32, ParameterDirection.Input);

                    _unitOfWork.SpCall.ExecuteWithoutReturn(AppConstant.usp_SaveProjectAllocation, fteAll);

                    return Json(new { success = true });
                }
                return Json(new { expired = true });
            }
            catch
            {
                return Json(new { error = true });
            }
        }

        /// <summary>
        ///     Edit the number of days that the employee will be allocated to the project for.
        /// </summary>
        /// <param name="projAllocationId"></param>
        /// <param name="allocatedDays"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Admin, Manager")]
        public JsonResult UpdateAllocatedDays(int projAllocationId, int allocatedDays)
        {
            try
            {
                ProjectAllocation projectAllocation =
                    _unitOfWork.ProjectAllocationRepository.GetFirstOrDefault(x =>
                        x.ProjAllocationId.Equals(projAllocationId));

                if (projectAllocation.WorkingDays >= allocatedDays)
                {
                    projectAllocation.AllocatedDays = allocatedDays;
                    _unitOfWork.ProjectAllocationRepository.Update(projectAllocation);

                    return Json(new { success = true });
                }

                return Json(new { error = true, errorMessage = "Cannot assign more than " + projectAllocation.WorkingDays + " days" });
            }
            catch
            {
                string msg = "Unable to save changes. " + "Try again, and if the problem persists " + "see your system administrator.";
                TempDataMessage(TDRPResource.msg, TDRPResource.msgError, msg);

                return Json(new { error = true, errorMessage = msg });
            }
        }

        /// <summary>
        ///     Delete the project allocation that has been assigned to the employee.
        /// </summary>
        /// <param name="projAllocationId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Authorize(Roles = "Admin, Manager")]
        public JsonResult DeleteAllocation(int projAllocationId)
        {
            try
            {
                ProjectAllocation projectAllocation = _unitOfWork.ProjectAllocationRepository.GetFirstOrDefault(x => x.ProjAllocationId.Equals(projAllocationId));
                _unitOfWork.ProjectAllocationRepository.Remove(projectAllocation);

                _unitOfWork.Save();

                return Json(new { success = true });
            }
            catch
            {
                string msg = "Unable to save changes. " + "Try again, and if the problem persists " + "see your system administrator.";
                TempDataMessage(TDRPResource.msg, TDRPResource.msgError, msg);

                return Json(new { error = true });
            }
        }

        /// <summary>
        ///     Method to handle Error Message
        /// </summary>
        /// <param name="key"></param>
        /// <param name="alert"></param>
        /// <param name="value"></param>
        public void TempDataMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }
        }
    }
}