﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;

namespace TDRP.Areas.Employee.Controllers
{
    [Area("Employee")]
    public class LeaveController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public LeaveController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult ApplyLeave()
        {
            return View();
        }

        public IActionResult LoadNestedTable()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAllTeams()
        {
            List<Teams> objTeamList = _unitOfWork.teamRepository.GetAllTeamDetails().ToList();
            return Json(new { data = objTeamList });            
        }
    }
}