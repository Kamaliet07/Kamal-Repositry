﻿var empNo = $("#empId").val();
var projId = $("#projectId").val();
var dataTablePartial;
var donutChart;
var startdate;
var enddate;
var numberofdays = 0;
var daysPending;
var date = new Date();
var month;
var year = date.getFullYear();
var barLabels = [];
var barAllocatedDays = [];
var barTotaldDays = [];
// This has been inserted to fetch the bank holiday dates from the government holiday API.
var bankHolidayEndpoint = ("https://www.gov.uk/bank-holidays.json");
var holidayDates = [];

$(document).ready(function () {
    loadBarChart();
    ActiveDefaultTab();
    loadAllocationPartial(month);
    loaddonutChart(month);
    $("#thisYear").addClass("active");
    // Used to collect bank holidays for England and Wales only. (This may be changes further down the line)
    fetch(bankHolidayEndpoint)
        .then((response) => response.json())
        .then((data) => handleBankHolidays(data));
});

function loadBarChart() {
    GetProjectsAllocationSixMonth(empNo);
    var areaChartData = {
        labels: barLabels,
        datasets: [
            {
                label: 'Allocated Days',
                backgroundColor: 'rgba(60,141,188,0.9)',
                borderColor: 'rgba(60,141,188,0.8)',
                pointRadius: false,
                pointColor: '#3b8bba',
                pointStrokeColor: 'rgba(60,141,188,1)',
                pointHighlightFill: '#fff',
                pointHighlightStroke: 'rgba(60,141,188,1)',
                data: barAllocatedDays
            },
            {
                label: 'Working Days',
                backgroundColor: 'rgba(210, 214, 222, 1)',
                borderColor: 'rgba(210, 214, 222, 1)',
                pointRadius: false,
                pointColor: 'rgba(210, 214, 222, 1)',
                pointStrokeColor: '#c1c7d1',
                pointHighlightFill: '#fff',
                pointHighlightStroke: 'rgba(220,220,220,1)',
                data: barTotaldDays
            }
        ]
    }

    //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas = $('#barChart').get(0).getContext('2d');
    var barChartData = jQuery.extend(true, {}, areaChartData);
    var temp0 = areaChartData.datasets[0];
    var temp1 = areaChartData.datasets[1];
    barChartData.datasets[0] = temp1;
    barChartData.datasets[1] = temp0;

    var barChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        datasetFill: false
    }

    var barChart = new Chart(barChartCanvas,
        {
            type: 'bar',
            data: barChartData,
            options: barChartOptions
        });
}

function ActiveDefaultTab() {
    month = GetCurrentMonthName();
    $('.nav-pills a[href="#' + month + '"]').tab('show');
    $("#Chart" + month).addClass("active");
    EnableTabAlongWithDataLoad();
}

function loadAllocationPartial(month) {
    // Reload the data
    dataTablepartial = $('#tblotherProject').DataTable({
        "searching": false,
        "paging": false,
        "ordering": false,
        "info": false,
        "ajax": {
            "url": "/User/ProjectAllocation/LoadProjectAllocationPartial",
            "data": { "empNo": empNo, "selectedmonth": month, "year": year },
            "type": "GET",
            "dataType": "json"
        },
        "columnDefs": [
            { "className": "dt-center", "targets": "_all" }
        ],
        "columns": [
            { "data": "projectName", "title": "Project Name" },
            {
                "data": "allocatedDays",
                "title": "Allocated Days",
                "render": function (data, type, row) {
                    return `<div class="text-center ${row.projAllocationId}" style="display:block;">
                                ${data}
                            </div>
                            <div class="text-center ${row.projAllocationId}" style="display:none;">
                                <input class="allocatedDaysFields${row.projAllocationId}" type="number" style="width:50%">
                            </div>
                           `;
                }
            },
            {
                "data": "projAllocationId",
                "title": " ",
                "render": function (data) {
                    return `<div id="allocationTableEditButtons${data}" class="text-center" style="display:block;">                         
                                <a onclick="ToggleAllocationInput(${data})" class="btn btn-box-tool" style="cursor:pointer;">
                                    <i class="glyphicon glyphicon-edit fa_customEdit"></i>
                                </a>
                                <a onclick=DeleteAllocation(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-trash fa_customDelete'></i> 
                                </a>	
                            </div>
                            <div id="allocationTableSubmitButtons${data}" class="text-center" style="display:none;">
                                <a onclick="UpdateAllocatedDays(${data})" class="btn btn-box-tool" style="cursor:pointer;">
                                    <i class="glyphicon glyphicon-ok fa_customEdit"></i>
                                </a>
                                <a onclick=ToggleAllocationInput(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-remove fa_customDelete'></i> 
                                </a>
                            </div>
                            `;
                },
                "width": "15%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

// When the user wants to edit the number of allocated days to the employee, toggle the buttons and show the input field.
function ToggleAllocationInput(projAllocationId) {
    $("." + projAllocationId).toggle();
    $("#allocationTableEditButtons" + projAllocationId).toggle();
    $("#allocationTableSubmitButtons" + projAllocationId).toggle();
    $(".allocatedDaysFields" + projAllocationId).val("");
}

// Update function will create an Ajax post request with the project allocation ID and update the number of days.
function UpdateAllocatedDays(projAllocationId) {
    // Select the input field that has the ID of the projAllocationId inside the allocatedDaysInput div.
    var allocatedDays = $(".allocatedDaysFields" + projAllocationId).val();

    swal({
        title: "Update Allocated Days?",
        text: "Are you sure you want to change the number of allocated days?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: "/User/ProjectAllocation/UpdateAllocatedDays",
                dataType: "json",
                data: { "projAllocationId": projAllocationId, "allocatedDays": allocatedDays },
                type: "POST",
                success: function (data) {
                    if (data.success) {
                        LoadProjectAllocationPartial();
                        EnableTabAlongWithDataLoad();
                    }
                    if (data.error) {
                        swal({
                            title: "Allocation not updated! Try again.",
                            text: data.errorMessage,
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Update Failed!",
                        text: "Allocation has not been updated! Try again.",
                        type: "warning"
                    });
                }
            });
        }
    });
}

function DeleteAllocation(projAllocationId) {
    swal({
        title: "Delete Allocation?",
        text: "This action cannot be reverted, are you sure you want to remove this allocation?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/User/ProjectAllocation/DeleteAllocation",
                dataType: "json",
                data: { "projAllocationId": projAllocationId },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        LoadProjectAllocationPartial();
                        EnableTabAlongWithDataLoad();
                    }
                    if (data.error) {
                        swal({
                            title: "Allocation not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Allocation not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function GetTotalMonthlyAllocated(empNo, month, year) {
    var totalFTE = 0;
    $.ajax({
        async: false,
        url: '/User/ProjectAllocation/GetMonthlyAllocation',
        data: { empId: empNo, currentMonth: month, year: year },
        type: "GET",
        success: function (result) {
            totalFTE = result.data;
        }
    });
    return totalFTE;
}

function GetProjectsAllocationSixMonth(empNo) {
    $.ajax({
        async: false,
        url: '/User/ProjectAllocation/GetSixMonthsAllocation',
        data: { empId: empNo },
        type: "GET",
        success: function (result) {
            if (result.data) {
                SplitResultIntoArray(result.data);
            }
        }
    });
}

function SplitResultIntoArray(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            barLabels.push(data[i].monthName);
            barAllocatedDays.push(data[i].allocatedDays);
            barTotaldDays.push(data[i].workingDays);
        }
    }
}

// Check the employee has the days available to allocate before saving the allocation to the database.
function SubmitAllocationDetails() {
    var workingDays = parseInt($("#txtworkdays" + month).val());
    var allocatedDay = parseInt($("#txtalloday" + month).val());
    var availableDays = parseInt($("#txtFteDays" + month).val());
    var teamId = $("#teamId").val();
    if ((workingDays != "") && (allocatedDay != "")) {
        if (availableDays >= allocatedDay) {
            $.ajax({
                async: false,
                url: '/User/ProjectAllocation/SaveProjectAllocation',
                data: {
                    empId: empNo,
                    projId: projId,
                    allocatedDay: allocatedDay,
                    month: month,
                    year: year,
                    workingDays: workingDays,
                    teamID: teamId
                },
                type: "POST",
                success: function (data) {
                    if (data.success) {
                        LoadProjectAllocationPartial();
                        EnableTabAlongWithDataLoad();
                        dataTablePartial.ajax.reload(null, false);
                    }
                    if (data.expired) {
                        swal({
                            title: "Project Ended",
                            text: "The time you are allocating has passed the end date of the project.",
                            type: "warning"
                        });
                    }
                    if (data.error) {
                        swal({
                            title: "Error!",
                            text: "Something went wrong.  Contact the site administrator for assistance.",
                            type: "warning"
                        });
                    }
                },
                error: function (ex) {
                    alert(ex);
                }
            });
        } else {
            swal({
                title: "Employee over-subscribed!",
                text: "User can allocate " + availableDays + " day(s) to this employee this month.",
                type: "warning"
            });
        }
    } else {
        swal("Allocated Days Error", "The required field is blank.  Insert a number and try again.", "warning");
    }
}

// Take the bank holidays and push them into an array for use in the workingDaysBetweenDates function.
function handleBankHolidays(data) {
    var englandAndWales = data["england-and-wales"].events;
    // For each item found in the array, loop through and push the dates into the holidayDates array.
    for (var i = 0; i < englandAndWales.length; i++) {
        holidayDates.push(englandAndWales[i].date);
    }
    return holidayDates;
}

function GetRemainingDaysInMonth(empNumber, month) {
    var remainingDays = 0;
    $.ajax({
        async: false,
        url: '/User/ProjectAllocation/GetRemainingDaysInMonth',
        data: { empId: empNumber, currentMonth: month },
        type: "GET",
        success: function (result) {
            remainingDays = result.data;
        }
    });
    return remainingDays;
}

// Used to validate the input string for date format dd/mm/yyyy
function isValidDate(dateString) {
    // First check for the pattern
    if (!/^\d{4}\-\d{1,2}\-\d{1,2}$/.test(dateString))
        return false;

    // Parse the date parts to integers
    var parts = dateString.split("-");
    var day = parseInt(parts[2], 10);
    var month = parseInt(parts[1], 10);
    var year = parseInt(parts[0], 10);

    // Check the ranges of month and year
    if (year < 1000 || year > 3000 || month == 0 || month > 12)
        return false;

    var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    // Adjust for leap years
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
        monthLength[1] = 29;

    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
};

function workingDaysBetweenDates(d0, d1) {
    /* Two working days and an sunday (not working day) */
    var holidays = holidayDates;
    var startDate = parseDate(d0);
    var endDate = parseDate(d1);

    // Validate input
    if (endDate < startDate) {
        return 0;
    }

    // Calculate days between dates
    var millisecondsPerDay = 86400 * 1000; // Day in milliseconds
    startDate.setHours(0, 0, 0, 1);  // Start just after midnight
    endDate.setHours(23, 59, 59, 999);  // End just before midnight
    var diff = endDate - startDate;  // Milliseconds between datetime objects    
    var days = Math.ceil(diff / millisecondsPerDay);

    // Subtract two weekend days for every week in between
    var weeks = Math.floor(days / 7);
    days -= weeks * 2;

    // Handle special cases
    var startDay = startDate.getDay();
    var endDay = endDate.getDay();

    // Remove weekend not previously removed.   
    if (startDay - endDay > 1) {
        days -= 2;
    }
    // Remove start day if span starts on Sunday but ends before Saturday
    if (startDay == 0 && endDay != 6) {
        days--;
    }
    // Remove end day if span ends on Saturday but starts after Sunday
    if (endDay == 6 && startDay != 0) {
        days--;
    }
    /* Here is the code */
    holidays.forEach(day => {
        if ((day >= d0) && (day <= d1)) {
            /* If it is not saturday (6) or sunday (0), subtract it */
            if ((parseDate(day).getDay() % 6) != 0) {
                days--;
            }
        }
    });
    return days;
}

function parseDate(input) {
    // Transform date from text to date
    var parts = input.match(/(\d+)/g);
    // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]])
    return new Date(parts[0], parts[1] - 1, parts[2]); // months are 0-based
}

function monthStartDate(input) {
    var myMonth = input + " " + year;
    var sDay = moment(myMonth).startOf("month").format("yyyy-MM-DD");
    // will give the start date of the month
    return sDay;
}

function monthEndDate(input) {
    var myMonth = input + " " + year;
    var checkDate = new Date(myMonth);
    var eDay = moment(checkDate).endOf("month").format("yyyy-MM-DD");
    return eDay;
}

function GetCurrentMonthName() {
    var month = new Array();
    month[0] = "January";
    month[1] = "February";
    month[2] = "March";
    month[3] = "April";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";

    var d = new Date();
    var mday = month[d.getMonth()];
    return mday;
}

function EnableTabAlongWithDataLoad() {
    // Depending on what year is selecting keep the selected year tab active even when the user changes months.
    $("[value=" + year + "]").addClass("active");
    // Get the Min and Max Date
    var min = monthStartDate(month);
    var max = monthEndDate(month);
    var total = GetTotalMonthlyAllocated(empNo, month, year);
    $('#txtworkdays' + month).val(workingDaysBetweenDates(min, max));
    $("#txtFteDays" + month).val(total.workingDays);
    $("#txtAvailableDays" + month).val(total.workingDays - total.allocatedDays);
    // Get the Data of Allocation
    var allocadt = GetAllocationDetails(empNo, month, projId);
    if (allocadt.length > 0) {
        $('#txtalloday' + month).val(allocadt[0].allocatedDays);
    }
}

function GetAllocationDetails(empNumber, month, projId) {
    var allocation = 0;
    $.ajax({
        async: false,
        url: '/User/ProjectAllocation/GetAllocationDetails',
        data: { empId: empNumber, currmonth: month, projectid: projId, year: year },
        type: "GET",
        success: function (result) {
            allocation = result.data;
        }
    });
    return allocation;
}

function LoadProjectAllocationPartial() {
    // Re-initialise the datatable
    dataTablePartial = $('#tblotherProject').DataTable();
    dataTablePartial.destroy();
    // Re-initialise the donut chart
    donutChart.destroy();
    // Reload the data For selected month
    loadAllocationPartial(month);
    loaddonutChart(month);
}

function loaddonutChart(mnthname) {
    // Get the selected month allocation
    var total = GetTotalMonthlyAllocated(empNo, mnthname, year);
    donutChartCanvas = $(donutProj).get(0).getContext('2d');
    var donutData = {
        labels: [
            'Capacity Used',
            'Capacity Spare'
        ],
        datasets: [
            {
                data: [total.allocatedDays, total.workingDays - total.allocatedDays],
                backgroundColor: ['#00a65a', '#d2d6de']
            }
        ]
    }
    var donutOptions = {
        maintainAspectRatio: false,
        responsive: true
    }
    donutChart = new Chart(donutChartCanvas,
        {
            type: 'doughnut',
            data: donutData,
            options: donutOptions
        });
}

$("#ChartJanuary").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'January';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartFebruary").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'February';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartMarch").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'March';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartApril").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'April';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartMay").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'May';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartJune").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'June';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartJuly").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'July';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartAugust").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'August';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});
$("#ChartSeptember").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'September';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartOctober").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'October';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartNovember").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'November';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#ChartDecember").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");
    month = 'December';
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#thisYear").click(function () {
    $("#nextYear").removeClass("active");
    $(this).addClass("active");
    year = parseInt($(this).val());
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#nextYear").click(function () {
    $("#thisYear").removeClass("active");
    $(this).addClass("active");
    year = parseInt($(this).val());
    EnableTabAlongWithDataLoad();
    LoadProjectAllocationPartial();
});

$("#btnJanReset").click(function () {
    $("#txtallodayJanuary").reset();
});

$("#btnFebReset").click(function () {
    $("#txtallodayFebruary").val("");
});

$("#btnMarchReset").click(function () {
    $("#txtallodayMarch").val("");
});

$("#btnAprReset").click(function () {
    $("#txtallodayApril").val("");
});

$("#btnMayReset").click(function () {
    $("#txtallodayMay").val("");
});

$("#btnJuneReset").click(function () {
    $("#txtallodayJune").val("");
});

$("#btnJulyReset").click(function () {
    $("#txtallodayJuly").val("");
});

$("#btnAugReset").click(function () {
    $("#txtallodayAugust").val("");
});

$("#btnSeptReset").click(function () {
    $("#txtallodaySeptember").val("");
});

$("#btnOctReset").click(function () {
    $("#txtallodayOctober").val("");
});

$("#btnNovReset").click(function () {
    $("#txtallodayNovember").val("");
});

$("#btnDecReset").click(function () {
    $("#txtallodayDecember").val("");
});