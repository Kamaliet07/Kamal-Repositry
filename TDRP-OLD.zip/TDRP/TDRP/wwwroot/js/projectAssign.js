﻿var dataTableEmployees;
var dataTableAssignments;
var dataTableAssignedEmp;
var projectId = parseInt($("#projectId").val());

// Stuck the array outside of the checkbox function so it does not refresh every time a checkbox fires an event.
var employeeArray = [];

function projectallocation(d) {
    return '<div class="col-md-8"><table class="table table-striped table-bordered" id="childtb_' + d.employeeNumber + '"></table></div><div class="col-md-4"><canvas id="donutChart_' + d.employeeNumber + '" style = "height:150px; min-height:150px" ></canvas ></div>';
}

$(document).ready(function () {
    loadAssignedEmployees();
    loadEmployeeTable(projectId);
    loadAssignedEmployeesTable(projectId);
});

function loadAssignedEmployees() {
    dataTableEmployees = $('#tblEmployeeList').DataTable({
        "ajax": {
            "url": "/admin/profile/GetAssignedWork",
            "type": "GET",
            "dataType": "json"
        },
        "columns": [
            { "data": "StartDate", "width": "85%" },
            {
                "data": "AssignedWorkId",
                "render": function (data) {
                    return `<div class="text-center">
                                <a href="/Admin/profile/UpdateWork/${data}" class="btn btn-box-tool" style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-edit fa_customEdit'></i></a>
                                &nbsp;
                                <a onclick= DeleteExp("/Admin/profile/DeleteWork/${data}") class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-trash fa_customDelete'></i> </a>	
                            </div>
                            `;
                }, "width": "15%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function loadEmployeeTable(projectId) {
    dataTableAssignments = $("#tblEmployeeAssignment").DataTable({
        "ajax": {
            "url": "/Admin/Projects/AssignEmployeeResult",
            "type": "GET",
            "dataType": "json",
            "data": { "projectId": projectId }
        },
        "columns": [
            { "data": "employeeNumber", "title": "Employee Number", "width": "20%" },
            {
                "data": "employeeName",
                "title": "Name",
                "width": "30%",
                "render": function (data) {
                    return `<a href="#">${data}</a>`;
                }
            },
            { "data": "fte", "title": "FTE (Hours)", "width": "20%" },
            {
                "data": "teamName",
                "title": "Team",
                "width": "20%",
                "render": function (data, type, row) {
                    return `<a href="/User/Teams/ViewTeamDetails/${row.teamId}">${data}</a>`;
                }
            },
            {
                "data": "teamId",
                "title": "Assign to Project",
                "render": function (data, type, row) {
                    return `<a onclick="AssignEmployeeToProject(${row.employeeNumber})" class="btn btn-box-tool" style="cursor:pointer;">
                                    <i class="glyphicon glyphicon-ok fa_customEdit"></i>
                            </a>`;
                }
            }
        ],
        "columnDefs": [
            { "visible": false, "targets": [2] }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function loadAssignedEmployeesTable(projectId) {
    dataTableAssignedEmp = $("#tblAssignedEmployees").DataTable({
        "ajax": {
            "url": "/Admin/Projects/ViewAssignedEmployees",
            "type": "GET",
            "data": { "projectId": projectId },
            "dataType": "json"
        },
        "columns": [
            { "data": "employeeNumber", "title": "Employee Number", "width": "20%" },
            {
                "data": "employeeName",
                "title": "Name",
                "width": "30%",
                "render": function (data, type, row) {
                    return `<a href="${row.employeeNumber}">${data}</a>`;
                }
            },
            {
                "data": "teamName",
                "title": "Team",
                "width": "20%",
                "render": function (data, type, row) {
                    return `<a href="/User/Teams/ViewTeamDetails/${row.teamId}">${data}</a>`;
                }
            },
            {
                "data": "assignedWorkId",
                "title": " ",
                "render": function (data, type, row) {
                    if (row.unnamedResource) {
                        return `<div class="text-center">                                
                                <a href="/Admin/Projects/UnnamedAssignment?assignedWorkId=${row.assignedWorkId}" class='btn btn-box-tool'style='cursor:pointer;'>
                                    <i class="glyphicon glyphicon-edit fa_customEdit"></i>
                                </a>  
                                <a onclick= RemoveEmployee(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-trash fa_customDelete'></i> </a>	
                            </div>
                            `;
                    } else {
                        return `<div class="text-center">                                
                                <a href="/User/ProjectAllocation/ProjectAllocation?empid=${row.employeeNumber
                            }&projectid=${projectId}" class='btn btn-box-tool'style='cursor:pointer;'>
                                    <i class="glyphicon glyphicon-edit fa_customEdit"></i>
                                </a>
                                <a onclick= RemoveEmployee(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-trash fa_customDelete'></i> </a>	
                            </div>
                            `;
                    }
                }
            },
            { "data": "teamId", "title": " " },
            { "data": "unnamedResource", "title": " " }
        ],
        "columnDefs": [
            { "visible": false, "targets": [4, 5] }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function AssignEmployeeToProject(employeeNumber) {
    $.ajax({
        url: "/Admin/Projects/AssignEmployeeProject",
        dataType: "json",
        data: { "employeeId": employeeNumber, "projectId": projectId },
        type: "POST",
        traditional: true,
        success: function (data) {
            if (data.success) {
                swal({
                    title: "Employee Assigned Successfully",
                    type: "success"
                });
                dataTableAssignments.ajax.reload(null, false);
            }
            if (data.expired) {
                swal({
                    title: "Project Ended",
                    text: "Cannot assign Employee to a Project that has ended.",
                    type: "warning"
                });
            }
            if (data.error) {
                swal({
                    title: "Employee not assigned",
                    text: "Something went wrong.  Please double check your assignments.",
                    type: "warning"
                });
            }
        },
        error: function () {
            swal({
                title: "Employee not assigned!",
                text: "Something went wrong.  Please double check your assignments.",
                type: "warning"
            });
            return false;
        }
    });
}

// Function will make an Ajax call to a method on the Projects controller to insert an end date in the active record for
// the selected employee.
function RemoveEmployee(assignedWorkId) {
    swal({
        title: "Remove Resource from this Project?",
        text: "This action cannot be reverted, are you sure you want to remove this employee?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: "/Admin/Projects/RemoveEmployeeFromProject",
                dataType: "json",
                data: { "assignedWorkId": assignedWorkId },
                type: "POST",
                traditional: true,
                success: function (data) {
                    if (data.success) {
                        swal({
                            title: "Resource removed successfully",
                            type: "success"
                        });
                        dataTableAssignedEmp.ajax.reload(null, false);
                    }
                    if (data.error) {
                        swal({
                            title: "Resource was not removed",
                            text: "Something went wrong.  Please try again.",
                            type: "warning"
                        });
                    }
                },
                error: function () {
                    swal({
                        title: "Resource not removed! Try again.",
                        type: "warning"
                    });
                    return false;
                }
            });
        }
    });
}

// When the user clicks the button to add an employee it will toggle the partial views and reset the form.
$("#btnToggleForms").click(function () {
    $("div[id=assignedEmployeeTable]").toggle();
    $("div[id=unnamedResourcesPartial]").toggle();
    // Reload the table in case any changes were posted to the database.
    dataTableAssignedEmp.ajax.reload(null, false);
    $(this).toggleText("Assign Unnamed Resource", "View Assigned Employees");
});