﻿var teamId = $("#teamId").val();
var barLabels = [];
var barAllocatedDays = [];
var barTotaldDays = [];
var roleCheck = $.parseJSON($("#roleCheck").val().toLowerCase());

function projectallocation(d) {
    return '<div class="col-md-12"><canvas id="barChart' + d.employeeNumber + '" style = "height:150px; min-height:150px" ></canvas ></div>';
}

$(document).ready(function () {
    $("#tblTeamProject").DataTable({
        "searching": false,
        "ordering": false,
        "info": false,
        "lengthChange": false,
        "pageLength": 3,
        "ajax": {
            "url": "/User/Teams/LoadActiveProjects",
            "type": "GET",
            "data": { "teamId": teamId },
            "dataType": "json"
        },
        "columns": [
            {
                "data": "projectName",
                "title": "Project Name",
                "render": function (data, type, row) {
                    return `<a href="../../../Admin/Projects/ProjectDetails/${row.projectId}">${data}</a>`;
                }
            },
            {
                "data": "projectId",
                "title": " "
            }
        ],
        "columnDefs": [
            { "visible": false, "targets": [1] }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });

    var table = $("#tblData").DataTable({
        "pageLength": 5,
        "lengthMenu": [[5, 10, 20], [5, 10, 20]],
        "ajax": {
            "url": "/User/Teams/ViewTeamEmployees",
            "data": { "id": teamId },
            "type": "GET",
            "dataType": "json"
        },
        "columns": [
            {
                "className": "details-control",
                "orderable": false,
                "data": null,
                "defaultContent": " ",
                "width": "5%"
            },
            { "data": "employeeNumber", "title": "Employee Number", "width": "20%" },
            { "data": "firstName", "title": "Name", "width": "20%" },
            { "data": "lastName" },
            { "data": "employmentType", "title": "Employment Type", "width": "20%" },
            {
                "data": "startDate", "title": "Start Date", "width": "15%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Start date not found.</p>";
                    }
                }
            },
            {
                "data": "employeeNumber",
                "render": function (data) {
                    return `<div class="text-center">                                
                                <a href="../../../Employee/Employees/EditEmployee?empNum=${data}" class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class="glyphicon glyphicon-edit fa_customEdit"></i>
                                </a>
                                <a onclick= DeleteEmployee(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-trash fa_customDelete'></i> </a>	
                            </div>
                            `;
                }, "width": "10%"
            }
        ],
        "columnDefs": [
            {
                "render": function (data, type, row) {
                    return `<a href="#" class="nav nav-link">${data} ${row.lastName}</a>`;
                },
                "targets": 2
            },
            { "visible": false, "targets": [3] },
            { "visible": roleCheck, "targets": [6] }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
    // Add event listener for opening and closing details
    $('#tblData tbody').on('click', 'td.details-control', function () {
        var tr = $(this).closest('tr');
        var row = table.row(tr);

        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }
        else {
            // Open this row (the format() function would return the data to be shown)
            if (row.child() && row.child().length) {
                row.child.show();
            }
            else {
                var empNo = row.data().employeeNumber;
                row.child(projectallocation(row.data())).show();
                // Clear array previous data
                barLabels.splice(0, barLabels.length);
                barAllocatedDays.splice(0, barAllocatedDays.length);
                barTotaldDays.splice(0, barTotaldDays.length);
                // Load employee allocation details
                GetProjectsAllocationSixMonth(empNo);
                var barchartEmpData = {
                    labels: barLabels,
                    datasets: [
                        {
                            label: 'Allocated Days',
                            backgroundColor: '#0a7d0a',
                            borderColor: '#0a7d0a',
                            pointRadius: false,
                            pointColor: '#3b8bba',
                            pointStrokeColor: 'rgba(60,141,188,1)',
                            pointHighlightFill: '#fff',
                            pointHighlightStroke: 'rgba(60,141,188,1)',
                            data: barAllocatedDays
                        },
                        {
                            label: 'Working Days',
                            backgroundColor: '#346beb',
                            borderColor: '#346beb',
                            pointRadius: false,
                            pointColor: 'rgba(210, 214, 222, 1)',
                            pointStrokeColor: '#c1c7d1',
                            pointHighlightFill: '#fff',
                            pointHighlightStroke: 'rgba(220,220,220,1)',
                            data: barTotaldDays
                        }
                    ]
                }

                //-------------
                //- BAR CHART -
                //-------------
                var barChartCanvas = $('#barChart' + empNo).get(0).getContext('2d');
                var barChartData = jQuery.extend(true, {}, barchartEmpData);
                var temp0 = barchartEmpData.datasets[0];
                var temp1 = barchartEmpData.datasets[1];
                barChartData.datasets[0] = temp1;
                barChartData.datasets[1] = temp0;

                var barChartOptions = {
                    responsive: true,
                    maintainAspectRatio: false,
                    datasetFill: false
                }

                var barChart = new Chart(barChartCanvas,
                    {
                        type: 'bar',
                        data: barChartData,
                        options: barChartOptions
                    });
            }
            tr.addClass('shown');
        }
    });

    // 
    $("select#EmploymentType").change(function () {
        newEmployeeType = $(this).children("option:selected").val();
    });
});

function GetProjectsAllocationSixMonth(empNo) {

    $.ajax({
        async: false,
        url: '/User/Teams/GetSixMonthsAllocation',
        data: { empId: empNo },
        type: "GET",
        success: function (result) {
            if (result.data) {

                SplitResultIntoArray(result.data);
            }
        }
    });
}

function SplitResultIntoArray(data) {

    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            barLabels.push(data[i].monthName);
            barAllocatedDays.push(data[i].allocatedDays);
            barTotaldDays.push(data[i].workingDays);
        }
    }
}

// Send a delete request using the employee number which will remove their details from the employee table on the database.
function DeleteEmployee(employeeNumber) {
    swal({
        title: "Delete Employee?",
        text: "This action cannot be reverted, are you sure you want to remove this employee?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/User/Teams/DeleteEmployee",
                dataType: "json",
                data: { "employeeNumber": employeeNumber },
                type: "POST",
                success: function (data) {
                    if (data.success) {
                        dataTableEmployees.ajax.reload(null, false);
                    }
                },
                error: function () {
                    swal({
                        title: "Employee not removed! Try again.",
                        type: "warning"
                    });
                    return false;
                }
            });
        };
    });
}