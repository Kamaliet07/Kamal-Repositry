﻿$(document).ready(function () {
    loadProjectListTable();
});

function loadProjectListTable() {
    $('#tblProjectList').DataTable({
        "ajax": {
            "url": "/admin/projects/ProjectList",
            "type": "GET",
            "dataType": "json"
        },
        "columns": [
            { "data": "projectId", "title": "Project ID", "width": "10%" },
            {
                "data": "projectName", "title": "Project Name", "width": "20%",
                "render": function (data, type, row) {
                    return `<a href="ProjectDetails/${row.projectId}">${data}</a>`;
                }
            },
            {
                "data": "startDate", "title": "Start Date", "width": "20%",
                "render": function (data) {
                    return data.split("T")[0];
                }
            },
            {
                "data": "endDate", "title": "End Date", "width": "20%",
                "render": function (data) {
                    return data.split("T")[0];
                }
            },
            { "data": "category", "title": "Category", "width": "20%" },
            { "data": "teamId", "title": "Team ID", "width": "10%" },
            { "data": "teamName", "title": "Team Name", "width": "20%" }
        ],
        "columnDefs": [
            { "visible": false, "targets": [0, 5] }
        ],
        "order": [[ 2, "asc"]]
    });
}

//Employees List - Java Script Method For All Employees List Activities

$(function () {
    $('#tblEmployees').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    });
});

$(function () {
    $('#tblEmployeeList').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    });
});

$(function () {
    $('#tblTeams').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    });
});

function viewProfile(id) {
    var url = "/User/Profile/UserProfile?uid=" + id;
    window.location.href = url;
}

// TO-DO - SD
function DeactivateUser(userId) {
    // Alert message will appear when the data has been saved for a set time 
    // and relocate user back to Project Details view.
    swal({
        title: "Deactivate selected Employee?",
        type: "warning",
        showCancelButton: true,
        cancelButtonText: "Return to List."
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/Employees/DeactivateUser",
                dataType: "json",
                data: { userId },
                type: "POST",
                traditional: true,
                success: function (data) {
                    if (data.success) {
                        swal({
                            title: "Employee deactivated Successfully",
                            type: "success"
                        }),
                        $('#tblEmployees').ajax.reload(null, false);
                    }
                },
                failure: function (data) {
                    swal({
                        title: "Employee has not been deactivated!",
                        type: "warning"
                    });
                    return false;
                },
                error: function (data) {
                    swal({
                        title: "Employee has not been deactivated!",
                        type: "warning"
                    });
                    return false;
                }
            });
        } else {
            swal("No changes were made to the account.");
        };
    });
}

// TO-DO - SD
function ActivateUser(userId) {
    // Alert message will appear when the data has been saved for a set time 
    // and relocate user back to Project Details view.
    swal({
        title: "Activate selected Employee?",
        type: "warning",
        showCancelButton: true,
        cancelButtonText: "Return to List."
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/Employees/ActivateUser",
                dataType: "json",
                data: { userId },
                type: "POST",
                traditional: true,
                success: function (data) {
                    swal({
                        title: "Employee activated Successfully",
                        type: "success"
                    }),
                        $('#tblEmployeeList').ajax.load(data);
                },
                failure: function (data) {
                    swal({
                        title: "Employee not activated!",
                        type: "warning"
                    });
                    return false;
                },
                error: function (data) {
                    swal({
                        title: "Employee not activated!",
                        type: "warning"
                    });
                    return false;
                }
            });
        } else {
            swal("No changes were made to the account.");
        };
    });
}

function DeactivateTeam(id) {
    swal({
        title: "Are you sure you want to deactivate this team?",
        text: "Your can re-activate from activation module!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, de-activate!",
        closeOnConfirm: true
    },
        function () {
            swal("Deactivated!", "This team has been deactivated successfully.", "success");
        });
}

// When the user clicks the button to add an employee it will toggle the partial views and reset the form.
$("#btnViewUserList").click(function () {
    $("div[id=activeUsersTable]").toggle();
    $("div[id=inactiveUsersTable]").toggle();
    $(this).toggleText("View Active Users", "View Inactive Users");
});