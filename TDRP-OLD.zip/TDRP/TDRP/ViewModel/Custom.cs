﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.DataModel;

namespace TDRP.ViewModel
{
    #region Property Definitions For Project Calender

    public class ProjectCalender
    {
        public int Id { get; set; }
        public string Month { get; set; }
    }

    public class CalenderProjects
    {
        public int ProjId { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }
        public string Category { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime? StartDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime? EndDate { get; set; }
    }

    public class ProjectsAllocation
    {
        public EmployeeDetails EmployeeDetails { get; set; }
        public Projects Project { get; set; }
    }

    public class ProjectsAssigned
    {
        public int ProjectId { get; set; }
        public int ProjAllocationId { get; set; }
        public string ProjectName { get; set; }
        public int AllocatedDays { get; set; }
        public string MonthName { get; set; }
        public int Year { get; set; }
        public int WorkingDays { get; set; }
    }

    public class DaysAllocated
    {
        public int WorkingDays { get; set; }
        public int AllocatedDays { get; set; }

    }

    public class MonthsAllocated
    {
        public string MonthName { get; set; }
        public int WorkingDays { get; set; }
        public int AllocatedDays { get; set; }
    }

    public class AllocationDetails
    {
        public int AllocatedDays { get; set; }
        public int WorkingDays { get; set; }
    }

    public class TeamProject
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int ResourceCount { get; set; }
    }

    public class TeamProjects
    {
        public Teams Teams { get; set; }
        public List<TeamProject> Teamproject { get; set; }
    }

    #endregion

    #region Project ViewModels

    public class AddProject
    {
        public int ProjectId { get; set; }
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        [Required] public string ProjectName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime StartDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime EndDate { get; set; }

        [Required] public string Category { get; set; }
        [Required] public string ProjectDescription { get; set; }
        [Required] public int EstimatedBudget { get; set; }
        public int TotalExpenditure { get; set; }
    }

    public class ProjectList
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Category { get; set; }
    }

    #endregion

    #region Employee ViewModels

    public class EmployeeDetails
    {
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public string SupervisorName { get; set; }
        public string EmploymentType { get; set; }
        public int EmployeeNumber { get; set; }
        public string EmployeeName { get; set; }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int FTE { get; set; }
    }

    public class EditEmployeeForm
    {
        public int EmpSysId { get; set; }
        [Display(Name = "Employee Number")]
        public int EmployeeNumber { get; set; }
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        public decimal FTE { get; set; }
        [Display(Name = "Start Date")]
        public DateTime? StartDate { get; set; }
        [Display(Name = "Create Date")]
        public DateTime CreateDate { get; set; }
        [Display(Name = "Creator User Number")]
        public int CreateId { get; set; }
        [Display(Name = "Supervisor Number")]
        public int? SupervisorNumber { get; set; }
        public bool Active { get; set; }
        [Display(Name = "Employment Type")]
        public string EmploymentType { get; set; }
        public int TeamId { get; set; }
        [Display(Name = "Team Name")]
        public IEnumerable<SelectListItem> TeamName { get; set; }
        [Display(Name = "Update ID")]
        public int? UpdateId { get; set; }
        [Display(Name = "Update Date")]
        public DateTime? UpdateDate { get; set; }
    }
    #endregion
}
