﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TDRP.DataModel
{
    [Table("Employees")]
    public class Employees
    {
        [Key]
        public int EmpSysId { get; set; }

        [Required]
        [Display(Name = "Employee Number")]
        public int EmployeeNumber { get; set; }

        [Display(Name = "Supervisor Number")]
        public int? SupervisorNumber { get; set; }

        [Required]
        [Display(Name = "Team ID")]
        public int TeamId { get; set; }

        [Display(Name = "Job Role ID")]
        public int? JobRoleId { get; set; }

        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string Title { get; set; }

        [Required]
        [Display(Name = "First Name")]
        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string LastName { get; set; }

        [Display(Name = "Employment Type")]
        public string EmploymentType { get; set; }

        public decimal FTE { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }

        [Required]
        public int CreateId { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime CreateDate { get; set; }
        
        public int? UpdateId { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdateDate { get; set; }

        [Required]
        public bool IsSupervisor { get; set; } 

        public Teams Teams { get; set; }
        
        public JobRoles JobRoles { get; set; }
    }

    // This will be used to display a table of employees in the employee area.
    public class ViewEmployeeList
    {
        public int AssignedWorkId { get; set; }
        [Display(Name = "Employee Number")]
        public int? EmployeeNumber { get; set; }
        public string EmployeeName { get; set; }
        public int FTE { get; set; }
        public int TeamId { get; set; }
        [Display(Name = "Team Name")]
        public string TeamName { get; set; }
        public bool UnnamedResource { get; set; }
    }

    [Table("AssignedWork")]
    public class AssignedWork
    {
        [Key]
        public int AssignedWorkId { get; set; }
        [Required]
        public int ProjectId { get; set; }
        // Added so managers can use 'U' numbers to assign, filter and search for people.
        [Display(Name = "Employee Number")]
        public int? EmployeeNumber { get; set; }
        // Team ID and UnnamedResource properties added for easier data filtering and unnamed resource assignment.
        public int? TeamId { get; set; }
        public bool? UnnamedResource { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }
        public int CreateId { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
        public int? UpdateId { get; set; }
        //Foreign Keys to join to other tables in the TDRP Database.
        [ForeignKey("ProjectId")]
        public Projects Projects { get; set; }
    }

    // Model for UnnamedResource table.
    [Table("UnnamedAssignments")]
    public class UnnamedAssignments
    {
        [Key]
        public int SysId { get; set; }
        public int TeamId { get; set; }
        public int ProjectId { get; set; }
        public int AssignedDays { get; set; }
        public int DaysInMonth { get; set; }
        public int MonthId { get; set; }
        public int Year { get; set; }
        public int CreateId { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime CreateDate { get; set; }
        // Nullable properties for the table.
        public int? UpdateId { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdateDate { get; set; }
    }
}
