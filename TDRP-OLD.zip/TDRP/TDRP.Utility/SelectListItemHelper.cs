﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace TDRP.Utility
{
    public class SelectListItemHelper
    {
        public static IEnumerable<SelectListItem> GetEmploymentTypes()
        {
            IList<SelectListItem> items = new List<SelectListItem>
            {
                new SelectListItem{Text = "Full Time", Value = "Full"},
                new SelectListItem{Text = "Part Time", Value="Part"},
                new SelectListItem{Text="Contractor", Value="Contract"}
            };
            return items;
        }

        public static IEnumerable<SelectListItem> Months()
        {
            IList<SelectListItem> items = new List<SelectListItem>
            {
                new SelectListItem {Text = "January", Value = "0"},
                new SelectListItem {Text = "February", Value = "1"},
                new SelectListItem {Text = "March", Value = "2"},
                new SelectListItem {Text = "April", Value = "3"},
                new SelectListItem {Text = "May", Value = "4"},
                new SelectListItem {Text = "June", Value = "5"},
                new SelectListItem {Text = "July", Value = "6"},
                new SelectListItem {Text = "August", Value = "7"},
                new SelectListItem {Text = "September", Value = "8"},
                new SelectListItem {Text = "October", Value = "9"},
                new SelectListItem {Text = "November", Value = "10"},
                new SelectListItem {Text = "December", Value = "11"}
            };
            return items;
        }
    }
}
