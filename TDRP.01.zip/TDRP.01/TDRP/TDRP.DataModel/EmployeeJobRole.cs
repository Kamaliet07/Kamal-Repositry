﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    [Table("EmployeeJobRole")]
    public class EmployeeJobRole
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int EmployeeId { get; set; }
        [ForeignKey("EmployeeId")]
        public Employees Employees { get; set; }            

        [Required]
        [Display(Name = "Job Role ID")]
        public int JobRoleId { get; set; }

        [ForeignKey("JobRoleId")]
        public JobRoles JobRoles { get; set; }

        [Required]
        [Display(Name = "Contract Type Id")]
        public int ContractTypeId { get; set; }

        [ForeignKey("ContractTypeId")]
        public ContractTypes ContractTypes { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal FTE { get; set; }

        [Required]
        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }

        [Required]
        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Update By")]
        public string Updateby { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdateDate { get; set; }
    }
}
