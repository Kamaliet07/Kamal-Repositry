﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    [Table("JobRoles")]
    public class JobRoles
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Job Role")]
        [StringLength(150, ErrorMessage = "Character length cannot exceed 150.")]
        public string JobRole { get; set; }

        [Required]
        [Display(Name = "Job Role Description")]
        [StringLength(450, ErrorMessage = "Character length cannot exceed 450.")]
        public string JobRoleDescription { get; set; }
                
        public bool Active { get; set; }
        
        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }
}
