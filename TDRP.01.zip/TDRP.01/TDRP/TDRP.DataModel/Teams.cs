﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    [Table("Teams")]
    public class Teams
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Team Name")]
        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string TeamName { get; set; }

        [Display(Name = "Team Details")]
        [StringLength(250, ErrorMessage = "Character length cannot exceed 250.")]
        public string TeamDetails { get; set; }

        [Required]
        public int BusinessUniteId { get; set; }

        [ForeignKey("BusinessUniteId")]
        public BusinessUnite BusinessUnite { get; set; }

        [Required]
        [Display(Name = "Team Lead Employee Number")]
        [StringLength(450)]
        public string TeamLeadId { get; set; }

        [Required]
        public bool Active { get; set; }

        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [Display(Name = "Creation Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Update By")]
        public string UpdateBy { get; set; }

        [Display(Name = "Update Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }
}
