﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TDRP.DataModel;

namespace TDRP.DataAccessLayer.DBContext
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
        }

        public DbSet<ApplicationUser> ApplicationUser { get; set; }        
        public DbSet<BusinessUnite> BusinessUnite { get; set; }
        public DbSet<ContractTypes> ContractTypes { get; set; }
        public DbSet<JobRoles> JobRoles { get; set; }
        public DbSet<Teams> Teams { get; set; }
        public DbSet<ProjectCategory> ProjectCategory { get; set; }
        public DbSet<Skills> Skills { get; set; }       
        public DbSet<Employees> Employees { get; set; }
        public DbSet<TeamResources> TeamResources { get; set; }
        public DbSet<TeamProjects> TeamProjects { get; set; }
        public DbSet<EmployeeSkills> EmployeeSkills { get; set; }
        public DbSet<EmployeeJobRole> EmployeeJobRole { get; set; }
        public DbSet<BusinessUniteLeads> BusinessUniteLeads { get; set; }
        public DbSet<ProjectAllocation> ProjectAllocation { get; set; }

    }
}
