﻿namespace TDRP.Utility
{
   public class AppConstant
    {
        #region Temp Message Values

        public const string StatusSubmitted = "Submitted";
        public const string StatusApproved = "Approved";
        public const string StatusRejected = "Rejected";

        #endregion

        #region User Roles

        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string Lead = "Lead";
        public const string Employee = "Employee";

        #endregion

        #region Stored Procedures

        public const string usp_GetUsersandRoles = "usp_GetUsersAndRoles";
        public const string usp_GetUsersandRolesById = "usp_GetUsersAndRolesById";
        public const string usp_GetTeams = "usp_GetTeams";
        public const string usp_GetUsersWithSpecificRole = "usp_GetUsersWithSpecificRole";
        public const string usp_GetBusinessUniteDetails = "usp_GetBusinessUniteDetails";
        public const string usp_GetBusinessUniteLeads = "usp_GetBusinessUniteLeads";
        public const string usp_SearchBusinessUniteLeads = "usp_SearchBusinessUniteLeads";
        public const string usp_CheckLeadAddedInBusinessUnite = "usp_CheckLeadAddedInBusinessUnite";
        public const string usp_GetMyTeamDetails = "usp_GetMyTeamDetails";
        public const string usp_GetTeamResources = "usp_GetTeamResources";
        public const string usp_SearchTeamResources = "usp_SearchTeamResources";
        public const string usp_GetEmployeeJobRole = "usp_GetEmployeeJobRole";
        public const string usp_GetMyTeamResources = "usp_GetMyTeamResources";
        public const string usp_GetMyTeamProjects = "usp_GetMyTeamProjects";
        public const string usp_GetAllManagerTeamProjects = "usp_GetAllManagerTeamProjects";
        public const string usp_SearchMyTeamResource = "usp_SearchMyTeamResource";
        public const string usp_GetProjectAllocatedResources = "usp_GetProjectAllocatedResources";
        public const string usp_GetResourceFteAvailability = "usp_GetResourceFteAvailability";
        public static string usp_DeleteResourceAllocation = "usp_DeleteResourceAllocation";
        public static string usp_GetResourceProjectCalendar = "usp_GetResourceProjectCalendar";
        public static string usp_GetMyBUResources = "usp_GetMyBUResources";
        public static string usp_GetBusinessUniteTeams = "usp_GetBusinessUniteTeams";
        public static string usp_GetTeamsProjectCalendar = "usp_GetTeamsProjectCalendar";
        public static string usp_GetTeamResourcesByTeamId = "usp_GetTeamResourcesByTeamId";
        public static string usp_RemoveProjectAllocation = "usp_RemoveProjectAllocation";
        public static string usp_UpdateProjectAllocationActiveStatus = "usp_UpdateProjectAllocationActiveStatus";
        public static string usp_UpdateEmployeeNumber = "usp_UpdateEmployeeNumber";
        #endregion
    }
}
