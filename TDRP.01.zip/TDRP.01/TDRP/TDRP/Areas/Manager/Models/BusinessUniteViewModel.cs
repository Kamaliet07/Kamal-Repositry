﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using TDRP.DataModel;

namespace TDRP.Areas.Manager.Models
{
    public class BUTeamLeadModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class BusinessUniteViewModel
    {
        public string Id { get; set; }
        public string BusinessUniteName { get; set; }
        public string BusinessUniteDetails { get; set; }
        public string OwnerID { get; set; }
        public string OwnerName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime CreatedDate { get; set; }
    }

    public class BULeadsModel
    {
        public BusinessUnite BusinessUnite { get; set; }
        public List<BUTeamLeadModel> BUTeamLead { get; set; }
    }
}
