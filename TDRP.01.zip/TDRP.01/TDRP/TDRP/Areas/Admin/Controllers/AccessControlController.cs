﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.Areas.Admin.Models;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class AccessControlController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ILogger<AccessControlController> _logger;
        private readonly RoleManager<IdentityRole> _roleManager;


        public AccessControlController(IUnitOfWork unitOfWork, UserManager<IdentityUser> userManager, 
            ILogger<AccessControlController> logger,
            RoleManager<IdentityRole> roleManager)
        {
            _unitOfWork = unitOfWork;
            _userManager = userManager;
            _logger = logger;
            _roleManager = roleManager;
        }

        public IActionResult Index()
        {
            try
            {
                List<UserRole> objuserRoles = _unitOfWork.spCall.ReturnList<UserRole>(AppConstant.usp_GetUsersandRoles).Result.ToList();
                return View(objuserRoles);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }            
        }

        [HttpGet]
        public IActionResult Upsert(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {

                    return View();
                }

                DynamicParameters param = new DynamicParameters();
                param.Add("@Id", id, DbType.String, ParameterDirection.Input);
                List<UserRole> objuserRoles = _unitOfWork.spCall.ReturnList<UserRole>(AppConstant.usp_GetUsersandRolesById, param).Result.ToList();
                if (objuserRoles.Count == 0)
                {
                    return NotFound();
                }
                return View(objuserRoles[0]);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }            
        }

        [HttpPost]        
        public async Task<IActionResult> UpdateUserPermission(string Id, bool active, string role, string prevRole, string empNumber)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(Id);                
                if (!string.IsNullOrEmpty(role))
                {
                    if(!string.Equals(prevRole, role))
                    {
                        if(string.IsNullOrEmpty(prevRole))
                        {
                            // Assigned Register User as Default Employee Role
                            await _userManager.AddToRoleAsync(user, role);
                        }
                        else
                        {
                            await _userManager.RemoveFromRoleAsync(user, prevRole);
                            // Assigned Register User as Default Employee Role
                            await _userManager.AddToRoleAsync(user, role);
                        }                        
                    }                    
                }

                user.EmailConfirmed = active;

                _unitOfWork.Save();
                
                if(!string.IsNullOrEmpty(empNumber))
                {
                    UpdateEmployeeNumber(Id, empNumber);
                }

                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error occurred while updating record." });
            } 
        }

        private void UpdateEmployeeNumber(string id, string empNumber)
        {
            DynamicParameters param = new DynamicParameters();
            param.Add("@Id", id, DbType.String, ParameterDirection.Input);
            param.Add("@EmpNumber", empNumber, DbType.String, ParameterDirection.Input);
            _unitOfWork.spCall.ExecuteWithoutReturn(AppConstant.usp_UpdateEmployeeNumber, param);
        }

        [HttpPost]
        public async Task<IActionResult> AddNewPermission(string permission)
        {
            try
            {                
                if (!string.IsNullOrEmpty(permission))
                {
                   await _roleManager.CreateAsync(new IdentityRole(permission));
                }                
                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(id);
                if (user == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                await _userManager.DeleteAsync(user);                
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
