﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.Areas.Admin.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class BusinessUniteController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<AccessControlController> _logger;        

        [BindProperty]
        public BusinessUniteModel businessUniteModel { get; set; }

        public BusinessUniteController(IUnitOfWork unitOfWork, ILogger<AccessControlController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;            
        }

        public IActionResult Index()
        {                      
            return View();
        }

        [HttpGet]
        public JsonResult GetBusinessUnites()
        {
            try
            {
                List<BusinessUniteTable> objbusinessUnite = _unitOfWork.spCall.ReturnList<BusinessUniteTable>(AppConstant.usp_GetBusinessUniteDetails).Result.ToList();
                return Json(new { data = objbusinessUnite });                
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }            
        }

        public IActionResult Upsert(int id)
        {
            try
            {
                BusinessUnite businessUnite = null;                
                if (id == 0)
                {
                    businessUnite = new BusinessUnite();
                }
                else
                {
                    businessUnite = _unitOfWork.businessUniteRepository.GetById(id);                   
                }

                DynamicParameters param = new DynamicParameters();
                param.Add("@role", AppConstant.Manager, DbType.String, ParameterDirection.Input);
                List<BusinessOwner> businessOwner = _unitOfWork.spCall.ReturnList<BusinessOwner>(AppConstant.usp_GetUsersWithSpecificRole, param).Result.ToList();

                businessUniteModel = new BusinessUniteModel()
                {
                    BusinessUnite = businessUnite,
                    BusinessOwner = businessOwner,                    
                };

                return View(businessUniteModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }            
        }

        [HttpPost]
        public IActionResult UpsertBusinessUnite(int Id, string uniteName, string uniteDesc, bool active, string ownerid)
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                BusinessUnite businessUnite = null;

                if (ModelState.IsValid)
                {
                    businessUnite = new BusinessUnite()
                    {
                        Id = Id,
                        BusinessUniteName = uniteName,
                        BusinessUniteDetails = uniteDesc,
                        Active = active,
                        OwnerId = ownerid,
                        CreatedBy = loginuserId,
                        CreatedDate = DateTime.Now
                    };

                    if (Id == 0)
                    {
                        _unitOfWork.businessUniteRepository.Add(businessUnite);
                    }
                    else
                    {
                        _unitOfWork.businessUniteRepository.Update(businessUnite);
                    }
                    _unitOfWork.Save();                    
                }

                //return RedirectToAction(nameof(Index));
                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while Updating Data." });
            }
        }        

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.businessUniteRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.businessUniteRepository.Remove(objFromDb);
                _unitOfWork.Save();
                //return RedirectToAction(nameof(Index));
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }            
        }                
    }
}
