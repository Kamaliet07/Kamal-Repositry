﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ContractTypeController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<ContractTypeController> _logger;

        public ContractTypeController(IUnitOfWork unitOfWork, ILogger<ContractTypeController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                List<ContractTypes> objContractTypes = _unitOfWork.contractTypeRepository.GetAll().ToList();
                return View(objContractTypes);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }        

        public IActionResult Upsert(int id)
        {
            try
            {
                ContractTypes contractTypes = null;
                if (id == 0)
                {
                    contractTypes = new ContractTypes();
                }
                else
                {
                    contractTypes = _unitOfWork.contractTypeRepository.GetById(id);
                }                

                return View(contractTypes);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpPost]
        public IActionResult Upsert(ContractTypes contractTypes)
        {
            try
            {
                if (ModelState.IsValid)
                {                   

                    if (contractTypes.Id == 0)
                    {
                        _unitOfWork.contractTypeRepository.Add(contractTypes);
                    }
                    else
                    {
                        _unitOfWork.contractTypeRepository.Update(contractTypes);
                    }
                    _unitOfWork.Save();
                }

                return RedirectToAction(nameof(Index));
                
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.contractTypeRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.contractTypeRepository.Remove(objFromDb);
                _unitOfWork.Save();
                //return RedirectToAction(nameof(Index));
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
