﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class SkillsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<AccessControlController> _logger;

        public SkillsController(IUnitOfWork unitOfWork, ILogger<AccessControlController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                List<Skills> objjobRoles = _unitOfWork.skillRepository.GetAll().ToList();
                return View(objjobRoles);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        public IActionResult Upsert(int id)
        {
            try
            {
                Skills skills = null;
                if (id == 0)
                {
                    skills = new Skills();
                }
                else
                {
                    skills = _unitOfWork.skillRepository.GetById(id);
                }

                return View(skills);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(Skills skills)
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                skills.CreatedBy = loginuser;                

                if (ModelState.IsValid)
                {
                    if (skills.Id == 0)
                    {
                        skills.CreatedDate = DateTime.Now;
                        _unitOfWork.skillRepository.Add(skills);
                    }
                    else
                    {
                        skills.UpdatedDate = DateTime.Now;
                        _unitOfWork.skillRepository.Update(skills);
                    }
                    
                    _unitOfWork.Save();

                    return RedirectToAction(nameof(Index));
                }

                return View(skills);

            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.skillRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.skillRepository.Remove(objFromDb);
                _unitOfWork.Save();
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
