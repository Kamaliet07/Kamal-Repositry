﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TDRP.Areas.Employee.Models
{
    public class TeamModel
    {
        public int Id { get; set; }
        public string TeamName { get; set; }
    }

    public class TeamProjectCalendar
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }        
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
