﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using TDRP.Areas.Lead.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Lead.Controllers
{
    [Authorize]
    [Area("Lead")]
    public class MyTeamProjectsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<MyTeamController> _logger;        

        public MyTeamProjectsController(IUnitOfWork unitOfWork, ILogger<MyTeamController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;            
        }

        public IActionResult Index()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                DynamicParameters param = new DynamicParameters();
                param.Add("@Id", loginuserId, DbType.String, ParameterDirection.Input);
                List<MyTeamProjectModel> teamProjects = _unitOfWork.spCall.ReturnList<MyTeamProjectModel>(AppConstant.usp_GetMyTeamProjects, param).Result.ToList();

                return View(teamProjects);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        public IActionResult Upsert(int id)
        {
            try
            {
                TeamProjectsModel teamProjects = null;
                if (id == 0)
                {
                    teamProjects = new TeamProjectsModel();
                }
                else
                {
                    var objTeamProj = _unitOfWork.teamProjectsRepository.GetById(id);
                    teamProjects = new TeamProjectsModel()
                    {
                        Id = objTeamProj.Id,
                        ProjectName = objTeamProj.ProjectName,
                        ProjectDescription = objTeamProj.ProjectDescription,
                        TeamId = objTeamProj.TeamId,
                        EstimatedBudget = objTeamProj.EstimatedBudget,
                        TotalExpenditure = objTeamProj.TotalExpenditure,
                        CategoryId = objTeamProj.CategoryId,
                        Active = objTeamProj.Active,
                        StartDate = objTeamProj.StartDate,
                        EndDate = objTeamProj.EndDate                        
                    };                   
                    teamProjects.ProjectCategory = _unitOfWork.projectCategoryRepository.GetById(objTeamProj.CategoryId).Name;
                    teamProjects.TeamName = _unitOfWork.teamRepository.GetById(objTeamProj.TeamId).TeamName;
                }

                return View(teamProjects);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(TeamProjectsModel teamProjectsmodel)
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                TeamProjects teamProjects = null;

                if (ModelState.IsValid)
                {
                    if (teamProjectsmodel.Id == 0)
                    {
                        teamProjects = new TeamProjects()
                        {
                            ProjectName = teamProjectsmodel.ProjectName,
                            ProjectDescription = teamProjectsmodel.ProjectDescription,
                            TeamId = teamProjectsmodel.TeamId,
                            EstimatedBudget = teamProjectsmodel.EstimatedBudget,
                            TotalExpenditure = teamProjectsmodel.TotalExpenditure,
                            CategoryId = teamProjectsmodel.CategoryId,                            
                            Active = teamProjectsmodel.Active,
                            StartDate = teamProjectsmodel.StartDate,
                            EndDate = teamProjectsmodel.EndDate,
                            CreatedBy = loginuser,
                            CreateDate = DateTime.Now
                        };
                        
                        _unitOfWork.teamProjectsRepository.Add(teamProjects);
                    }
                    else
                    {
                        // Update the allocation status of this project to resource.
                        UpdateStatusOfResourceAllocatedInProject(teamProjectsmodel.Id, teamProjectsmodel.Active);

                        teamProjects = new TeamProjects()
                        {
                            Id = teamProjectsmodel.Id,
                            ProjectName = teamProjectsmodel.ProjectName,
                            ProjectDescription = teamProjectsmodel.ProjectDescription,
                            TeamId = teamProjectsmodel.TeamId,
                            EstimatedBudget = teamProjectsmodel.EstimatedBudget,
                            TotalExpenditure = teamProjectsmodel.TotalExpenditure,
                            CategoryId = teamProjectsmodel.CategoryId,
                            Active = teamProjectsmodel.Active,
                            StartDate = teamProjectsmodel.StartDate,
                            EndDate = teamProjectsmodel.EndDate,
                            UpdateBy = loginuser,
                            UpdateDate = DateTime.Now
                        };
                        _unitOfWork.teamProjectsRepository.Update(teamProjects);
                    }

                    _unitOfWork.Save();

                    return RedirectToAction(nameof(Index));
                }                

                return View(teamProjectsmodel);

            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        private void UpdateStatusOfResourceAllocatedInProject(int id, bool active)
        {
            DynamicParameters param = new DynamicParameters();
            param.Add("@ProjId", id, DbType.Int32, ParameterDirection.Input);
            param.Add("@Active", active, DbType.Boolean, ParameterDirection.Input);
            _unitOfWork.spCall.ExecuteWithoutReturn(AppConstant.usp_UpdateProjectAllocationActiveStatus, param);           
        }

        [HttpGet]
        public JsonResult GetProjectCategory()
        {
            try
            {
                // Get the Selected Employee Details
                var objcategory = _unitOfWork.projectCategoryRepository.GetAll().Where(x => x.Active == true).ToList();

                return Json(new { success = true, data = objcategory });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        [HttpGet]
        public JsonResult GetMyTeams()
        {
            try
            {
                var loginuser = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

                // Get the list of Teams login user own
                var objcategory = _unitOfWork.teamRepository.GetAll().Where(x => x.TeamLeadId == loginuser).ToList();

                return Json(new { success = true, data = objcategory });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                if(DeleteResourceAllocation(id))
                {
                    var objFromDb = _unitOfWork.teamProjectsRepository.GetById(id);
                    if (objFromDb == null)
                    {
                        return Json(new { success = false, message = "Error while deleting." });
                    }
                    _unitOfWork.teamProjectsRepository.Remove(objFromDb);
                    _unitOfWork.Save();
                    return Json(new { success = true, message = "Delete success." });
                }
                return Json(new { success = false, message = "Error while deleting." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }

        private bool DeleteResourceAllocation(int projectid)
        {
            bool value = false;            
            DynamicParameters param = new DynamicParameters();
            param.Add("@ProjId", projectid, DbType.Int32, ParameterDirection.Input);
            param.Add("@Count", projectid, DbType.Int32, ParameterDirection.Output);
            int count = _unitOfWork.spCall.ExecuteWithReturnAsync(AppConstant.usp_DeleteResourceAllocation, param).Result;
            if(count>0)
            {
                value = true;
            }

            return value;
        }

        [HttpGet]
        public IActionResult ProjectAllocation(int id)
        {
            try
            {
                TeamProjectsModel teamProjects = null;
                List<ProjectResource> projectResource = null;
                if (id != 0)
                {
                    var objTeamProj = _unitOfWork.teamProjectsRepository.GetById(id);
                    teamProjects = new TeamProjectsModel()
                    {
                        Id = objTeamProj.Id,
                        ProjectName = objTeamProj.ProjectName,
                        ProjectDescription = objTeamProj.ProjectDescription,
                        TeamId = objTeamProj.TeamId,
                        EstimatedBudget = objTeamProj.EstimatedBudget,
                        TotalExpenditure = objTeamProj.TotalExpenditure,
                        CategoryId = objTeamProj.CategoryId,
                        Active = objTeamProj.Active,
                        StartDate = objTeamProj.StartDate,
                        EndDate = objTeamProj.EndDate
                    };
                    teamProjects.ProjectCategory = _unitOfWork.projectCategoryRepository.GetById(objTeamProj.CategoryId).Name;
                    teamProjects.TeamName = _unitOfWork.teamRepository.GetById(objTeamProj.TeamId).TeamName;

                    // Get the Resource List
                    DynamicParameters param = new DynamicParameters();
                    param.Add("@ProjectId", id, DbType.Int16, ParameterDirection.Input);
                    projectResource = _unitOfWork.spCall.ReturnList<ProjectResource>(AppConstant.usp_GetProjectAllocatedResources, param).Result.ToList();

                }
                else
                {
                    teamProjects = new TeamProjectsModel();
                    projectResource = new List<ProjectResource>();
                }

                ProjectAndResourceModel projectAndResourceModel = new ProjectAndResourceModel
                {
                    teamProjectsModel = teamProjects,
                    listResource = projectResource
                };

                return View(projectAndResourceModel);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public JsonResult SearchMyTeamResource(string search, int teamId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@namestr", search, DbType.String, ParameterDirection.Input);
                param.Add("@teamId", teamId, DbType.Int16, ParameterDirection.Input);
                List<EmployeesModel> resources = _unitOfWork.spCall.ReturnList<EmployeesModel>(AppConstant.usp_SearchMyTeamResource, param).Result.ToList();
                return Json(resources);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetProjectAllocatedResources(int projectId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();                
                param.Add("@ProjectId", projectId, DbType.Int16, ParameterDirection.Input);
                List<ProjectResource> projectResource = _unitOfWork.spCall.ReturnList<ProjectResource>(AppConstant.usp_GetProjectAllocatedResources, param).Result.ToList();
                return Json(projectResource);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpGet]
        public JsonResult GetResourceFteAvailability(int empId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@EmpId", empId, DbType.Int16, ParameterDirection.Input);
                List<ProjectResourceFTE> resourceSearch = _unitOfWork.spCall.ReturnList<ProjectResourceFTE>(AppConstant.usp_GetResourceFteAvailability, param).Result.ToList();
                //return Json(resourceSearch);
                return Json(new { success = true, data = resourceSearch });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }

        [HttpPost]
        public IActionResult AlignResourceInProject(int Id, int projId, int empId, decimal fteAssigned, bool active, DateTime startdate, DateTime endDate)
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                if (Id == 0)
                {
                    ProjectAllocation projectAllocation = new ProjectAllocation()
                    {
                        ProjectId = projId,
                        EmployeeId = empId,
                        FTEAssigned = fteAssigned,
                        Active = active,
                        StartDate = startdate,
                        EndDate = endDate,
                        CreatedBy = loginuserId,
                        CreatedDate = DateTime.Now,
                    };
                    _unitOfWork.projectAllocationRepository.Add(projectAllocation);
                }
                else
                {
                    ProjectAllocation projectAllocation = new ProjectAllocation()
                    {
                        Id = Id,
                        ProjectId = projId,
                        EmployeeId = empId,
                        FTEAssigned = fteAssigned,
                        Active = active,
                        StartDate = startdate,
                        EndDate = endDate,
                        UpdateBy = loginuserId,
                        UpdatedDate = DateTime.Now,
                    };
                    _unitOfWork.projectAllocationRepository.Update(projectAllocation);
                }
                
                _unitOfWork.Save();

                return Json(new { success = true, message = "Data Saved Successfully." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while fetching data." });
            }
        }

        [HttpDelete]
        public IActionResult DeleteResourceFromProject(int id)
        {
            try
            {
                var objFromDb = _unitOfWork.projectAllocationRepository.GetById(id);
                if (objFromDb == null)
                {
                    return Json(new { success = false, message = "Error while deleting." });
                }
                _unitOfWork.projectAllocationRepository.Remove(objFromDb);
                _unitOfWork.Save();
                //return RedirectToAction(nameof(Index));
                return Json(new { success = true, message = "Delete success." });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while deleting." });
            }
        }
    }
}
