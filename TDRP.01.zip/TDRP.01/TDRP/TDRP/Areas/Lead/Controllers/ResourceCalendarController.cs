﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.Areas.Lead.Models;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Lead.Controllers
{
    [Authorize]
    [Area("Lead")]
    public class ResourceCalendarController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<ResourceCalendarController> _logger;

        public ResourceCalendarController(IUnitOfWork unitOfWork, ILogger<ResourceCalendarController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                var loginuserId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                DynamicParameters param = new DynamicParameters();
                param.Add("@Id", loginuserId, DbType.String, ParameterDirection.Input);
                List<MyTeamResourceModel> teamResources = _unitOfWork.spCall.ReturnList<MyTeamResourceModel>(AppConstant.usp_GetMyTeamResources, param).Result.ToList();

                return View(teamResources);
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public JsonResult GetResourceProjectCalendar(int empId)
        {
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@EmpId", empId, DbType.Int16, ParameterDirection.Input);
                List<ResourceCalendar> projectResource = _unitOfWork.spCall.ReturnList<ResourceCalendar>(AppConstant.usp_GetResourceProjectCalendar, param).Result.ToList();
                
                return Json(new { success = true, data = projectResource });
            }
            catch (Exception e)
            {
                _logger.LogWarning(e.Message);
                return Json(new { success = false, message = "Error while retriving data." });
            }
        }
    }
}
