﻿$(document).ready(function () {
    loadBusinessUnites();
});

function loadBusinessUnites() {
    $('#tblMyBusinessUnite').DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,        
        "ajax": {
            "url": "/Manager/MyBusinessUnite/GetBusinessUnites",
            "type": "GET",
            "dataType": "json"
        },        
        "columns": [
            {
                "data": "businessUniteName",
                "title": "Business Unit",
                "render": function (data, type, row) {
                    return `<a href="/Manager/MyBusinessUnite/Upsert/${row.id}">${data}</a>`;
                },
                "width": "25%"
            },
            { "data": "businessUniteDetails", "title": "Unit Details", "width": "45%" },
            { "data": "ownerName", "title": "Unit Owner", "width": "20%" },
            {
                "data": "id",
                "title": "Leads",
                "className": "text-center",
                "render": function (data) {
                    return `<div class="text-center">
                                <a href="/Manager/MyBusinessUnite/AddLeads/${data}" style='cursor:pointer;' class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus-square"></i> Lead
                                </a>
                            </div>
                            `;
                }, "width": "10%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    })
};


function upsertBusinessUnite() {
    var uniteId = $("#hdnbuId").val();
    var uniteName = $("#txtuniteName").val();
    var uniteDesc = $("#txtdesc").val();
    var active = document.getElementById("chkActive").checked;    
    if (uniteName == null || uniteDesc == null || active == false) {
        swal({
            title: "Validation Status",
            text: "All fields are mandatory!",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Manager/MyBusinessUnite/Upsert',
            data: { Id: uniteId, uniteName: uniteName, uniteDesc: uniteDesc, active: active},
            type: "POST",
            success: function (data) {
                if (data.success) {
                    window.location.href = '/Manager/MyBusinessUnite';
                }
                else {
                    swal({
                        title: "Error Occurred! Try again.",
                        type: "warning"
                    });
                }
            }
        });
    }
}

$(function () {
    $('#tblBuLeads').DataTable({
        'paging': true,
        'pageLength': 3,
        'lengthChange': false,
        'searching': false,
        'ordering': false,
        'info': false,
        'autoWidth': false
    });
});

$("#buLeads").autocomplete({
    source: function (request, response) {
        var name = $("#buLeads").val();
        if (name.length > 4) {
            $.ajax({
                url: '/Manager/MyBusinessUnite/GetBuLead',
                type: "GET",
                dataType: "json",
                data: { search: name },
                success: function (data) {
                    response(data.map(function (item) {
                        return { label: item.name, value: item.name, id: item.id };
                    }));
                },
                error: function (data) {
                    alert(data.responseText);
                }
            });
        }
    },
    select: function (event, ui) {
        $('#leadId').val(ui.item.id);
    }
});


function addBULeads() {
    var uniteId = $("#hdnId").val();
    var leadId = $("#leadId").val();
    if (uniteId == 0 || leadId == null) {
        swal({
            title: "Active Status",
            text: "All find the leads to add!",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Manager/MyBusinessUnite/AddBULeads',
            data: { Id: uniteId, leadsId: leadId },
            type: "POST",
            success: function (data) {
                if (data.success) {
                    window.location.reload(true);
                }
                else {
                    swal({
                        title: "Information",
                        text: "Resource Already Added!",
                        type: "warning"
                    });
                    return false;
                }
            }
        });
    }
}

function deleteLeads(Id) {
    swal({
        title: "Delete Leads?",
        text: "Are you sure you want to remove",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: "/Manager/MyBusinessUnite/DeleteBULead",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}