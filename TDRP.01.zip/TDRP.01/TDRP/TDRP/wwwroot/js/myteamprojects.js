﻿$(document).ready(function () {
    $("#projCatDiv").hide();
    $("#teamDiv").hide();
    $("#divAddResource").hide();
    loadMyTeams();
    loadProjectCategory();    
});

$("#enbTeams").click(function () {    
    $("#teamDiv").show();
});

$("#enbCat").click(function () {    
    $("#projCatDiv").show();
});

$("#hideTeam").click(function () {
    $("#teamDiv").hide();
});

$("#hideCat").click(function () {
    $("#projCatDiv").hide();
});

// BS-Stepper Init
document.addEventListener('DOMContentLoaded', function () {
    window.stepper = new Stepper(document.querySelector('.bs-stepper'))
})

function loadMyTeams() {
    var ddlTeams = $("#sltTeam");
    $.ajax({
        url: '/Lead/MyTeamProjects/GetMyTeams',
        dataType: "json",
        type: "GET",
        success: function (data) {
            if (data.success == true) {
                var dataOptions = "";
                if (data.data.length > 0) {
                    dataOptions += '<option selected="selected" value="0">--Please Select Team--</option>';
                    for (var i = 0; i < data.data.length; i++) {
                        dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].teamName + '</option>';
                    }
                    ddlTeams.html(dataOptions);
                }                
            }
        },
        failure: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        },
        error: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        }
    });
}

function loadProjectCategory() {
    var ddlProjCat = $("#sltProjCategory");
    $.ajax({
        url: '/Lead/MyTeamProjects/GetProjectCategory',
        dataType: "json",
        type: "GET",
        success: function (data) {
            if (data.success == true) {
                var dataOptions = "";
                if (data.data.length > 0) {
                    dataOptions += '<option selected="selected" value="0">--Please Select Category--</option>';
                    for (var i = 0; i < data.data.length; i++) {
                        dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].name + '</option>';
                    }
                    ddlProjCat.html(dataOptions);
                }                
            }
        },
        failure: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        },
        error: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        }
    });
}

$("#sltProjCategory").change(function () {
    var catId = $("#sltProjCategory").val();
    var cattext = $("#sltProjCategory").children("option:selected").text();
    $("#hdnCategoryId").val(catId);
    $("#lblCatname").val(cattext);
});

$("#sltTeam").change(function () {
    var tmId = $("#sltTeam").val();
    var teamtext = $("#sltTeam").children("option:selected").text();
    $("#hdnTeamId").val(tmId);
    $("#lblTmname").val(teamtext);
});

$("#projectResource").autocomplete({
    source: function (request, response) {
        var name = $("#projectResource").val();
        if (name.length > 4) {
            var teamId = $("#hdnteamId").val();
            $.ajax({
                url: '/Lead/MyTeamProjects/SearchMyTeamResource',
                type: "GET",
                dataType: "json",
                data: { search: name, teamId: teamId },
                success: function (data) {
                    response(data.map(function (item) {
                        return { label: item.employeeName, value: item.employeeName, id: item.id };
                    }));
                },
                error: function (data) {
                    alert(data.responseText);
                }
            });
        }
    },
    select: function (event, ui) {
        $('#empId').val(ui.item.id);
    }
});

$(function () {
    $('#tblProjectResource').DataTable({
        'paging': true,
        'pageLength': 3,
        'lengthChange': false,
        'searching': false,
        'ordering': false,
        'info': false,
        'autoWidth': false
    });
});

$("#btnaddresource").click(function () {
    var active = $("#hdnActive").val();
    if (active) {
        var resourceId = $("#empId").val();
        $('#hdnAllocationId').val("");
        $("#divtblResource").hide();
        $("#divAddResource").show();
        $.ajax({
            url: '/Lead/MyTeamProjects/GetResourceFteAvailability',
            dataType: "json",
            type: "GET",
            data: { empId: resourceId },
            success: function (data) {
                if (data.success == true) {
                    if (data.data.length > 0) {
                        $('#txtname').val(data.data[0].employeeName);
                        $('#txtfteAss').val(data.data[0].fte);
                        $('#txtfteusd').val(data.data[0].fteConsumed);
                        $('#txtfteAvlb').val(data.data[0].fteAvailable);
                        $('#chkActive').val(data.data[0].active);
                    }
                }
            },
            failure: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            },
            error: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        });
    }
    else {
        swal({
            title: "Information",
            text: "Project is not active! You are not allowed to add resource.",
            type: "warning"
        });
        return false;
    }
});

function AddResourceInProject() {    
    var projAllcId = $("#hdnAllocationId").val();
    var projId = $("#hdnId").val();
    var resourceId = $("#empId").val();
    var txtfteaval = $("#txtfteAvlb").val();
    var txtfteassign = $("#txtfteall").val();
    var active = document.getElementById("chkActive").checked;
    var startdt = $("#txtstrdate").val();    
    var enddate = $("#txtenddate").val();
    if (startdt == null || enddate == null) {
        swal({
            title: "Allocation Date Error",
            text: "Please Select the allocation start and end date.",
            type: "warning"
        });
        return false;
    }
    if (txtfteassign > txtfteaval) {
        swal({
            title: "FTE Error",
            text: "Assigned FTE value cannot be greater then available FTE.",
            type: "warning"
        });
        return false;
    }
    if (active == false) {
        swal({
            title: "Active Assignment",
            text: "Please select the Active Checkbox.",
            type: "warning"
        });
        return false;
    }
    $.ajax({
        async: false,
        url: '/Lead/MyTeamProjects/AlignResourceInProject',
        data: { Id: projAllcId, projId: projId, empId: resourceId, fteAssigned: txtfteassign, active: active, startdate: startdt, endDate: enddate},
        type: "POST",
        success: function (data) {
            if (data.success) {
                window.location.reload(true);
            }
            else {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        }
    });
}

function UpdateResourceAllocation(empId, ProAllocId) {
    $('#hdnAllocationId').val(ProAllocId);
    $("#empId").val(empId);
    $("#divtblResource").hide();
    $("#divAddResource").show();
    $.ajax({
        url: '/Lead/MyTeamProjects/GetResourceFteAvailability',
        dataType: "json",
        type: "GET",
        data: { empId: empId },
        success: function (data) {
            if (data.success == true) {
                if (data.data.length > 0) {
                    $('#txtname').val(data.data[0].employeeName);
                    $('#txtfteAss').val(data.data[0].fte);
                    $('#txtfteusd').val(data.data[0].fteConsumed);
                    $('#txtfteAvlb').val(data.data[0].fteAvailable);
                }
            }
        },
        failure: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        },
        error: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        }
    });
}

function DeleteResourceFromProject(Id) {
    swal({
        title: "Delete Team?",
        text: "This action cannot be reverted, are you sure you want to remove this Resource?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Lead/MyTeamProjects/DeleteResourceFromProject",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Team not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Team not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

$('#txtstrdate').change(function () {
    var srtdate = $(this).val();
    var projStrtDate = $("#projStrtDt").val().slice(0, 10);    
    projStrtDate = projStrtDate.split("/").reverse().join("-");
    if (srtdate < projStrtDate) {
        $(this).val("");
        swal({
            title: "Allocation start date cannot be before project start date.",
            type: "warning"
        });
    }

    var projendDate = $("#projenddate").val().slice(0, 10);
    projendDate = projendDate.split("/").reverse().join("-");
    if (srtdate > projendDate) {
        $(this).val("");
        swal({
            title: "Allocation start date cannot be after the project end date.",
            type: "warning"
        });
    }    
});

$('#txtenddate').change(function () {
    var enddate = $(this).val();
    var projendDate = $("#projenddate").val().slice(0, 10);
    projendDate = projendDate.split("/").reverse().join("-");
    if (enddate > projendDate) {
        $(this).val("");
        swal({
            title: "Allocation end date cannot be after the project end date.",
            type: "warning"
        });
    }

    var projStrtDate = $("#projStrtDt").val().slice(0, 10);
    projStrtDate = projStrtDate.split("/").reverse().join("-");
    if (enddate < projStrtDate) {
        $(this).val("");
        swal({
            title: "Allocation end date cannot be before project start date.",
            type: "warning"
        });
    }
});

$("#btnReturn").click(function () {
    $("#divtblResource").show();
    $("#divAddResource").hide();
});