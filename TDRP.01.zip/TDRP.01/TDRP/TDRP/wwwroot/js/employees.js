﻿$(function () {
    $("#tblAdminEmployees").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblAdminEmployees_wrapper .col-md-6:eq(0)');
});

$(function () {
    $("#tblEmployees").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblEmployees_wrapper .col-md-6:eq(0)');
});

$(function () {
    $("#tblmyResource").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblmyResource_wrapper .col-md-6:eq(0)');
});

$(function () {
    $("#tblContractTypes").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblContractTypes_wrapper .col-md-6:eq(0)');
});

function deleteEmployeeFromAdmin(Id) {
    swal({
        title: "Delete Business Unite?",
        text: "This action cannot be reverted, are you sure you want to remove this Resource?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/Employee/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Resource not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Resource not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function deleteContractType(Id) {
    swal({
        title: "Delete Contract Type?",
        text: "This action cannot be reverted, are you sure you want to remove this contract Type?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/ContractType/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Data not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Data not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}