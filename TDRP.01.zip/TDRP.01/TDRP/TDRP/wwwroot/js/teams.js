﻿$(document).ready(function () {
    loadTeams();
    var assbuId = $("#hdnbuId").val();
    if (assbuId != 0) {

        loadTeamLeadsddl(assbuId);
    }    
});

function loadTeams() {
    $('#tblTeam').DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,        
        "ajax": {
            "url": "/Manager/Team/GetManagerTeam",
            "type": "GET",
            "dataType": "json"
        },
        "columnDefs": [
            { "className": "dt-center", "targets": "_all" }
        ],
        "columns": [
            { "data": "teamName", "title": "Team Name", "width": "20%" },
            { "data": "teamDetails", "title": "Team Details", "width": "30%" },
            { "data": "teamLead", "title": "Team Owner", "width": "15%" },
            { "data": "businessUniteName", "title": "Business Unit", "width": "20%" },
            {
                "data": "id",
                "title": "Action",
                "className": "text-center",
                "render": function (data) {
                    return `<div class="text-center">
                                <a href="/Manager/Team/Upsert/${data}" class="btn btn-box-tool" style='cursor:pointer;'>
                                    <i class="fas fa-edit"></i></a>
                                &nbsp;
                                <a onclick= DeleteTeam(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class="fas fa-trash-alt"></i> </a>
                            </div>
                            `;
                }, "width": "15%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    })
}


function SubmitTeams() {
    var teamId = $("#hdnId").val();
    var tmName = $("#txtTeamnm").val();
    var tmDesc = $("#txtTeamdes").val();
    var active = document.getElementById("chkActive").checked;
    var e = document.getElementById("ddlBusinessUnite");
    var buid = e.value;
    var ld = document.getElementById("ddlBuLeads");
    var leadid = ld.value;
    if (tmName === "" || tmDesc === "" || buid == 0 || leadid == 0) {
        swal({
            title: "Active Status",
            text: "Please Provide Details of mandatory Field!",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Manager/Team/Upsert',
            data: { Id: teamId, teamName: tmName, teamDesc: tmDesc, active: active, buid: buid, leadid: leadid },
            type: "POST",
            success: function (data) {
                if (data.success) {
                    window.location.href = '/Manager/Team';
                }
                else {
                    swal({
                        title: "Error Occurred! Try again.",
                        type: "warning"
                    });
                }
            }
        });
    }
}

function UpdateTeams() {
    var teamId = $("#hdnId").val();
    var tmName = $("#txtTeamnm").val();
    var tmDesc = $("#txtTeamdes").val();
    var active = document.getElementById("chkActive").checked;    
    var buid = $("#hdnbuId").val();
    var ld = document.getElementById("ddlBuLeadsAss");
    var leadid = ld.value;
    if (tmName === "" || tmDesc === "" || leadid == 0) {
        swal({
            title: "Active Status",
            text: "Please Provide Details of mandatory Field!",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Manager/Team/Upsert',
            data: { Id: teamId, teamName: tmName, teamDesc: tmDesc, active: active, buid: buid, leadid: leadid },
            type: "POST",
            success: function (data) {
                if (data.success) {
                    window.location.href = '/Manager/Team';
                }
                else {
                    swal({
                        title: "Error Occurred! Try again.",
                        type: "warning"
                    });
                }
            }
        });
    }
}

function DeleteTeam(Id) {
    swal({
        title: "Delete Team?",
        text: "This action cannot be reverted, are you sure you want to remove this Team?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Manager/Team/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Team not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Team not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function changeddlBU(obj) {

    var ddlLeads = $("#ddlBuLeads");
    ddlLeads.empty().append('<option selected="selected" value="0" disabled = "disabled">Loading.....</option>');
    var buId = obj.options[obj.selectedIndex].value;
    if (buId != 0) {
        $.ajax({
            url: '/Manager/Team/GetBusinessUniteLeads',
            dataType: "json",
            data: { "buId": buId },
            type: "GET",
            success: function (data) {                
                var dataOptions = "";
                dataOptions += '<option selected="selected" value="0">--Please Select Lead--</option>';
                for (var i = 0; i < data.data.length; i++) {
                    dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].name + '</option>';
                }
                ddlLeads.html(dataOptions);
            },
            failure: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            },
            error: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        });
    }    
}

function loadTeamLeadsddl(buId) {    
    var ddlLeadsAss = $("#ddlBuLeadsAss");    
    $.ajax({
        url: '/Manager/Team/GetBusinessUniteLeads',
        dataType: "json",
        data: { "buId": buId },
        type: "GET",
        success: function (data) {
            var dataOptions = "";
            dataOptions += '<option selected="selected" value="0">--Please Select Lead--</option>';
            for (var i = 0; i < data.data.length; i++) {
                dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].name + '</option>';
            }
            ddlLeadsAss.html(dataOptions);                       
        },
        failure: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        },
        error: function (data) {
            swal({
                title: "Error Occurred! Try again.",
                type: "warning"
            });
        }
    });

}
