﻿var dataTable;

$(document).ready(function () {
    $("#tblteamproj").hide();
    loadEmptyCalender();
});

$(function () {
    $('#tblmybuTeams').DataTable({
        'paging': true,
        'pageLength': 10,
        'lengthChange': false,
        'searching': false,
        'ordering': true,
        'info': false,
        'autoWidth': false
    });
});

$("#tblview").click(function () {
    $("#clndteamproj").hide();
    $("#tblteamproj").show();    
    var teamid = $('#hdnteamId').val();
    if (teamid > 0) {       
        loadTeamsProjectsTable(teamid);
    }    
});

$("#clndrview").click(function () {
    $("#tblteamproj").hide();
    $("#clndteamproj").show();    
});


$('#tblmybuTeams').on('click', 'tbody tr', function (event) {
    $(this).addClass('highlight').siblings().removeClass('highlight');
});

function loadEmptyCalender() {
    var Calendar = FullCalendar.Calendar;
    var calendarEl = document.getElementById('calendar');
    var calendar = new Calendar(calendarEl, {
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        themeSystem: 'bootstrap',
        //Random default events
        events: [

        ],
        editable: false,
    });

    calendar.render();
}

function loadTeamsProjects(teamId) {
    $("#tblteamproj").hide();
    $("#clndteamproj").show();
    $('#hdnteamId').val(teamId);
    var eventsarray = [];
    $.ajax({
        url: '/Employee/ProjectCalendar/GetTeamsProjectCalendar',
        type: "GET",
        dataType: "JSON",
        data: { teamId: teamId },
        success: function (result) {
            if (result.data.length > 0) {
                var colorArray = ['#f39c12', "#669933", "#03d3fc", "#3399FF", "#a103fc", "#fc03c2", '#f56954'];
                for (var i = 0; i < result.data.length; i++) {
                    eventsarray.push(
                        {
                            title: result.data[i].projectName,
                            start: moment(result.data[i].startDate).format("yyyy-MM-DD"),
                            end: moment(result.data[i].endDate).format("yyyy-MM-DD"),
                            backgroundColor: colorArray[i]
                        });
                };
            }

            if (calendar) calendar.destroy();
            var Calendar = FullCalendar.Calendar;
            var calendarEl = document.getElementById('calendar');
            var calendar = new Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                themeSystem: 'bootstrap',

                events: eventsarray,

                editable: false
            });

            calendar.render();
        }
    });
}

function loadTeamsProjectsTable(teamId) {
    dataTable = $("#tblTeamsProject").DataTable({
        destroy: true,
        "ajax": {
            "url": "/Employee/ProjectCalendar/GetTeamsProjectCalendar",
            "dataType": "json",
            "type": "GET",
            "data": { "teamId": teamId }
        },
        "columns": [
            { "data": "projectName", "title": "Project Name", "width": "20%"  },
            { "data": "projectDescription", "title": "Project Description", "width": "40%" },
            {
                "data": "startDate", "title": "Start Date", "width": "20%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Start date not found.</p>";
                    }
                }
            },
            {
                "data": "endDate", "title": "End Date", "width": "20%",
                // Renders the date in a different format so it is more user friendly.
                "render": function (data) {
                    if (data != null) {
                        return data.split("T")[0];
                    } else {
                        return "<p>Start date not found.</p>";
                    }
                }
            },                        
        ],
        
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}