﻿$(function () {
    $("#tblJobRoles").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblJobRoles_wrapper .col-md-6:eq(0)');
});

$(function () {
    $("#tblSkills").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#tblSkills_wrapper .col-md-6:eq(0)');
});

function deleteJobRole(Id) {
    swal({
        title: "Delete Job Role?",
        text: "This action cannot be reverted, are you sure you want to remove this Job Role?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/JobRoles/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Unite not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Unite not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function deleteSkills(Id) {
    swal({
        title: "Delete Skill?",
        text: "This action cannot be reverted, are you sure you want to remove this Skill?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/Skills/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Unite not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Unite not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

function deleteCategory(Id) {
    swal({
        title: "Delete Skill?",
        text: "This action cannot be reverted, are you sure you want to remove this Category?",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            // Post details to the controller action method that will post the data on to database tables.
            $.ajax({
                url: "/Admin/ProjectCategory/Delete",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Unite not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Unite not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}