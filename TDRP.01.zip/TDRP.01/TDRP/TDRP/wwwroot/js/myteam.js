﻿$(document).ready(function () {
    loadMyTeam();
});

function loadMyTeam() {
    $('#tblMyTeam').DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false, 'searching': false,
        "ajax": {
            "url": "/Lead/MyTeam/GetMyTeam",
            "type": "GET",
            "dataType": "json"
        },
        "columnDefs": [
            { "className": "dt-center", "targets": "_all" }
        ],
        "columns": [
            {
                "data": "teamName",
                "title": "Team Name",
                "render": function (data, type, row) {
                    return `<a href="/Lead/MyTeam/Upsert/${row.id}">${data}</a>`;
                },
                "width": "20%"
            },
            { "data": "teamDetails", "title": "Team Details", "width": "35%" },
            { "data": "businessUniteName", "title": "Business Unit", "width": "20%" },
            { "data": "createdBy", "title": "Created By", "width": "15%" },
            {
                "data": "id",
                "title": "Resource",
                "className": "text-center",
                "render": function (data) {
                    return `<div class="text-center">
                                <a href="/Lead/MyTeam/AddTeamResource/${data}" style='cursor:pointer;' class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus-square"></i> Add</a>
                            </div>
                            `;
                }, "width": "10%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    })
};

$("#teamResource").autocomplete({
    source: function (request, response) {
        var name = $("#teamResource").val();
        if (name.length > 4) {
            $.ajax({
                url: '/Lead/MyTeam/SearchResource',
                type: "GET",
                dataType: "json",
                data: { search: name },
                success: function (data) {
                    response(data.map(function (item) {
                        return { label: item.employeeName, value: item.employeeName, id: item.id };
                    }));
                },
                error: function (data) {
                    alert(data.responseText);
                }
            });
        }
    },
    select: function (event, ui) {
        $('#empId').val(ui.item.id);
    }
});

function addTeamResource() {
    var teamId = $("#hdnId").val();
    var empId = $("#empId").val();
    if (teamId == 0 || empId == null) {
        swal({
            title: "Active Status",
            text: "Please find the resource to add!",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Lead/MyTeam/AddResourceInTeam',
            data: { Id: teamId, empId: empId },
            type: "POST",
            success: function (data) {
                if (data.success) {
                    window.location.reload(true);
                }
                else {
                    swal({
                        title: "Not Added! Try again.",
                        type: "warning"
                    });
                }
            }
        });
    }
}

function deleteLeads(Id) {
    swal({
        title: "Delete Resource?",
        text: "Are you sure you want to remove Resource",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: "/Lead/MyTeam/DeleteResourceFromTeam",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        window.location.reload(true);
                    }
                    if (data.error) {
                        swal({
                            title: "Not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}

$(function () {
    $('#tblTeamResource').DataTable({
        'paging': true,
        'pageLength': 3,
        'lengthChange': false,
        'searching': false,
        'ordering': false,
        'info': false,
        'autoWidth': false
    });
});