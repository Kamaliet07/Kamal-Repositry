﻿var dataTableProjects;

$(document).ready(function () {
    loadTeamResourceTable(0);
});

function changeddlBU(obj) {

    var ddlbuTeam = $("#ddlBuTeam");
    ddlbuTeam.empty().append('<option selected="selected" value="0" disabled = "disabled">Loading.....</option>');
    var buId = obj.options[obj.selectedIndex].value;
    $("#hdnbuId").val(buId);
    if (buId != 0) {
        $.ajax({
            url: '/Manager/TeamResource/GetBusinessUnitTeams',
            dataType: "json",
            data: { "buId": buId },
            type: "GET",
            success: function (data) {
                var dataOptions = "";
                dataOptions += '<option selected="selected" value="0">--Please Select Team--</option>';
                for (var i = 0; i < data.data.length; i++) {
                    dataOptions += '<option value="' + data.data[i].id + '">' + data.data[i].teamName + '</option>';
                }
                ddlbuTeam.html(dataOptions);
            },
            failure: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            },
            error: function (data) {
                swal({
                    title: "Error Occurred! Try again.",
                    type: "warning"
                });
            }
        });
    }
}

function changeddlTeams(obj) {

    var teamId = obj.options[obj.selectedIndex].value;
    $("#hdnteamId").val(teamId);
    if (teamId != 0) {
        loadTeamResourceTable(teamId);
    }
}

function loadTeamResourceTable(teamId) {
    dataTableProjects = $("#tblTeamsResource").DataTable({
        'paging': true,
        'pageLength': 10,
        'lengthChange': false,
        'searching': false,
        'ordering': true,
        'info': false,
        'autoWidth': false,
        'destroy': true,
        "ajax": {
            "url": "/Manager/TeamResource/GetTeamResourcesByTeamId",
            "dataType": "json",
            "type": "GET",
            "data": { "teamId": teamId }
        },
        "columns": [
            { "data": "employeeName", "title": "Employee", "width": "30%" },
            { "data": "teamName", "title": "Team Name", "width": "30%" },
            { "data": "businessUniteName", "title": "Unit Name", "width": "35%" },
            {
                "data": "id",
                "title": "Action",
                "render": function (data) {
                    return `<div>                                
                                <a onclick= DeleteResourceFromTeam(${data}) class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class="fas fa-trash-alt"></i> </a>
                            </div>
                            `;
                }, "width": "5%"
            }
        ],

        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

$("#teamResource").autocomplete({
    source: function (request, response) {
        var name = $("#teamResource").val();
        if (name.length > 4) {
            $.ajax({
                url: '/Manager/TeamResource/SearchResource',
                type: "GET",
                dataType: "json",
                data: { search: name },
                success: function (data) {
                    response(data.map(function (item) {
                        return { label: item.employeeName, value: item.employeeName, id: item.id };
                    }));
                },
                error: function (data) {
                    alert(data.responseText);
                }
            });
        }
    },
    select: function (event, ui) {
        $('#empId').val(ui.item.id);
    }
});

$("#btnaddresource").click(function () {    
    checkifteamactiveandAdd();
});

function checkifteamactiveandAdd() {
    var teamId = $("#hdnteamId").val();
    $.ajax({        
        url: '/Manager/TeamResource/CheckIfTeamActive',
        type: "GET",
        dataType: "json",
        data: { teamId: teamId},        
        success: function (data) {
            if (data.success) {
                addTeamResource();
            }
            else {                
                swal({
                    title: "Information",
                    text: "Team is not active! You are not allowed to add resource.",
                    type: "warning"
                });
                return false;
            }
        }
    });
}

function addTeamResource() {
    var teamId = $("#hdnteamId").val();
    var empId = $("#empId").val();
    if (teamId == 0 || empId == null) {
        swal({
            title: "Information",
            text: "Please select the team and find the resource to add!",
            type: "warning"
        });
        return false;
    }
    else {
        $.ajax({
            async: false,
            url: '/Manager/TeamResource/AddResourceInTeam',
            data: { Id: teamId, empId: empId },
            type: "POST",
            success: function (data) {
                if (data.success) {
                    /* window.location.reload(true);*/
                    dataTableProjects.ajax.reload(null, false);
                }
                else {
                    swal({
                        title: "Information",
                        text: "Resource already added into Team! Please remove resource from the team allocated first and try again.",
                        type: "warning"
                    });
                    return false;
                }
            }
        });
    }
}

function DeleteResourceFromTeam(Id) {
    swal({
        title: "Delete Resource?",
        text: "Are you sure you want to remove this resource from team? His/Her project allocation within this team will also be removed.",
        buttons: true,
        showCancelButton: true,
        cancelButtonClass: "btn-danger",
        type: "warning"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                url: "/Manager/TeamResource/DeleteResourceFromTeam",
                dataType: "json",
                data: { "id": Id },
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        dataTableProjects.ajax.reload(null, false);
                    }
                    if (data.error) {
                        swal({
                            title: "Not removed! Try again.",
                            type: "warning"
                        });
                    }
                },
                error: function (data) {
                    swal({
                        title: "Not removed! Try again.",
                        type: "warning"
                    });
                }
            });
        };
    });
}