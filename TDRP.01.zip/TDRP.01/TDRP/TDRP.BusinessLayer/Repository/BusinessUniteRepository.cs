﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class BusinessUniteRepository : Repository<BusinessUnite>, IBusinessUniteRepository
    {
        private readonly ApplicationDbContext _db;

        public BusinessUniteRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }
        public IEnumerable<SelectListItem> GetBusinessUnitesForDropDown()
        {
            return _db.BusinessUnite.Select(i => new SelectListItem()
            {
                Text = i.BusinessUniteName,
                Value = i.Id.ToString(),
            });
        }

        public List<BusinessUnite> GetAllBusinessUnites()
        {
            List<BusinessUnite> uniteDetails = new List<BusinessUnite>();
            uniteDetails = _db.BusinessUnite.AsList();
            return uniteDetails;
        }             

        public void Update(BusinessUnite businessUnite)
        {
            var objFromDb = _db.BusinessUnite.FirstOrDefault(s => s.Id == businessUnite.Id);
            objFromDb.BusinessUniteName = businessUnite.BusinessUniteName;
            objFromDb.BusinessUniteDetails = businessUnite.BusinessUniteDetails;
            objFromDb.OwnerId = businessUnite.OwnerId;
            objFromDb.Active = businessUnite.Active;
            objFromDb.UpdatedDate = DateTime.Now;
            objFromDb.UpdateBy = businessUnite.UpdateBy;
            _db.SaveChanges();
        }
    }
}
