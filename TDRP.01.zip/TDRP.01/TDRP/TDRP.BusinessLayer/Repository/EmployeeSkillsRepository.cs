﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class EmployeeSkillsRepository : Repository<EmployeeSkills>, IEmployeeSkillsRepository
    {
        private readonly ApplicationDbContext _db;

        public EmployeeSkillsRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public List<EmployeeSkills> GetEmployeeSkills()
        {
            List<EmployeeSkills> employeeSkills = new List<EmployeeSkills>();
            employeeSkills = _db.EmployeeSkills.AsList();
            return employeeSkills;
        }

        public IEnumerable<SelectListItem> GetEmployeeSkillsForDropDown()
        {
            return _db.EmployeeSkills.Select(i => new SelectListItem()
            {
                Text = i.Skills.Skill,
                Value = i.Id.ToString(),
            });
        }

        public void Update(EmployeeSkills employeeSkills)
        {
            var objFromDb = _db.EmployeeSkills.FirstOrDefault(s => s.Id == employeeSkills.Id);
            objFromDb.SkillId = employeeSkills.SkillId;            
            objFromDb.Active = employeeSkills.Active;
            objFromDb.StartDate = employeeSkills.StartDate;
            objFromDb.EndDate = employeeSkills.EndDate;
            objFromDb.CreatedBy = employeeSkills.CreatedBy;
            objFromDb.CreateDate = employeeSkills.CreateDate;
            objFromDb.UpdateBy = employeeSkills.UpdateBy;
            objFromDb.UpdateDate = DateTime.Now;
            objFromDb.EmployeeId = employeeSkills.EmployeeId;
            _db.SaveChanges();
        }
    }
}
