﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ProjectCategoryRepository : Repository<ProjectCategory>, IProjectCategoryRepository
    {
        private readonly ApplicationDbContext _db;

        public ProjectCategoryRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetCategoriesDropDown()
        {
            return _db.ProjectCategory.Select(i => new SelectListItem()
            {
                Text = i.Name,
                Value = i.Name.ToString()
            });
        }

        public void Update(ProjectCategory projectCategories)
        {
            var objFromDb = _db.ProjectCategory.FirstOrDefault(s => s.Id == projectCategories.Id);
            objFromDb.Name = projectCategories.Name;            
            objFromDb.Active = projectCategories.Active;
            objFromDb.CreatedDate = projectCategories.CreatedDate;
            objFromDb.UpdateBy = projectCategories.UpdateBy;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
