﻿using TDRP.DataAccessLayer.DBContext;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IUserRepository : IRepository<ApplicationUser>
    {
        void LockUser(string userId);

        void UnLockUser(string userId);
    }
}
