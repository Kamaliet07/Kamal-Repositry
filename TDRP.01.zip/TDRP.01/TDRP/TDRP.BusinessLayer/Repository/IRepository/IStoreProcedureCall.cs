﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IStoreProcedureCall : IDisposable
    {
        Task<IEnumerable<T>> ReturnList<T>(string storeprocedure, DynamicParameters parm = null);

        void ExecuteWithoutReturn(string storeprocedure, DynamicParameters parm = null);

        Task<T> ExecuteReturnScaler<T>(string storeprocedure, DynamicParameters parm = null);

        Task<T> QueryFirstOrDefault<T>(string storeprocedure, DynamicParameters parm = null);

        Task<int> ExecuteWithReturnAsync(string storeprocedure, DynamicParameters parm = null);        
    }
}
