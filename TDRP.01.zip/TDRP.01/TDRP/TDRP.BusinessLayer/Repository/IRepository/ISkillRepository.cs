﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface ISkillRepository : IRepository<Skills>
    {
        IEnumerable<SelectListItem> GetSkillsListItems();

        void Update(Skills skills);
    }
}
