﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface ITeamProjectsRepository : IRepository<TeamProjects>
    {
        IEnumerable<SelectListItem> GetTeamProjectsForDropDown();

        IEnumerable<TeamProjects> GetTeamProjects();

        void Update(TeamProjects teamProjects);
    }
}
