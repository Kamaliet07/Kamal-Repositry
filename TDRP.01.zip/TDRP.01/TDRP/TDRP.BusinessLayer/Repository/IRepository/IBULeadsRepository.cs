﻿using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IBULeadsRepository : IRepository<BusinessUniteLeads>
    {
        public interface IBusinessUniteRepository : IRepository<BusinessUniteLeads>
        {           
            List<BusinessUniteLeads> GetAllBusinessUnitesLeads();            
        }
    }
}
