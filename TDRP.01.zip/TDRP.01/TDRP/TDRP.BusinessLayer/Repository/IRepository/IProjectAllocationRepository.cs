﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository.IRepository
{
    public interface IProjectAllocationRepository : IRepository<ProjectAllocation>
    {
        IEnumerable<SelectListItem> GetBusinessUnitesForDropDown();
        List<ProjectAllocation> GetProjectAllocation();
        void Update(ProjectAllocation projectAllocation);
    }
}
