﻿using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ContractTypeRepository : Repository<ContractTypes>, IContractTypeRepository
    {
        private readonly ApplicationDbContext _db;
        public ContractTypeRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetContractTypeForDropDown()
        {
            return _db.ContractTypes.Select(i => new SelectListItem()
            {
                Text = i.ContractType,
                Value = i.Id.ToString(),
            });
        }

        public List<ContractTypes> GetContractTypes()
        {
            List<ContractTypes> contractTypes = new List<ContractTypes>();
            contractTypes = _db.ContractTypes.AsList();
            return contractTypes;
        }

        public void Update(ContractTypes contractTypes)
        {
            var objFromDb = _db.ContractTypes.FirstOrDefault(s => s.Id == contractTypes.Id);            
            objFromDb.ContractType = contractTypes.ContractType;           
            objFromDb.Active = contractTypes.Active;
            objFromDb.CreatedDate = contractTypes.CreatedDate;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
