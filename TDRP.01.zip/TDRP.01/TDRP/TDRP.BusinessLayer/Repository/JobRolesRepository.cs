﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using TDRP.BusinessLayer.Repository.IRepository;
using TDRP.DataAccessLayer.DBContext;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class JobRolesRepository : Repository<JobRoles>, IJobRolesRepository
    {
        private readonly ApplicationDbContext _db;

        public JobRolesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetJobRoles()
        {
            return _db.JobRoles.Select(i => new SelectListItem()
            {
                Text = i.JobRole,
                Value = i.Id.ToString(),
            });
        }

        public void Update(JobRoles jobRoles)
        {
            var objFromDb = _db.JobRoles.FirstOrDefault(s => s.Id == jobRoles.Id);
            objFromDb.JobRole = jobRoles.JobRole;
            objFromDb.JobRoleDescription = jobRoles.JobRoleDescription;
            objFromDb.Active = jobRoles.Active;
            objFromDb.CreatedBy = jobRoles.CreatedBy;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
