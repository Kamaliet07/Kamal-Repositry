﻿-- =============================================
-- Author:		Kamal Batham
-- Create date: 08-DEC-2021
-- Description:	Retrives List of All Register Users
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateProjectAllocationActiveStatus]
-- Add the parameters for the stored procedure here
	@ProjId INT,
	@Active BIT,
	@StartDate DATE,
	@EndDate DATE

AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
	IF(@Active = 1)
	  BEGIN
		  UPDATE [dbo].[ProjectAllocation]
		  SET Active = @Active,			
			StartDate = @StartDate,
			EndDate = @EndDate
		  WHERE ProjectId = @ProjId
	  END

	ELSE
	  BEGIN
		  UPDATE [dbo].[ProjectAllocation]
		  SET Active = @Active,			
			StartDate = Null,
			EndDate = Null
		  WHERE ProjectId = @ProjId
	  END

	RETURN @@rowcount
	
	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
