﻿CREATE PROCEDURE [dbo].[usp_GetResourceFteAvailability]
-- Add the parameters for the stored procedure here
	@EmpId INT

AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    
	DECLARE @FTEAssigned   DECIMAL(18,2)
    
	SELECT @FTEAssigned = COALESCE(SUM(PA.FTEAssigned), 0) FROM dbo.ProjectAllocation AS PA WHERE PA.EmployeeId = @EmpId AND PA.Active =1

	SELECT EP.EmployeeName, 
	       EJR.FTE, 
		   @FTEAssigned AS FTEConsumed,
		   (EJR.FTE - @FTEAssigned) AS FTEAvailable	   
    FROM  dbo.Employees AS EP  LEFT JOIN
          dbo.EmployeeJobRole AS EJR ON EJR.EmployeeId = EP.Id  LEFT JOIN   
		  dbo.ProjectAllocation AS PA ON EP.Id = PA.EmployeeId
	WHERE EP.Id  = @EmpId AND ISNULL(PA.EndDate, GETDATE() + 1) > GETDATE()
	GROUP BY EP.EmployeeName, EJR.FTE
	
	
	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
