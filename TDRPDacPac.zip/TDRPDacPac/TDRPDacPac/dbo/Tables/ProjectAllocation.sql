﻿CREATE TABLE [dbo].[ProjectAllocation] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [ProjectId]   INT             NOT NULL,
    [EmployeeId]  INT             NOT NULL,
    [FTEAssigned] DECIMAL (18, 2) NOT NULL,
    [StartDate]   DATETIME2 (7)   NULL,
    [EndDate]     DATETIME2 (7)   NULL,
    [CreatedBy]   NVARCHAR (MAX)  NULL,
    [CreatedDate] DATETIME2 (7)   NULL,
    [UpdateBy]    NVARCHAR (MAX)  NULL,
    [UpdatedDate] DATETIME2 (7)   NULL,
    [Active]      BIT             DEFAULT (CONVERT([bit],(0))) NOT NULL,
    CONSTRAINT [PK_ProjectAllocation] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProjectAllocation_Employees_EmployeeId] FOREIGN KEY ([EmployeeId]) REFERENCES [dbo].[Employees] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_ProjectAllocation_TeamProjects_ProjectId] FOREIGN KEY ([ProjectId]) REFERENCES [dbo].[TeamProjects] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_ProjectAllocation_EmployeeId]
    ON [dbo].[ProjectAllocation]([EmployeeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_ProjectAllocation_ProjectId]
    ON [dbo].[ProjectAllocation]([ProjectId] ASC);

