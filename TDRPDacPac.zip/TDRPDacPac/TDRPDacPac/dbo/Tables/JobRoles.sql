﻿CREATE TABLE [dbo].[JobRoles] (
    [Id]                 INT            IDENTITY (1, 1) NOT NULL,
    [JobRole]            NVARCHAR (150) NOT NULL,
    [JobRoleDescription] NVARCHAR (450) NOT NULL,
    [Active]             BIT            NOT NULL,
    [CreatedBy]          NVARCHAR (MAX) NULL,
    [CreatedDate]        DATETIME2 (7)  NULL,
    [UpdatedDate]        DATETIME2 (7)  NULL,
    CONSTRAINT [PK_JobRoles] PRIMARY KEY CLUSTERED ([Id] ASC)
);

