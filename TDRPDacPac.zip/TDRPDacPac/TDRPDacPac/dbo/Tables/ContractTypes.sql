﻿CREATE TABLE [dbo].[ContractTypes] (
    [Id]           INT           IDENTITY (1, 1) NOT NULL,
    [ContractType] NVARCHAR (50) NOT NULL,
    [Active]       BIT           NOT NULL,
    [CreatedDate]  DATETIME2 (7) NULL,
    [UpdatedDate]  DATETIME2 (7) NULL,
    CONSTRAINT [PK_ContractTypes] PRIMARY KEY CLUSTERED ([Id] ASC)
);

