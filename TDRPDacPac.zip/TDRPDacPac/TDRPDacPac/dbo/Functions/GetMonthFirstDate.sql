﻿CREATE FUNCTION [dbo].[GetMonthFirstDate]
(
    @Month CHAR(12),
	@Year INT
)
RETURNS date
AS
BEGIN
    DECLARE @CurrentDate Date
 
    ;WITH CteMonths(n, m) AS(
    SELECT 1, 'January' UNION ALL
    SELECT 2, 'February' UNION ALL
    SELECT 3, 'March' UNION ALL
    SELECT 4, 'April' UNION ALL
    SELECT 5, 'May' UNION ALL
    SELECT 6, 'June' UNION ALL
    SELECT 7, 'July' UNION ALL
    SELECT 8, 'August' UNION ALL
    SELECT 9, 'September' UNION ALL
    SELECT 10, 'October' UNION ALL
    SELECT 11, 'November' UNION ALL
    SELECT 12, 'December'
    )

    SELECT @CurrentDate  =  DATEADD(MONTH, n - 1, DATEADD(YEAR, @Year - 1, 0)) FROM CteMonths WHERE m = @Month
 
    RETURN @CurrentDate
END