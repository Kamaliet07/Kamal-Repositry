﻿CREATE TABLE [YBS\YBSXW505$].[ProjectAllocation] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [ProjectId]   INT             NOT NULL,
    [EmployeeId]  INT             NOT NULL,
    [FTEAssigned] DECIMAL (18, 2) NOT NULL,
    [Active]      BIT             NOT NULL,
    [StartDate]   DATETIME2 (7)   NULL,
    [EndDate]     DATETIME2 (7)   NULL,
    [CreatedBy]   NVARCHAR (MAX)  NULL,
    [CreatedDate] DATETIME2 (7)   NULL,
    [UpdateBy]    NVARCHAR (MAX)  NULL,
    [UpdatedDate] DATETIME2 (7)   NULL,
    CONSTRAINT [PK_ProjectAllocation] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProjectAllocation_Employees_EmployeeId] FOREIGN KEY ([EmployeeId]) REFERENCES [YBS\YBSXW505$].[Employees] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_ProjectAllocation_TeamProjects_ProjectId] FOREIGN KEY ([ProjectId]) REFERENCES [YBS\YBSXW505$].[TeamProjects] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_ProjectAllocation_EmployeeId]
    ON [YBS\YBSXW505$].[ProjectAllocation]([EmployeeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_ProjectAllocation_ProjectId]
    ON [YBS\YBSXW505$].[ProjectAllocation]([ProjectId] ASC);

