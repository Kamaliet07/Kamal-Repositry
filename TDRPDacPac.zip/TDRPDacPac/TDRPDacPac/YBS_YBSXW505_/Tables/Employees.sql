﻿CREATE TABLE [YBS\YBSXW505$].[Employees] (
    [Id]             INT            IDENTITY (1, 1) NOT NULL,
    [EmployeeName]   NVARCHAR (50)  NOT NULL,
    [EmployeeNumber] NVARCHAR (10)  NOT NULL,
    [Email]          NVARCHAR (50)  NOT NULL,
    [Active]         BIT            NOT NULL,
    [PhoneNumber]    NVARCHAR (10)  NULL,
    [StartDate]      DATETIME2 (7)  NULL,
    [EndDate]        DATETIME2 (7)  NULL,
    [CreatedBy]      NVARCHAR (MAX) NOT NULL,
    [CreateDate]     DATETIME2 (7)  NOT NULL,
    [UpdateBy]       NVARCHAR (MAX) NULL,
    [UpdateDate]     DATETIME2 (7)  NULL,
    CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED ([Id] ASC)
);

