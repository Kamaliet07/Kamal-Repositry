﻿CREATE TABLE [YBS\YBSXW505$].[BusinessUniteLeads] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [BusinessUniteId] INT            NOT NULL,
    [LeadsId]         NVARCHAR (450) NOT NULL,
    [CreatedBy]       NVARCHAR (450) NOT NULL,
    [CreatedDate]     DATETIME2 (7)  NULL,
    CONSTRAINT [PK_BusinessUniteLeads] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_BusinessUniteLeads_BusinessUnite_BusinessUniteId] FOREIGN KEY ([BusinessUniteId]) REFERENCES [YBS\YBSXW505$].[BusinessUnite] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_BusinessUniteLeads_BusinessUniteId]
    ON [YBS\YBSXW505$].[BusinessUniteLeads]([BusinessUniteId] ASC);

