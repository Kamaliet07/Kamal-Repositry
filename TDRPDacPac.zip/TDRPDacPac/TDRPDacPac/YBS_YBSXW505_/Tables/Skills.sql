﻿CREATE TABLE [YBS\YBSXW505$].[Skills] (
    [Id]               INT            IDENTITY (1, 1) NOT NULL,
    [Skill]            NVARCHAR (150) NOT NULL,
    [SkillDescription] NVARCHAR (250) NOT NULL,
    [Active]           BIT            NOT NULL,
    [CreatedBy]        NVARCHAR (MAX) NULL,
    [CreatedDate]      DATETIME2 (7)  NULL,
    [UpdatedDate]      DATETIME2 (7)  NULL,
    CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED ([Id] ASC)
);

