﻿CREATE TABLE [YBS\YBSXW505$].[ProjectCategory] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (MAX) NOT NULL,
    [Active]      BIT            NOT NULL,
    [CreatedBy]   NVARCHAR (MAX) NULL,
    [CreatedDate] DATETIME2 (7)  NOT NULL,
    [UpdatedDate] DATETIME2 (7)  NULL,
    [UpdateBy]    NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_ProjectCategory] PRIMARY KEY CLUSTERED ([Id] ASC)
);

