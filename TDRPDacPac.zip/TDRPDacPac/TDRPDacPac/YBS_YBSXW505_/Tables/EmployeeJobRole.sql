﻿CREATE TABLE [YBS\YBSXW505$].[EmployeeJobRole] (
    [Id]             INT             IDENTITY (1, 1) NOT NULL,
    [EmployeeId]     INT             NOT NULL,
    [JobRoleId]      INT             NOT NULL,
    [ContractTypeId] INT             NOT NULL,
    [FTE]            DECIMAL (18, 2) NOT NULL,
    [Active]         BIT             NOT NULL,
    [StartDate]      DATETIME2 (7)   NULL,
    [EndDate]        DATETIME2 (7)   NULL,
    [CreatedBy]      NVARCHAR (MAX)  NOT NULL,
    [CreateDate]     DATETIME2 (7)   NOT NULL,
    [Updateby]       NVARCHAR (MAX)  NULL,
    [UpdateDate]     DATETIME2 (7)   NULL,
    CONSTRAINT [PK_EmployeeJobRole] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_EmployeeJobRole_ContractTypes_ContractTypeId] FOREIGN KEY ([ContractTypeId]) REFERENCES [YBS\YBSXW505$].[ContractTypes] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_EmployeeJobRole_Employees_EmployeeId] FOREIGN KEY ([EmployeeId]) REFERENCES [YBS\YBSXW505$].[Employees] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_EmployeeJobRole_JobRoles_JobRoleId] FOREIGN KEY ([JobRoleId]) REFERENCES [YBS\YBSXW505$].[JobRoles] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_EmployeeJobRole_ContractTypeId]
    ON [YBS\YBSXW505$].[EmployeeJobRole]([ContractTypeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_EmployeeJobRole_EmployeeId]
    ON [YBS\YBSXW505$].[EmployeeJobRole]([EmployeeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_EmployeeJobRole_JobRoleId]
    ON [YBS\YBSXW505$].[EmployeeJobRole]([JobRoleId] ASC);

