﻿CREATE TABLE [YBS\YBSXW505$].[TeamResources] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [EmployeeId] INT            NOT NULL,
    [TeamId]     INT            NOT NULL,
    [CreatedBy]  NVARCHAR (MAX) NOT NULL,
    [CreateDate] DATETIME2 (7)  NOT NULL,
    [UpdateBy]   NVARCHAR (MAX) NULL,
    [UpdateDate] DATETIME2 (7)  NULL,
    CONSTRAINT [PK_TeamResources] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_TeamResources_Employees_EmployeeId] FOREIGN KEY ([EmployeeId]) REFERENCES [YBS\YBSXW505$].[Employees] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_TeamResources_Teams_TeamId] FOREIGN KEY ([TeamId]) REFERENCES [YBS\YBSXW505$].[Teams] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_TeamResources_EmployeeId]
    ON [YBS\YBSXW505$].[TeamResources]([EmployeeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_TeamResources_TeamId]
    ON [YBS\YBSXW505$].[TeamResources]([TeamId] ASC);

