﻿CREATE TABLE [YBS\YBSXW505$].[EmployeeSkills] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [EmployeeId] INT            NOT NULL,
    [SkillId]    INT            NOT NULL,
    [Active]     BIT            NOT NULL,
    [StartDate]  DATETIME2 (7)  NULL,
    [EndDate]    DATETIME2 (7)  NULL,
    [CreatedBy]  NVARCHAR (MAX) NULL,
    [CreateDate] DATETIME2 (7)  NOT NULL,
    [UpdateBy]   NVARCHAR (MAX) NULL,
    [UpdateDate] DATETIME2 (7)  NULL,
    CONSTRAINT [PK_EmployeeSkills] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_EmployeeSkills_Employees_EmployeeId] FOREIGN KEY ([EmployeeId]) REFERENCES [YBS\YBSXW505$].[Employees] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_EmployeeSkills_Skills_SkillId] FOREIGN KEY ([SkillId]) REFERENCES [YBS\YBSXW505$].[Skills] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_EmployeeSkills_EmployeeId]
    ON [YBS\YBSXW505$].[EmployeeSkills]([EmployeeId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_EmployeeSkills_SkillId]
    ON [YBS\YBSXW505$].[EmployeeSkills]([SkillId] ASC);

